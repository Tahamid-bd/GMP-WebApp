import React, { useState, useEffect, useMemo } from 'react';
import { AccountOpeningBalance, FilterOptions, Transaction, TransactionType, TransactionWithBalance, ViewTab } from './types';
import { INITIAL_OPENING_BALANCES, INITIAL_TRANSACTIONS, INITIAL_CATEGORIES } from './data/initialData';
import { calculateTransactionsWithRunningBalance, exportToCSV, filterTransactions, sortAccountsWithCashFirst } from './utils/finance';
import { Sidebar } from './components/Sidebar';
import { TopHeader } from './components/TopHeader';
import { AccountSummaryCards } from './components/AccountSummaryCards';
import { FilterBar } from './components/FilterBar';
import { TransactionTable } from './components/TransactionTable';
import { TransactionModal } from './components/TransactionModal';
import { OpeningBalancesModal } from './components/OpeningBalancesModal';
import { CategoryManagerModal } from './components/CategoryManagerModal';
import { HeaderConfigModal, HeaderConfig } from './components/HeaderConfigModal';
import { AnalyticsView } from './components/AnalyticsView';
import { StatementView } from './components/StatementView';
import { GoogleSyncWidget } from './components/GoogleSyncWidget';
import { getStoredSyncConfig, pushTransactionsToSheet, performFullSync } from './lib/googleSheetsSync';
import { initAuth } from './lib/googleAuth';
import { Search, ChevronDown, Filter } from 'lucide-react';

const LOCAL_STORAGE_ACCOUNTS_KEY = 'transaction_register_accounts_v1';
const LOCAL_STORAGE_TRANSACTIONS_KEY = 'transaction_register_transactions_v1';
const LOCAL_STORAGE_CATEGORIES_KEY = 'transaction_register_categories_v1';
const LOCAL_STORAGE_HEADER_CONFIG_KEY = 'transaction_register_header_config_v1';

const DEFAULT_HEADER_CONFIG: HeaderConfig = {
  title: 'Transaction Register Ledger Report',
  subtitle: 'Bank & Cash Ledger Statement',
  logoUrl: '',
  isEnabled: true,
};

export default function App() {
  // Load initial accounts
  const [accounts, setAccounts] = useState<AccountOpeningBalance[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_ACCOUNTS_KEY);
      if (saved) return sortAccountsWithCashFirst(JSON.parse(saved));
    } catch (e) {
      console.error('Failed to load accounts from storage', e);
    }
    return sortAccountsWithCashFirst(INITIAL_OPENING_BALANCES);
  });

  // Load initial transactions
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_TRANSACTIONS_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load transactions from storage', e);
    }
    return INITIAL_TRANSACTIONS;
  });

  // Load custom categories
  const [customCategories, setCustomCategories] = useState<{ type: TransactionType; name: string }[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CATEGORIES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load custom categories from storage', e);
    }
    return INITIAL_CATEGORIES;
  });

  // Load Header Config
  const [headerConfig, setHeaderConfig] = useState<HeaderConfig>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_HEADER_CONFIG_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load header config from storage', e);
    }
    return DEFAULT_HEADER_CONFIG;
  });

  // Active View Tab
  const [activeTab, setActiveTab] = useState<ViewTab>('register');

  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [isOpeningModalOpen, setIsOpeningModalOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [isHeaderModalOpen, setIsHeaderModalOpen] = useState(false);
  const [initialAccountForModal, setInitialAccountForModal] = useState<string>('All');

  // Filter Options State
  const [isFilterVisible, setIsFilterVisible] = useState(false);
  const [filters, setFilters] = useState<FilterOptions>({
    searchQuery: '',
    type: 'All',
    category: 'All',
    account: 'All',
    startDate: '',
    endDate: '',
    minAmount: '',
    maxAmount: '',
  });

  // Clear filters whenever activeTab changes
  useEffect(() => {
    handleClearFilters();
  }, [activeTab]);

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_ACCOUNTS_KEY, JSON.stringify(accounts));
    } catch (e) {
      console.error('Failed to save accounts to storage', e);
    }
  }, [accounts]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_TRANSACTIONS_KEY, JSON.stringify(transactions));
    } catch (e) {
      console.error('Failed to save transactions to storage', e);
    }
  }, [transactions]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_CATEGORIES_KEY, JSON.stringify(customCategories));
    } catch (e) {
      console.error('Failed to save categories to storage', e);
    }
  }, [customCategories]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_HEADER_CONFIG_KEY, JSON.stringify(headerConfig));
    } catch (e) {
      console.error('Failed to save header config to storage', e);
    }
  }, [headerConfig]);

  // Compute transactions with running balances
  const transactionsWithBalance = useMemo(() => {
    return calculateTransactionsWithRunningBalance(transactions, accounts);
  }, [transactions, accounts]);

  // Filtered transactions for view
  const filteredTransactions = useMemo(() => {
    return filterTransactions(transactionsWithBalance, filters);
  }, [transactionsWithBalance, filters]);

  // Auto Sync on load if enabled
  useEffect(() => {
    const syncConfig = getStoredSyncConfig();
    if (syncConfig.autoSyncEnabled && syncConfig.spreadsheetId) {
      const unsubscribe = initAuth((user) => {
        if (user) {
          performFullSync(transactions)
            .then((res) => {
              if (res.mergedTransactions && res.mergedTransactions.length > 0) {
                setTransactions(res.mergedTransactions);
              }
            })
            .catch((err) => console.error('Auto-sync on load failed:', err));
        }
      });
      return () => unsubscribe();
    }
  }, []);

  // Handlers
  const handleSaveTransaction = (
    transactionData: Omit<Transaction, 'id' | 'createdAt'> & { id?: string }
  ) => {
    let updatedList: Transaction[] = [];
    if (transactionData.id) {
      // Edit
      updatedList = transactions.map((t) =>
        t.id === transactionData.id
          ? { ...t, ...transactionData, id: transactionData.id }
          : t
      );
    } else {
      // New
      const newTransaction: Transaction = {
        ...transactionData,
        id: 'tnx-' + Date.now(),
        createdAt: Date.now(),
      };
      updatedList = [newTransaction, ...transactions];
    }
    setTransactions(updatedList);
    setEditingTransaction(null);

    // Auto push to Google Sheet if Auto Sync is enabled
    const syncConfig = getStoredSyncConfig();
    if (syncConfig.autoSyncEnabled && syncConfig.spreadsheetId) {
      pushTransactionsToSheet(syncConfig.spreadsheetId, updatedList).catch((err) =>
        console.error('Auto push to Google Sheet error:', err)
      );
    }
  };

  const handleDeleteTransaction = (id: string) => {
    const updatedList = transactions.filter((t) => t.id !== id);
    setTransactions(updatedList);

    // Auto push to Google Sheet if Auto Sync is enabled
    const syncConfig = getStoredSyncConfig();
    if (syncConfig.autoSyncEnabled && syncConfig.spreadsheetId) {
      pushTransactionsToSheet(syncConfig.spreadsheetId, updatedList).catch((err) =>
        console.error('Auto push to Google Sheet error:', err)
      );
    }
  };

  const handleSaveAccounts = (updatedAccounts: AccountOpeningBalance[]) => {
    // Check if any bank account names were updated and sync transactions
    accounts.forEach((oldAcc) => {
      const updated = updatedAccounts.find((a) => a.id === oldAcc.id);
      if (updated && updated.name !== oldAcc.name) {
        setTransactions((prev) =>
          prev.map((t) =>
            t.accountName === oldAcc.name ? { ...t, accountName: updated.name } : t
          )
        );
      }
    });
    setAccounts(sortAccountsWithCashFirst(updatedAccounts));
  };

  const handleAddCustomCategory = (type: TransactionType, name: string) => {
    setCustomCategories((prev) => {
      if (prev.some((c) => c.type === type && c.name.toLowerCase() === name.toLowerCase())) {
        return prev;
      }
      return [...prev, { type, name }];
    });
  };

  const handleDeleteCustomCategory = (type: TransactionType, name: string) => {
    setCustomCategories((prev) =>
      prev.filter((c) => !(c.type === type && c.name.toLowerCase() === name.toLowerCase()))
    );
  };

  const handleEditCustomCategory = (type: TransactionType, oldName: string, newName: string) => {
    setCustomCategories((prev) =>
      prev.map((c) =>
        c.type === type && c.name.toLowerCase() === oldName.toLowerCase()
          ? { type, name: newName }
          : c
      )
    );
    setTransactions((prev) =>
      prev.map((t) =>
        t.type === type && t.category.toLowerCase() === oldName.toLowerCase()
          ? { ...t, category: newName }
          : t
      )
    );
  };

  const handleResetData = () => {
    if (
      window.confirm(
        'Reset register data to default initial sample transactions and opening balances?'
      )
    ) {
      setAccounts(INITIAL_OPENING_BALANCES);
      setTransactions(INITIAL_TRANSACTIONS);
      setCustomCategories(INITIAL_CATEGORIES);
      setFilters({
        searchQuery: '',
        type: 'All',
        category: 'All',
        account: 'All',
        startDate: '',
        endDate: '',
        minAmount: '',
        maxAmount: '',
      });
      localStorage.removeItem(LOCAL_STORAGE_ACCOUNTS_KEY);
      localStorage.removeItem(LOCAL_STORAGE_TRANSACTIONS_KEY);
      localStorage.removeItem(LOCAL_STORAGE_CATEGORIES_KEY);
    }
  };

  const handleExportCSV = () => {
    exportToCSV(transactionsWithBalance, accounts);
  };

  const handleClearFilters = () => {
    setFilters({
      searchQuery: '',
      type: 'All',
      category: 'All',
      account: 'All',
      startDate: '',
      endDate: '',
      minAmount: '',
      maxAmount: '',
    });
  };

  const handleSelectAccountFilter = (accName: string) => {
    setFilters((prev) => ({ ...prev, account: accName }));
    setIsFilterVisible(true);
    if (activeTab !== 'register') {
      setActiveTab('register');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-500 selection:text-white flex flex-col md:flex-row">
      
      {/* Left Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddModal={() => {
          setEditingTransaction(null);
          setInitialAccountForModal(filters.account);
          setIsAddModalOpen(true);
        }}
        onOpenOpeningModal={() => setIsOpeningModalOpen(true)}
        onOpenCategoryModal={() => setIsCategoryModalOpen(true)}
        onResetData={handleResetData}
        transactionCount={transactions.length}
      />

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col min-w-0">
        <TopHeader activeTab={activeTab} />

        {/* Main Body */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
          
          {/* Google Sheets Real-time Auto Sync Banner */}
          <GoogleSyncWidget
            transactions={transactions}
            onTransactionsUpdated={(newTnx) => setTransactions(newTnx)}
          />

          {/* Views */}
          {activeTab === 'register' && (
            <div className="space-y-4">
              {/* 1. Search & Filter Trigger Button */}
              <div
                className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white border border-slate-200 p-3.5 sm:p-4 rounded-xl shadow-xs"
                style={{ borderWidth: '2.8px', borderColor: '#7a8088' }}
              >
                <button
                  type="button"
                  onClick={() => setIsFilterVisible((prev) => !prev)}
                  className="w-full sm:w-auto px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm rounded-lg shadow-sm transition-all flex items-center justify-center space-x-2 cursor-pointer active:scale-[0.99]"
                >
                  <Search className="h-4 w-4 shrink-0" />
                  <span>Click Here For Search Specific Data</span>
                  <ChevronDown className={`h-4 w-4 shrink-0 transition-transform duration-200 ${isFilterVisible ? 'rotate-180' : ''}`} />
                </button>

                {isFilterVisible && (
                  <button
                    type="button"
                    onClick={handleClearFilters}
                    className="text-xs text-rose-600 hover:text-rose-700 font-semibold underline self-end sm:self-auto cursor-pointer"
                  >
                    Clear Filters
                  </button>
                )}
              </div>

              {/* 2. Filter Bar */}
              {isFilterVisible && (
                <FilterBar
                  filters={filters}
                  setFilters={setFilters}
                  accounts={accounts}
                  totalFilteredCount={filteredTransactions.length}
                  totalAllCount={transactions.length}
                  onClearFilters={handleClearFilters}
                  customCategories={customCategories}
                  allTransactions={transactions}
                  onOpenCategoryManager={() => setIsCategoryModalOpen(true)}
                  onOpenBankManager={() => setIsOpeningModalOpen(true)}
                />
              )}

              {/* 3. Summary Cards (Sequence: 1. Opening Balance, 2. Received, 3. Payments, 4. Closing Balance) */}
              <AccountSummaryCards
                accounts={accounts}
                transactions={transactions}
                selectedAccountFilter={filters.account}
                onSelectAccountFilter={handleSelectAccountFilter}
              />

              {/* 4. Transaction Register Table */}
              <TransactionTable
                transactions={filteredTransactions}
                headerConfig={headerConfig}
                onEdit={(tnx) => {
                  setEditingTransaction(tnx);
                  setIsAddModalOpen(true);
                }}
                onDelete={handleDeleteTransaction}
                onOpenAddModal={() => {
                  setEditingTransaction(null);
                  setIsAddModalOpen(true);
                }}
              />
            </div>
          )}

          {activeTab === 'accounts' && (
            <div className="space-y-4">
              <div
                className="flex flex-col sm:flex-row items-start sm:items-center justify-between bg-white border border-slate-200 p-5 rounded-xl shadow-sm gap-3"
                style={{ borderWidth: '2.8px', borderColor: '#7a8088' }}
              >
                <div>
                  <h2 className="text-base font-bold text-slate-900">
                    Bank & Cash Accounts Management
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Configure account details, opening balances, and view account-specific register histories.
                  </p>
                </div>
                <button
                  onClick={() => setIsOpeningModalOpen(true)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium rounded-md shadow-sm transition-all cursor-pointer"
                >
                  Edit Opening Balances
                </button>
              </div>

              {/* Search & Filter Trigger Button */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white border border-slate-200 p-3.5 sm:p-4 rounded-xl shadow-xs">
                <button
                  type="button"
                  onClick={() => setIsFilterVisible((prev) => !prev)}
                  className="w-full sm:w-auto px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm rounded-lg shadow-sm transition-all flex items-center justify-center space-x-2 cursor-pointer active:scale-[0.99]"
                >
                  <Search className="h-4 w-4 shrink-0" />
                  <span>Click Here For Search Specific Data</span>
                  <ChevronDown className={`h-4 w-4 shrink-0 transition-transform duration-200 ${isFilterVisible ? 'rotate-180' : ''}`} />
                </button>

                {isFilterVisible && (
                  <button
                    type="button"
                    onClick={handleClearFilters}
                    className="text-xs text-rose-600 hover:text-rose-700 font-semibold underline self-end sm:self-auto cursor-pointer"
                  >
                    Clear Filters
                  </button>
                )}
              </div>

              {isFilterVisible && (
                <FilterBar
                  filters={filters}
                  setFilters={setFilters}
                  accounts={accounts}
                  totalFilteredCount={filteredTransactions.length}
                  totalAllCount={transactions.length}
                  onClearFilters={handleClearFilters}
                  customCategories={customCategories}
                  allTransactions={transactions}
                  onOpenCategoryManager={() => setIsCategoryModalOpen(true)}
                  onOpenBankManager={() => setIsOpeningModalOpen(true)}
                />
              )}

              {/* Summary Cards */}
              <AccountSummaryCards
                accounts={accounts}
                transactions={transactions}
                selectedAccountFilter={filters.account}
                onSelectAccountFilter={handleSelectAccountFilter}
              />

              <TransactionTable
                transactions={filteredTransactions}
                headerConfig={headerConfig}
                onEdit={(tnx) => {
                  setEditingTransaction(tnx);
                  setIsAddModalOpen(true);
                }}
                onDelete={handleDeleteTransaction}
                onOpenAddModal={() => {
                  setEditingTransaction(null);
                  setIsAddModalOpen(true);
                }}
              />
            </div>
          )}

          {activeTab === 'statement' && (
            <StatementView transactions={transactions} accounts={accounts} categories={customCategories} />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsView transactions={transactions} accounts={accounts} />
          )}

        </main>
      </div>

      {/* Record / Edit Transaction Modal */}
      <TransactionModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingTransaction(null);
        }}
        onSave={handleSaveTransaction}
        editingTransaction={editingTransaction}
        allTransactions={transactions}
        accounts={accounts}
        initialAccount={initialAccountForModal}
        customCategories={customCategories}
      />

      {/* Opening Balances Modal */}
      <OpeningBalancesModal
        isOpen={isOpeningModalOpen}
        onClose={() => setIsOpeningModalOpen(false)}
        accounts={accounts}
        onSaveAccounts={handleSaveAccounts}
      />

      {/* Category Manager Modal */}
      <CategoryManagerModal
        isOpen={isCategoryModalOpen}
        onClose={() => setIsCategoryModalOpen(false)}
        customCategories={customCategories}
        onAddCustomCategory={handleAddCustomCategory}
        onDeleteCustomCategory={handleDeleteCustomCategory}
        onEditCustomCategory={handleEditCustomCategory}
      />

      {/* Header Config Modal */}
      <HeaderConfigModal
        isOpen={isHeaderModalOpen}
        onClose={() => setIsHeaderModalOpen(false)}
        headerConfig={headerConfig}
        onSave={(updatedConfig) => setHeaderConfig(updatedConfig)}
      />

    </div>
  );
}
