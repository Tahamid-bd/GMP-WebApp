export type TransactionType = 'Receipts' | 'Expenses' | 'Contra';

export type TransactionMode = 'Bank' | 'Cash' | 'Bank→Cash' | 'Cash→Bank' | 'Bank→Bank';

export interface AccountOpeningBalance {
  id: string;
  name: string;
  amount: number;
}

export interface Transaction {
  id: string;
  entryDate: string; // YYYY-MM-DD or DD-MMM-YYYY format
  voucherNo: string;
  type: TransactionType;
  category: string;
  mode: TransactionMode;
  withdrawnBank: string; // Account name or 'N/A'
  depositedBank: string; // Account name or 'N/A'
  amount: number;
  remarks: string;
  createdAt: number;
}

export interface TransactionWithBalance extends Transaction {
  balanceAmount: number;
}

export interface FilterOptions {
  searchQuery: string;
  type: string; // 'All' | 'Receipts' | 'Expenses' | 'Contra'
  category: string; // 'All' | specific category
  account: string; // 'All' | specific bank/cash
  startDate: string;
  endDate: string;
  minAmount: string;
  maxAmount: string;
}

export type ViewTab = 'register' | 'accounts' | 'analytics' | 'statement';
