import { AccountOpeningBalance, FilterOptions, Transaction, TransactionWithBalance } from '../types';

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatNumberInput(value: string | number): string {
  if (value === '' || value === null || value === undefined) return '';
  const str = value.toString();
  // Strip out invalid characters except digits and decimal point
  const clean = str.replace(/[^0-9.]/g, '');
  if (!clean) return '';

  const parts = clean.split('.');
  const intStr = parts[0];
  const formattedInt = intStr === '' ? '0' : parseInt(intStr, 10).toLocaleString('en-US');

  if (parts.length > 1) {
    // Limit decimal places to max 4 if needed or keep user typing
    return `${formattedInt}.${parts[1]}`;
  }
  return formattedInt;
}

export function parseFormattedNumber(value: string | number): number {
  if (value === '' || value === null || value === undefined) return 0;
  if (typeof value === 'number') return isNaN(value) ? 0 : value;
  const clean = value.replace(/,/g, '');
  const parsed = parseFloat(clean);
  return isNaN(parsed) ? 0 : parsed;
}

export function sortAccountsWithCashFirst(accounts: AccountOpeningBalance[]): AccountOpeningBalance[] {
  return [...accounts].sort((a, b) => {
    const isACash = a.name.trim().toLowerCase() === 'cash';
    const isBCash = b.name.trim().toLowerCase() === 'cash';
    if (isACash) return -1;
    if (isBCash) return 1;
    return a.name.localeCompare(b.name, undefined, { sensitivity: 'base' });
  });
}

export function formatDateForDisplay(dateStr: string): string {
  if (!dateStr) return '';
  // If YYYY-MM-DD
  const parts = dateStr.split('-');
  if (parts.length === 3 && parts[0].length === 4) {
    const date = new Date(dateStr + 'T00:00:00');
    if (!isNaN(date.getTime())) {
      return date.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });
    }
  }
  return dateStr;
}

export function calculateAccountBalances(
  accounts: AccountOpeningBalance[],
  transactions: Transaction[]
): Record<string, { opening: number; current: number; totalIn: number; totalOut: number }> {
  const result: Record<string, { opening: number; current: number; totalIn: number; totalOut: number }> = {};

  // Initialize with opening balances
  accounts.forEach((acc) => {
    result[acc.name] = {
      opening: acc.amount,
      current: acc.amount,
      totalIn: 0,
      totalOut: 0,
    };
  });

  // Calculate movements
  transactions.forEach((tnx) => {
    const amt = Number(tnx.amount) || 0;

    // Inflow to deposited bank
    if (tnx.depositedBank && tnx.depositedBank !== 'N/A' && result[tnx.depositedBank]) {
      result[tnx.depositedBank].current += amt;
      result[tnx.depositedBank].totalIn += amt;
    }

    // Outflow from withdrawn bank
    if (tnx.withdrawnBank && tnx.withdrawnBank !== 'N/A' && result[tnx.withdrawnBank]) {
      result[tnx.withdrawnBank].current -= amt;
      result[tnx.withdrawnBank].totalOut += amt;
    }
  });

  return result;
}

export function calculateTransactionsWithRunningBalance(
  transactions: Transaction[],
  accounts: AccountOpeningBalance[]
): TransactionWithBalance[] {
  // Sort transactions by date and id
  const sorted = [...transactions].sort((a, b) => {
    if (a.entryDate !== b.entryDate) {
      return a.entryDate.localeCompare(b.entryDate);
    }
    return (a.createdAt || 0) - (b.createdAt || 0);
  });

  const totalOpening = accounts.reduce((sum, acc) => sum + (acc.amount || 0), 0);
  let runningBalance = totalOpening;

  return sorted.map((tnx) => {
    const amt = Number(tnx.amount) || 0;
    if (tnx.type === 'Receipts') {
      runningBalance += amt;
    } else if (tnx.type === 'Expenses') {
      runningBalance -= amt;
    }
    // Contra doesn't change total liquid funds across all accounts
    return {
      ...tnx,
      balanceAmount: runningBalance,
    };
  });
}

export function filterTransactions(
  transactions: TransactionWithBalance[],
  filters: FilterOptions
): TransactionWithBalance[] {
  return transactions.filter((tnx) => {
    // Search query
    if (filters.searchQuery.trim()) {
      const q = filters.searchQuery.toLowerCase().trim();
      const matchVoucher = tnx.voucherNo.toLowerCase().includes(q);
      const matchRemarks = tnx.remarks.toLowerCase().includes(q);
      const matchCategory = tnx.category.toLowerCase().includes(q);
      const matchWithdrawn = tnx.withdrawnBank.toLowerCase().includes(q);
      const matchDeposited = tnx.depositedBank.toLowerCase().includes(q);
      const matchAmount = tnx.amount.toString().includes(q);
      if (!matchVoucher && !matchRemarks && !matchCategory && !matchWithdrawn && !matchDeposited && !matchAmount) {
        return false;
      }
    }

    // Type filter
    if (filters.type && filters.type !== 'All' && tnx.type !== filters.type) {
      return false;
    }

    // Category filter
    if (filters.category && filters.category !== 'All' && tnx.category !== filters.category) {
      return false;
    }

    // Account filter
    if (filters.account && filters.account !== 'All') {
      const matchWithdrawn = tnx.withdrawnBank === filters.account;
      const matchDeposited = tnx.depositedBank === filters.account;
      if (!matchWithdrawn && !matchDeposited) {
        return false;
      }
    }

    // Date range filter
    if (filters.startDate && tnx.entryDate < filters.startDate) {
      return false;
    }
    if (filters.endDate && tnx.entryDate > filters.endDate) {
      return false;
    }

    // Amount range
    if (filters.minAmount && tnx.amount < Number(filters.minAmount)) {
      return false;
    }
    if (filters.maxAmount && tnx.amount > Number(filters.maxAmount)) {
      return false;
    }

    return true;
  });
}

export function exportToCSV(
  transactions: TransactionWithBalance[],
  accounts: AccountOpeningBalance[]
) {
  const accountBalances = calculateAccountBalances(accounts, transactions);
  const totalOpening = accounts.reduce((s, a) => s + a.amount, 0);

  let csvContent = 'Transaction Register\n';
  csvContent += 'Master source for all receipts, expenses and contra movements\n\n';

  csvContent += 'Date,Bank Name,Amount,Remarks\n';
  accounts.forEach((acc) => {
    csvContent += `01-Jul-2026,${acc.name},"${formatCurrency(acc.amount)}",Opening Balance\n`;
  });
  csvContent += `01-Jul-2026,Total Opening,"${formatCurrency(totalOpening)}",\n\n`;

  csvContent += 'Entry Date,Voucher No,Transaction Type,Category,Transaction Mode,Amount Withdrawn Bank Name,Amount Deposited Bank Name,Transaction Amount,Balance Amount,Remarks\n';

  transactions.forEach((t) => {
    const row = [
      formatDateForDisplay(t.entryDate),
      t.voucherNo,
      t.type,
      `"${t.category}"`,
      t.mode,
      t.withdrawnBank,
      t.depositedBank,
      `"${formatCurrency(t.amount)}"`,
      `"${formatCurrency(t.balanceAmount)}"`,
      `"${t.remarks.replace(/"/g, '""')}"`,
    ];
    csvContent += row.join(',') + '\n';
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Transaction_Register_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function generateNextVoucherNo(transactions: Transaction[]): string {
  let maxNum = 0;
  transactions.forEach((t) => {
    const match = t.voucherNo.match(/Tnx-(\d+)/i);
    if (match) {
      const num = parseInt(match[1], 10);
      if (num > maxNum) maxNum = num;
    }
  });
  const nextNum = maxNum + 1;
  return `Tnx-${nextNum < 10 ? '0' + nextNum : nextNum}`;
}
