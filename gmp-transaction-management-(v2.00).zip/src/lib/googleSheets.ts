import { getAccessToken, googleSignIn } from './googleAuth';

export interface StatementDataForExport {
  title: string;
  periodText: string;
  scopeText: string;
  openingBalances: { name: string; amount: number }[];
  openingTotal: number;
  receipts: { name: string; amount: number; count: number }[];
  receiptsTotal: number;
  expenses: { name: string; amount: number; count: number }[];
  expensesTotal: number;
  closingBalances: { name: string; amount: number }[];
  closingTotal: number;
}

export async function ensureAccessToken(): Promise<string> {
  let token = await getAccessToken();
  if (!token) {
    const res = await googleSignIn();
    if (!res?.accessToken) {
      throw new Error('Please sign in with Google to export to Google Sheets.');
    }
    token = res.accessToken;
  }
  return token;
}

/**
 * Creates and formats a Google Spreadsheet for the Receipts & Payments Statement
 */
export async function exportStatementToGoogleSheets(data: StatementDataForExport): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  const accessToken = await ensureAccessToken();

  // 1. Prepare raw row values
  const values: (string | number)[][] = [
    ['GMP FASHIONS LTD.'],
    ['RECEIPTS & PAYMENTS STATEMENT'],
    [`Period: ${data.periodText} | Account Scope: ${data.scopeText}`],
    [],
    ['A. OPENING CASH & BANK BALANCES', 'AMOUNT (BDT)'],
  ];

  data.openingBalances.forEach((acc) => {
    values.push([acc.name, Math.round(acc.amount)]);
  });
  values.push(['TOTAL OPENING BALANCE', Math.round(data.openingTotal)]);
  values.push([]);

  values.push(['B. RECEIPTS RECEIVED DURING PERIOD', 'AMOUNT (BDT)', 'TRANSACTIONS']);
  data.receipts.forEach((r) => {
    values.push([r.name, Math.round(r.amount), `${r.count} Entries`]);
  });
  values.push(['TOTAL RECEIPTS', Math.round(data.receiptsTotal), '']);
  values.push([]);

  values.push(['C. PAYMENTS & EXPENSES MADE DURING PERIOD', 'AMOUNT (BDT)', 'TRANSACTIONS']);
  data.expenses.forEach((e) => {
    values.push([e.name, Math.round(e.amount), `${e.count} Entries`]);
  });
  values.push(['TOTAL PAYMENTS & EXPENSES', Math.round(data.expensesTotal), '']);
  values.push([]);

  values.push(['D. CLOSING CASH & BANK BALANCES', 'AMOUNT (BDT)']);
  data.closingBalances.forEach((acc) => {
    values.push([acc.name, Math.round(acc.amount)]);
  });
  values.push(['TOTAL CLOSING BALANCE', Math.round(data.closingTotal)]);

  // 2. Create the Spreadsheet via Google Sheets API
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: `GMP Fashions Ltd - Cash & Bank Statement (${new Date().toLocaleDateString('en-GB')})`,
      },
      sheets: [
        {
          properties: {
            title: 'Statement',
            gridProperties: {
              frozenRowCount: 4,
            },
          },
        },
      ],
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(`Failed to create Google Sheet: ${createRes.statusText} (${errText})`);
  }

  const sheetData = await createRes.json();
  const spreadsheetId = sheetData.spreadsheetId;
  const sheetId = sheetData.sheets[0].properties.sheetId;

  // 3. Populate values
  const updateRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Statement!A1?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        values,
      }),
    }
  );

  if (!updateRes.ok) {
    const errText = await updateRes.text();
    throw new Error(`Failed to update Google Sheet values: ${errText}`);
  }

  // 4. Batch update formatting (Styling, Colors, Fonts, Borders, Column Widths)
  const requests: any[] = [
    // Column widths
    {
      updateDimensionProperties: {
        range: {
          sheetId,
          dimension: 'COLUMNS',
          startIndex: 0,
          endIndex: 1,
        },
        properties: { pixelSize: 320 },
        fields: 'pixelSize',
      },
    },
    {
      updateDimensionProperties: {
        range: {
          sheetId,
          dimension: 'COLUMNS',
          startIndex: 1,
          endIndex: 2,
        },
        properties: { pixelSize: 180 },
        fields: 'pixelSize',
      },
    },
    {
      updateDimensionProperties: {
        range: {
          sheetId,
          dimension: 'COLUMNS',
          startIndex: 2,
          endIndex: 3,
        },
        properties: { pixelSize: 150 },
        fields: 'pixelSize',
      },
    },
    // Main Title Formatting (Row 0)
    {
      repeatCell: {
        range: { sheetId, startRowIndex: 0, endRowIndex: 1, startColumnIndex: 0, endColumnIndex: 3 },
        cell: {
          userEnteredFormat: {
            textFormat: { bold: true, fontSize: 16, foregroundColor: { red: 0.06, green: 0.09, blue: 0.16 } },
          },
        },
        fields: 'userEnteredFormat(textFormat)',
      },
    },
    // Subtitle (Row 1)
    {
      repeatCell: {
        range: { sheetId, startRowIndex: 1, endRowIndex: 2, startColumnIndex: 0, endColumnIndex: 3 },
        cell: {
          userEnteredFormat: {
            textFormat: { bold: true, fontSize: 11, foregroundColor: { red: 0.3, green: 0.35, blue: 0.45 } },
          },
        },
        fields: 'userEnteredFormat(textFormat)',
      },
    },
    // Metadata (Row 2)
    {
      repeatCell: {
        range: { sheetId, startRowIndex: 2, endRowIndex: 3, startColumnIndex: 0, endColumnIndex: 3 },
        cell: {
          userEnteredFormat: {
            textFormat: { italic: true, fontSize: 10, foregroundColor: { red: 0.4, green: 0.4, blue: 0.4 } },
          },
        },
        fields: 'userEnteredFormat(textFormat)',
      },
    },
    // Format Numbers in Column B (Index 1) as Currency / Integer with commas
    {
      repeatCell: {
        range: { sheetId, startRowIndex: 4, endRowIndex: values.length, startColumnIndex: 1, endColumnIndex: 2 },
        cell: {
          userEnteredFormat: {
            numberFormat: { type: 'NUMBER', pattern: '#,##0' },
            horizontalAlignment: 'RIGHT',
          },
        },
        fields: 'userEnteredFormat(numberFormat,horizontalAlignment)',
      },
    },
  ];

  // Apply Section Header formatting
  values.forEach((row, idx) => {
    const text = row[0]?.toString() || '';
    if (text.startsWith('A.') || text.startsWith('B.') || text.startsWith('C.') || text.startsWith('D.')) {
      requests.push({
        repeatCell: {
          range: { sheetId, startRowIndex: idx, endRowIndex: idx + 1, startColumnIndex: 0, endColumnIndex: 3 },
          cell: {
            userEnteredFormat: {
              backgroundColor: { red: 0.06, green: 0.09, blue: 0.16 }, // Slate 900 #0F172A
              textFormat: { bold: true, fontSize: 11, foregroundColor: { red: 1, green: 1, blue: 1 } },
            },
          },
          fields: 'userEnteredFormat(backgroundColor,textFormat)',
        },
      });
    } else if (text.startsWith('TOTAL')) {
      requests.push({
        repeatCell: {
          range: { sheetId, startRowIndex: idx, endRowIndex: idx + 1, startColumnIndex: 0, endColumnIndex: 3 },
          cell: {
            userEnteredFormat: {
              backgroundColor: { red: 0.89, green: 0.91, blue: 0.94 }, // Slate 200 #E2E8F0
              textFormat: { bold: true, fontSize: 10, foregroundColor: { red: 0.06, green: 0.09, blue: 0.16 } },
            },
          },
          fields: 'userEnteredFormat(backgroundColor,textFormat)',
        },
      });
    }
  });

  await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ requests }),
  });

  const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}`;
  return { spreadsheetId, spreadsheetUrl };
}

/**
 * Creates and formats a Google Spreadsheet for a Category Ledger
 */
export async function exportCategoryLedgerToGoogleSheets(
  categoryName: string,
  type: string,
  rows: { sl: number | string; date: string; voucherNo: string; account: string; remarks: string; amount: number; runningBalance: number }[],
  subtotal: number,
  runningTotal: number
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  const accessToken = await ensureAccessToken();

  const values: (string | number)[][] = [
    ['GMP FASHIONS LTD.'],
    [`CATEGORY LEDGER STATEMENT: ${categoryName.toUpperCase()} (${type.toUpperCase()})`],
    [`Total Entries: ${rows.length} | Category Subtotal: BDT ${Math.round(subtotal)}`],
    [],
    ['SL#', 'Date', 'Voucher No', 'Account / Bank', 'Remarks / Particulars', 'Amount (BDT)', 'Running Balance (BDT)'],
  ];

  rows.forEach((r) => {
    values.push([r.sl, r.date, r.voucherNo, r.account, r.remarks, Math.round(r.amount), Math.round(r.runningBalance)]);
  });

  values.push([]);
  values.push(['-', '-', '-', '-', `TOTAL (${categoryName.toUpperCase()}):`, Math.round(subtotal), Math.round(runningTotal)]);

  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: `Category Ledger - ${categoryName} (${new Date().toLocaleDateString('en-GB')})`,
      },
      sheets: [{ properties: { title: 'Category Ledger' } }],
    }),
  });

  if (!createRes.ok) {
    throw new Error('Failed to create Category Ledger Google Sheet.');
  }

  const sheetData = await createRes.json();
  const spreadsheetId = sheetData.spreadsheetId;
  const sheetId = sheetData.sheets[0].properties.sheetId;

  await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/'Category Ledger'!A1?valueInputOption=USER_ENTERED`, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ values }),
  });

  // Apply header & row styling
  const requests: any[] = [
    {
      repeatCell: {
        range: { sheetId, startRowIndex: 4, endRowIndex: 5, startColumnIndex: 0, endColumnIndex: 7 },
        cell: {
          userEnteredFormat: {
            backgroundColor: { red: 0.06, green: 0.09, blue: 0.16 },
            textFormat: { bold: true, fontSize: 10, foregroundColor: { red: 1, green: 1, blue: 1 } },
          },
        },
        fields: 'userEnteredFormat(backgroundColor,textFormat)',
      },
    },
    // Zebra row striping
    ...rows.map((_, idx) => ({
      repeatCell: {
        range: { sheetId, startRowIndex: 5 + idx, endRowIndex: 6 + idx, startColumnIndex: 0, endColumnIndex: 7 },
        cell: {
          userEnteredFormat: {
            backgroundColor: idx % 2 === 1 ? { red: 0.97, green: 0.98, blue: 0.99 } : { red: 1, green: 1, blue: 1 },
          },
        },
        fields: 'userEnteredFormat(backgroundColor)',
      },
    })),
    // Total row style
    {
      repeatCell: {
        range: { sheetId, startRowIndex: values.length - 1, endRowIndex: values.length, startColumnIndex: 0, endColumnIndex: 7 },
        cell: {
          userEnteredFormat: {
            backgroundColor: { red: 0.89, green: 0.91, blue: 0.94 },
            textFormat: { bold: true },
          },
        },
        fields: 'userEnteredFormat(backgroundColor,textFormat)',
      },
    },
  ];

  await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ requests }),
  });

  return { spreadsheetId, spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}` };
}
