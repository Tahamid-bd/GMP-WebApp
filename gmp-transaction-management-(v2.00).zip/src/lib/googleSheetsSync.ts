import { getAccessToken, googleSignIn } from './googleAuth';
import { Transaction, TransactionType, TransactionMode, AccountOpeningBalance } from '../types';

export const LOCAL_STORAGE_SYNC_SHEET_ID_KEY = 'google_sync_spreadsheet_id_v1';
export const LOCAL_STORAGE_AUTO_SYNC_ENABLED_KEY = 'google_auto_sync_enabled_v1';
export const LOCAL_STORAGE_LAST_SYNC_TIME_KEY = 'google_last_sync_time_v1';

export interface SyncConfig {
  spreadsheetId: string | null;
  spreadsheetUrl: string | null;
  autoSyncEnabled: boolean;
  lastSyncTime: string | null;
}

export async function ensureAccessToken(): Promise<string> {
  let token = await getAccessToken();
  if (!token) {
    const res = await googleSignIn();
    if (!res?.accessToken) {
      throw new Error('Please sign in with Google to sync with Google Sheets.');
    }
    token = res.accessToken;
  }
  return token;
}

export function getStoredSyncConfig(): SyncConfig {
  const spreadsheetId = localStorage.getItem(LOCAL_STORAGE_SYNC_SHEET_ID_KEY);
  const autoSyncEnabled = localStorage.getItem(LOCAL_STORAGE_AUTO_SYNC_ENABLED_KEY) === 'true';
  const lastSyncTime = localStorage.getItem(LOCAL_STORAGE_LAST_SYNC_TIME_KEY);
  return {
    spreadsheetId,
    spreadsheetUrl: spreadsheetId ? `https://docs.google.com/spreadsheets/d/${spreadsheetId}` : null,
    autoSyncEnabled,
    lastSyncTime,
  };
}

export function saveSyncConfig(config: Partial<SyncConfig>) {
  if (config.spreadsheetId !== undefined) {
    if (config.spreadsheetId) {
      localStorage.setItem(LOCAL_STORAGE_SYNC_SHEET_ID_KEY, config.spreadsheetId);
    } else {
      localStorage.removeItem(LOCAL_STORAGE_SYNC_SHEET_ID_KEY);
    }
  }
  if (config.autoSyncEnabled !== undefined) {
    localStorage.setItem(LOCAL_STORAGE_AUTO_SYNC_ENABLED_KEY, config.autoSyncEnabled ? 'true' : 'false');
  }
  if (config.lastSyncTime !== undefined) {
    if (config.lastSyncTime) {
      localStorage.setItem(LOCAL_STORAGE_LAST_SYNC_TIME_KEY, config.lastSyncTime);
    } else {
      localStorage.removeItem(LOCAL_STORAGE_LAST_SYNC_TIME_KEY);
    }
  }
}

/**
 * Ensures existing or new spreadsheet has Transactions, Categories, and Bank Accounts tabs
 */
export async function getOrCreateSyncSpreadsheet(
  customSheetId?: string
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  const accessToken = await ensureAccessToken();

  let targetSpreadsheetId: string | null = null;

  if (customSheetId && customSheetId.trim()) {
    targetSpreadsheetId = customSheetId.trim();
  } else {
    const storedId = localStorage.getItem(LOCAL_STORAGE_SYNC_SHEET_ID_KEY);
    if (storedId) targetSpreadsheetId = storedId;
  }

  if (targetSpreadsheetId) {
    const checkRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${targetSpreadsheetId}`, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    if (checkRes.ok) {
      const sheetInfo = await checkRes.json();
      const existingTitles: string[] = sheetInfo.sheets?.map((s: any) => s.properties.title) || [];

      // Check if missing 'Categories' or 'Bank Accounts' sheets
      const requestsToBatch: any[] = [];
      if (!existingTitles.includes('Categories')) {
        requestsToBatch.push({
          addSheet: { properties: { title: 'Categories', gridProperties: { frozenRowCount: 1 } } },
        });
      }
      if (!existingTitles.includes('Bank Accounts')) {
        requestsToBatch.push({
          addSheet: { properties: { title: 'Bank Accounts', gridProperties: { frozenRowCount: 1 } } },
        });
      }

      if (requestsToBatch.length > 0) {
        await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${targetSpreadsheetId}:batchUpdate`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ requests: requestsToBatch }),
        });
      }

      saveSyncConfig({ spreadsheetId: targetSpreadsheetId });
      return {
        spreadsheetId: targetSpreadsheetId,
        spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${targetSpreadsheetId}`,
      };
    }
  }

  // Create new Spreadsheet with 3 tabs: Transactions, Categories, Bank Accounts
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: `GMP Fashions Ltd - Financial Ledger & Register`,
      },
      sheets: [
        { properties: { title: 'Transactions', gridProperties: { frozenRowCount: 1 } } },
        { properties: { title: 'Categories', gridProperties: { frozenRowCount: 1 } } },
        { properties: { title: 'Bank Accounts', gridProperties: { frozenRowCount: 1 } } },
      ],
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(`Failed to create Google Sheet for sync: ${errText}`);
  }

  const sheetData = await createRes.json();
  const spreadsheetId = sheetData.spreadsheetId;

  // Add initial headers for all tabs
  const batchValueData = [
    {
      range: 'Transactions!A1:K1',
      values: [
        [
          'Transaction ID',
          'Entry Date',
          'Voucher No',
          'Type',
          'Category',
          'Mode',
          'Withdrawn Bank / Cheque No',
          'Deposited Bank / Particulars',
          'Amount (BDT)',
          'Remarks',
          'Last Updated',
        ],
      ],
    },
    {
      range: 'Categories!A1:C1',
      values: [['Category Name', 'Type (Receipts / Expenses / Contra)', 'Last Updated']],
    },
    {
      range: 'Bank Accounts!A1:D1',
      values: [['Account ID', 'Account Name', 'Opening Balance (BDT)', 'Last Updated']],
    },
  ];

  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        valueInputOption: 'USER_ENTERED',
        data: batchValueData,
      }),
    }
  );

  saveSyncConfig({ spreadsheetId });
  return {
    spreadsheetId,
    spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}`,
  };
}

/**
 * Push Transactions to Google Sheet
 */
export async function pushTransactionsToSheet(
  spreadsheetId: string,
  transactions: Transaction[]
): Promise<void> {
  const token = await getAccessToken();
  if (!token) return;

  const headerRow = [
    'Transaction ID',
    'Entry Date',
    'Voucher No',
    'Type',
    'Category',
    'Mode',
    'Withdrawn Bank / Cheque No',
    'Deposited Bank / Particulars',
    'Amount (BDT)',
    'Remarks',
    'Last Updated',
  ];

  const dataRows = transactions.map((t) => [
    t.id,
    t.entryDate || '',
    t.voucherNo || '',
    t.type || 'Receipts',
    t.category || '',
    t.mode || 'Bank',
    t.withdrawnBank || '',
    t.depositedBank || '',
    Math.round(t.amount || 0),
    t.remarks || '',
    new Date(t.createdAt || Date.now()).toISOString(),
  ]);

  const allValues = [headerRow, ...dataRows];

  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Transactions!A1:K2000:clear`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    }
  );

  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Transactions!A1?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ values: allValues }),
    }
  );

  saveSyncConfig({
    lastSyncTime: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
  });
}

/**
 * Push Categories tab
 */
export async function pushCategoriesToSheet(
  spreadsheetId: string,
  categories: { type: TransactionType; name: string }[]
): Promise<void> {
  const token = await getAccessToken();
  if (!token) return;

  const header = ['Category Name', 'Type (Receipts / Expenses / Contra)', 'Last Updated'];
  const rows = categories.map((c) => [c.name, c.type, new Date().toISOString()]);
  const allValues = [header, ...rows];

  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Categories!A1:C500:clear`,
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    }
  );

  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Categories!A1?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ values: allValues }),
    }
  );
}

/**
 * Push Bank Accounts tab
 */
export async function pushAccountsToSheet(
  spreadsheetId: string,
  accounts: AccountOpeningBalance[]
): Promise<void> {
  const token = await getAccessToken();
  if (!token) return;

  const header = ['Account ID', 'Account Name', 'Opening Balance (BDT)', 'Last Updated'];
  const rows = accounts.map((a) => [a.id, a.name, a.amount || 0, new Date().toISOString()]);
  const allValues = [header, ...rows];

  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Bank Accounts!A1:D200:clear`,
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    }
  );

  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Bank Accounts!A1?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ values: allValues }),
    }
  );
}

/**
 * Pull Transactions from Sheet
 */
export async function pullTransactionsFromSheet(spreadsheetId: string): Promise<Transaction[]> {
  const token = await getAccessToken();
  if (!token) return [];

  const getRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Transactions!A2:K2000`,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  if (!getRes.ok) return [];

  const data = await getRes.json();
  const rows: any[][] = data.values || [];

  const pulledTransactions: Transaction[] = [];

  rows.forEach((row, idx) => {
    if (!row || row.length === 0) return;

    const rawId = row[0]?.toString().trim();
    const rawDate = row[1]?.toString().trim();
    const rawVoucher = row[2]?.toString().trim();
    const rawType = row[3]?.toString().trim();
    const rawCategory = row[4]?.toString().trim();
    const rawMode = row[5]?.toString().trim();
    const rawWithdrawn = row[6]?.toString().trim();
    const rawDeposited = row[7]?.toString().trim();
    const rawAmount = parseFloat(row[8]?.toString().replace(/,/g, '') || '0');
    const rawRemarks = row[9]?.toString().trim();
    const rawUpdated = row[10]?.toString().trim();

    if (!rawDate && !rawAmount && !rawCategory) return;

    let type: TransactionType = 'Receipts';
    if (rawType) {
      const lower = rawType.toLowerCase();
      if (lower.includes('exp') || lower.includes('pay')) type = 'Expenses';
      else if (lower.includes('contra')) type = 'Contra';
    }

    let mode: TransactionMode = 'Bank';
    if (rawMode) {
      if (rawMode.includes('Cash')) mode = 'Cash';
      else if (rawMode.includes('Bank→Cash')) mode = 'Bank→Cash';
      else if (rawMode.includes('Cash→Bank')) mode = 'Cash→Bank';
      else if (rawMode.includes('Bank→Bank')) mode = 'Bank→Bank';
    }

    const tnxId = rawId || `tnx-sheet-${Date.now()}-${idx}`;
    const createdAt = rawUpdated ? new Date(rawUpdated).getTime() : Date.now() - idx * 1000;

    pulledTransactions.push({
      id: tnxId,
      entryDate: rawDate || new Date().toISOString().split('T')[0],
      voucherNo: rawVoucher || `V-${1000 + idx}`,
      type,
      category: rawCategory || (type === 'Receipts' ? 'Sales Revenue' : 'Office Expenses'),
      mode,
      withdrawnBank: rawWithdrawn || 'N/A',
      depositedBank: rawDeposited || 'N/A',
      amount: isNaN(rawAmount) ? 0 : rawAmount,
      remarks: rawRemarks || '',
      createdAt: isNaN(createdAt) ? Date.now() : createdAt,
    });
  });

  return pulledTransactions;
}

/**
 * Pull Categories from Sheet
 */
export async function pullCategoriesFromSheet(
  spreadsheetId: string
): Promise<{ type: TransactionType; name: string }[]> {
  const token = await getAccessToken();
  if (!token) return [];

  const getRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Categories!A2:C500`,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  if (!getRes.ok) return [];

  const data = await getRes.json();
  const rows: any[][] = data.values || [];
  const pulledCats: { type: TransactionType; name: string }[] = [];

  rows.forEach((row) => {
    if (!row || !row[0]) return;
    const catName = row[0].toString().trim();
    const rawType = row[1]?.toString().trim() || 'Receipts';

    let type: TransactionType = 'Receipts';
    if (rawType.toLowerCase().includes('exp')) type = 'Expenses';
    else if (rawType.toLowerCase().includes('contra')) type = 'Contra';

    if (catName) {
      pulledCats.push({ name: catName, type });
    }
  });

  return pulledCats;
}

/**
 * Pull Bank Accounts from Sheet
 */
export async function pullAccountsFromSheet(
  spreadsheetId: string
): Promise<AccountOpeningBalance[]> {
  const token = await getAccessToken();
  if (!token) return [];

  const getRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Bank Accounts!A2:D200`,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  if (!getRes.ok) return [];

  const data = await getRes.json();
  const rows: any[][] = data.values || [];
  const pulledAccs: AccountOpeningBalance[] = [];

  rows.forEach((row, idx) => {
    if (!row || !row[1]) return;
    const id = row[0]?.toString().trim() || `acc-${Date.now()}-${idx}`;
    const name = row[1].toString().trim();
    const amount = parseFloat(row[2]?.toString().replace(/,/g, '') || '0');

    if (name) {
      pulledAccs.push({
        id,
        name,
        amount: isNaN(amount) ? 0 : amount,
      });
    }
  });

  return pulledAccs;
}

/**
 * Performs full bi-directional sync for Transactions, Categories, AND Bank Accounts
 */
export async function performFullSync(
  currentLocalTransactions: Transaction[],
  currentCategories: { type: TransactionType; name: string }[] = [],
  currentAccounts: AccountOpeningBalance[] = []
): Promise<{
  mergedTransactions: Transaction[];
  mergedCategories: { type: TransactionType; name: string }[];
  mergedAccounts: AccountOpeningBalance[];
  spreadsheetId: string;
  spreadsheetUrl: string;
}> {
  // 1. Get or create spreadsheet with 3 tabs
  const { spreadsheetId, spreadsheetUrl } = await getOrCreateSyncSpreadsheet();

  // 2. Pull from all 3 tabs
  const sheetTransactions = await pullTransactionsFromSheet(spreadsheetId);
  const sheetCategories = await pullCategoriesFromSheet(spreadsheetId);
  const sheetAccounts = await pullAccountsFromSheet(spreadsheetId);

  // 3. Merge Transactions
  const localTnxMap = new Map<string, Transaction>();
  currentLocalTransactions.forEach((t) => localTnxMap.set(t.id, t));

  const mergedTransactionsList: Transaction[] = [...currentLocalTransactions];
  sheetTransactions.forEach((st) => {
    if (localTnxMap.has(st.id)) {
      const idx = mergedTransactionsList.findIndex((t) => t.id === st.id);
      if (idx !== -1) mergedTransactionsList[idx] = { ...mergedTransactionsList[idx], ...st };
    } else {
      mergedTransactionsList.unshift(st);
    }
  });
  mergedTransactionsList.sort((a, b) => new Date(b.entryDate).getTime() - new Date(a.entryDate).getTime());

  // Merge Categories
  const catSet = new Set<string>(currentCategories.map((c) => `${c.type}:${c.name.toLowerCase()}`));
  const mergedCategoriesList = [...currentCategories];
  sheetCategories.forEach((sc) => {
    const key = `${sc.type}:${sc.name.toLowerCase()}`;
    if (!catSet.has(key)) {
      catSet.add(key);
      mergedCategoriesList.push(sc);
    }
  });

  // Merge Bank Accounts
  const accMap = new Map<string, AccountOpeningBalance>();
  currentAccounts.forEach((a) => accMap.set(a.name.toLowerCase(), a));
  const mergedAccountsList = [...currentAccounts];
  sheetAccounts.forEach((sa) => {
    if (!accMap.has(sa.name.toLowerCase())) {
      accMap.set(sa.name.toLowerCase(), sa);
      mergedAccountsList.push(sa);
    }
  });

  // 4. Push merged states back to all 3 tabs
  await pushTransactionsToSheet(spreadsheetId, mergedTransactionsList);
  await pushCategoriesToSheet(spreadsheetId, mergedCategoriesList);
  await pushAccountsToSheet(spreadsheetId, mergedAccountsList);

  saveSyncConfig({
    spreadsheetId,
    lastSyncTime: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
  });

  return {
    mergedTransactions: mergedTransactionsList,
    mergedCategories: mergedCategoriesList,
    mergedAccounts: mergedAccountsList,
    spreadsheetId,
    spreadsheetUrl,
  };
}
