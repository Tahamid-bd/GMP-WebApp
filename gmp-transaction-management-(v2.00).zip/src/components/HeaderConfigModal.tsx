import React, { useState, useEffect } from 'react';
import { Settings, Heading, X, Check, Upload, Image as ImageIcon, Link as LinkIcon } from 'lucide-react';

export interface HeaderConfig {
  title: string;
  subtitle: string;
  logoUrl: string;
  isEnabled: boolean;
}

interface HeaderConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  headerConfig: HeaderConfig;
  onSave: (config: HeaderConfig) => void;
}

export const HeaderConfigModal: React.FC<HeaderConfigModalProps> = ({
  isOpen,
  onClose,
  headerConfig,
  onSave,
}) => {
  const [title, setTitle] = useState(headerConfig.title);
  const [subtitle, setSubtitle] = useState(headerConfig.subtitle);
  const [logoUrl, setLogoUrl] = useState(headerConfig.logoUrl);
  const [isEnabled, setIsEnabled] = useState(headerConfig.isEnabled);
  const [logoFileError, setLogoFileError] = useState('');

  // Keep modal inputs in sync with incoming headerConfig whenever modal opens
  useEffect(() => {
    if (isOpen) {
      setTitle(headerConfig.title);
      setSubtitle(headerConfig.subtitle);
      setLogoUrl(headerConfig.logoUrl);
      setIsEnabled(headerConfig.isEnabled);
      setLogoFileError('');
    }
  }, [isOpen, headerConfig]);

  if (!isOpen) return null;

  const handleLogoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      setLogoFileError('Logo image size must be less than 2MB');
      return;
    }
    setLogoFileError('');

    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        setLogoUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    onSave({
      title: title.trim(),
      subtitle: subtitle.trim(),
      logoUrl: logoUrl.trim(),
      isEnabled,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-md w-full p-5 space-y-4 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center space-x-2">
            <Heading className="h-5 w-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 text-base">Configure Report Header</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="space-y-3.5 text-xs">
          
          {/* Header Toggle */}
          <label className="flex items-center space-x-2.5 p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer">
            <input
              type="checkbox"
              checked={isEnabled}
              onChange={(e) => setIsEnabled(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
            />
            <span className="font-semibold text-slate-800">
              Include Header & Subtitle in Reports (Prints & Excel)
            </span>
          </label>

          {/* Header Title Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Header Name / Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              disabled={!isEnabled}
              placeholder="e.g. Transaction Register Ledger Report"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-800 font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden disabled:bg-slate-100 disabled:opacity-60"
            />
          </div>

          {/* Header Subtitle Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Header Subtitle
            </label>
            <input
              type="text"
              value={subtitle}
              onChange={(e) => setSubtitle(e.target.value)}
              disabled={!isEnabled}
              placeholder="e.g. Bank & Cash Ledger Statement"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-800 font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden disabled:bg-slate-100 disabled:opacity-60"
            />
          </div>

          {/* Logo Upload Section */}
          <div className="pt-2 border-t border-slate-100">
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
              <span className="flex items-center space-x-1">
                <ImageIcon className="h-3.5 w-3.5 text-indigo-600" />
                <span>Header Logo (Optional)</span>
              </span>
              {logoUrl && (
                <button
                  type="button"
                  onClick={() => setLogoUrl('')}
                  className="text-[11px] text-rose-600 hover:underline font-semibold cursor-pointer"
                >
                  Remove Logo
                </button>
              )}
            </label>

            {/* Logo Preview */}
            {logoUrl && (
              <div className="flex items-center space-x-3 p-2 bg-slate-50 border border-slate-200 rounded-xl mb-2">
                <img
                  src={logoUrl}
                  alt="Logo Preview"
                  className="h-10 max-w-[120px] object-contain rounded bg-white p-1 border border-slate-200"
                />
                <div className="text-[11px] text-slate-600">
                  <p className="font-semibold text-slate-800">Logo Uploaded</p>
                  <p className="text-[10px] text-slate-500">Will render beside header in reports</p>
                </div>
              </div>
            )}

            {/* File Upload or URL input */}
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <label className="flex-1 flex items-center justify-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-medium text-xs transition-colors cursor-pointer">
                  <Upload className="h-3.5 w-3.5" />
                  <span>Upload Logo Image</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoFileUpload}
                    disabled={!isEnabled}
                    className="hidden"
                  />
                </label>
              </div>
              {logoFileError && (
                <p className="text-[11px] text-rose-600 font-medium">{logoFileError}</p>
              )}

              <div className="relative">
                <input
                  type="text"
                  value={logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                  disabled={!isEnabled}
                  placeholder="Or enter logo image URL (https://...)"
                  className="w-full pl-7 pr-3 py-1.5 rounded-lg border border-slate-300 text-slate-800 text-[11px] font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden disabled:bg-slate-100 disabled:opacity-60"
                />
                <LinkIcon className="h-3.5 w-3.5 text-slate-400 absolute left-2 top-2" />
              </div>
            </div>
          </div>

        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end space-x-2 border-t border-slate-100 pt-3">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-xs transition-colors flex items-center space-x-1.5 cursor-pointer"
          >
            <Check className="h-3.5 w-3.5" />
            <span>Save Header Config</span>
          </button>
        </div>

      </div>
    </div>
  );
};
