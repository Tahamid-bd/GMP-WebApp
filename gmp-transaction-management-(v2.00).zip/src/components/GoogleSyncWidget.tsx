import React, { useState, useEffect } from 'react';
import { RefreshCw, FileSpreadsheet, ExternalLink, Settings, CheckCircle2, AlertCircle, ToggleLeft, ToggleRight, Sparkles, Trash2 } from 'lucide-react';
import { User } from 'firebase/auth';
import { initAuth, googleSignIn } from '../lib/googleAuth';
import {
  getStoredSyncConfig,
  saveSyncConfig,
  performFullSync,
  getOrCreateSyncSpreadsheet,
} from '../lib/googleSheetsSync';
import { Transaction, TransactionType, AccountOpeningBalance } from '../types';

interface GoogleSyncWidgetProps {
  transactions: Transaction[];
  categories?: { type: TransactionType; name: string }[];
  accounts?: AccountOpeningBalance[];
  onTransactionsUpdated: (newTransactions: Transaction[]) => void;
  onCategoriesUpdated?: (newCategories: { type: TransactionType; name: string }[]) => void;
  onAccountsUpdated?: (newAccounts: AccountOpeningBalance[]) => void;
  onOpenTrashBin?: () => void;
  trashCount?: number;
}

export const GoogleSyncWidget: React.FC<GoogleSyncWidgetProps> = ({
  transactions,
  categories = [],
  accounts = [],
  onTransactionsUpdated,
  onCategoriesUpdated,
  onAccountsUpdated,
  onOpenTrashBin,
  trashCount = 0,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [syncConfig, setSyncConfig] = useState(getStoredSyncConfig());
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isCustomSheetModalOpen, setIsCustomSheetModalOpen] = useState(false);
  const [inputSheetId, setInputSheetId] = useState('');

  // Track auth state
  useEffect(() => {
    const unsubscribe = initAuth(
      (u) => setUser(u),
      () => setUser(null)
    );
    return () => unsubscribe();
  }, []);

  // Update local state when stored config changes
  useEffect(() => {
    setSyncConfig(getStoredSyncConfig());
  }, []);

  // Handle Manual Trigger / Perform Full Sync across all 3 sheet tabs
  const handleSyncNow = async () => {
    try {
      setIsSyncing(true);
      setErrorMsg(null);
      setSyncStatusMsg('Syncing Transactions, Categories & Bank Accounts with Google Sheets...');

      if (!user) {
        const authRes = await googleSignIn();
        if (!authRes?.user) {
          throw new Error('Sign in required to sync with Google Sheets.');
        }
        setUser(authRes.user);
      }

      const { mergedTransactions, mergedCategories, mergedAccounts } = await performFullSync(
        transactions,
        categories,
        accounts
      );

      onTransactionsUpdated(mergedTransactions);
      if (onCategoriesUpdated && mergedCategories) onCategoriesUpdated(mergedCategories);
      if (onAccountsUpdated && mergedAccounts) onAccountsUpdated(mergedAccounts);

      const updatedConfig = getStoredSyncConfig();
      setSyncConfig(updatedConfig);

      setSyncStatusMsg(`Successfully synchronized all 3 tabs (Transactions, Categories, Bank Accounts) with Google Sheets!`);
      setTimeout(() => setSyncStatusMsg(null), 5000);
    } catch (err: any) {
      console.error('Google Sheets Sync Error:', err);
      setErrorMsg(err.message || 'Failed to sync with Google Sheets');
    } finally {
      setIsSyncing(false);
    }
  };

  // Toggle Auto Sync On/Off
  const handleToggleAutoSync = () => {
    const nextState = !syncConfig.autoSyncEnabled;
    saveSyncConfig({ autoSyncEnabled: nextState });
    setSyncConfig(getStoredSyncConfig());
  };

  // Save Custom Sheet ID
  const handleSaveCustomSheetId = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputSheetId.trim()) return;

    try {
      setIsSyncing(true);
      setErrorMsg(null);
      const res = await getOrCreateSyncSpreadsheet(inputSheetId.trim());
      saveSyncConfig({ spreadsheetId: res.spreadsheetId });
      setSyncConfig(getStoredSyncConfig());
      setIsCustomSheetModalOpen(false);
      setInputSheetId('');

      // Perform sync to test
      await handleSyncNow();
    } catch (err: any) {
      setErrorMsg(err.message || 'Invalid Spreadsheet ID or permission denied.');
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white rounded-xl p-4 shadow-md border border-slate-700/80 mb-4 transition-all">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        
        {/* Left Side: Header & Connected Sheet info */}
        <div className="flex items-center space-x-3.5">
          <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl shrink-0">
            <FileSpreadsheet className="h-6 w-6 text-emerald-400" />
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-sm font-bold tracking-tight text-slate-100">
                Google Sheets Multi-Tab Real-time Auto Sync
              </h3>
              <span className="px-2 py-0.5 text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full flex items-center space-x-1">
                <Sparkles className="h-2.5 w-2.5" />
                <span>3 Tabs Sync (Transactions, Categories, Banks)</span>
              </span>
            </div>

            <p className="text-xs text-slate-300 mt-0.5">
              {user ? (
                <>
                  Connected as <span className="text-emerald-300 font-medium">{user.email}</span>
                  {syncConfig.lastSyncTime && (
                    <span className="ml-2 text-slate-400">
                      • Last synced: <span className="text-slate-200">{syncConfig.lastSyncTime}</span>
                    </span>
                  )}
                </>
              ) : (
                'Connect Google account to enable auto sync to Google Sheet & auto load sheet data into app'
              )}
            </p>
          </div>
        </div>

        {/* Right Side: Action Controls */}
        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-end">
          
          {/* Recycle Bin Button with Trash Badge */}
          {onOpenTrashBin && (
            <button
              type="button"
              onClick={onOpenTrashBin}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-950/60 border border-rose-500/40 hover:bg-rose-900/80 text-rose-200 flex items-center space-x-1.5 transition-all cursor-pointer"
              title="Open Recycle Bin to view or restore deleted items"
            >
              <Trash2 className="h-4 w-4 text-rose-400" />
              <span>Recycle Bin</span>
              {trashCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 text-[10px] font-extrabold bg-rose-500 text-white rounded-full">
                  {trashCount}
                </span>
              )}
            </button>
          )}

          {/* Auto Sync Toggle */}
          <button
            type="button"
            onClick={handleToggleAutoSync}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-2 border transition-all cursor-pointer ${
              syncConfig.autoSyncEnabled
                ? 'bg-emerald-900/50 text-emerald-300 border-emerald-500/40 hover:bg-emerald-800/60'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
            title="Toggle live auto-sync whenever transactions or categories are edited or added"
          >
            {syncConfig.autoSyncEnabled ? (
              <>
                <ToggleRight className="h-4 w-4 text-emerald-400" />
                <span>Auto Sync: ON</span>
              </>
            ) : (
              <>
                <ToggleLeft className="h-4 w-4 text-slate-400" />
                <span>Auto Sync: OFF</span>
              </>
            )}
          </button>

          {/* Sync Now Button */}
          <button
            type="button"
            onClick={handleSyncNow}
            disabled={isSyncing}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs rounded-lg shadow-sm transition-all flex items-center space-x-2 cursor-pointer active:scale-95"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Syncing...' : 'Sync Now'}</span>
          </button>

          {/* Link to Open Google Sheet */}
          {syncConfig.spreadsheetUrl && (
            <a
              href={syncConfig.spreadsheetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-xs font-medium text-slate-200 hover:text-white transition-all flex items-center space-x-1.5"
              title="Open connected Google Sheet in new tab"
            >
              <span>Open Sheet</span>
              <ExternalLink className="h-3 w-3 text-slate-400" />
            </a>
          )}

          {/* Connect Custom Sheet Settings */}
          <button
            type="button"
            onClick={() => setIsCustomSheetModalOpen(true)}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
            title="Configure / Link Existing Google Sheet ID"
          >
            <Settings className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Success Notification */}
      {syncStatusMsg && (
        <div className="mt-3 p-2.5 bg-emerald-950/80 border border-emerald-500/40 rounded-lg text-xs text-emerald-200 flex items-center space-x-2 animate-fade-in">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{syncStatusMsg}</span>
        </div>
      )}

      {/* Error Notification */}
      {errorMsg && (
        <div className="mt-3 p-2.5 bg-rose-950/80 border border-rose-500/40 rounded-lg text-xs text-rose-200 flex items-center space-x-2 animate-fade-in">
          <AlertCircle className="h-4 w-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Custom Sheet ID Modal */}
      {isCustomSheetModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl p-5 max-w-md w-full text-white shadow-xl">
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <FileSpreadsheet className="h-5 w-5 text-emerald-400" />
              <span>Link Google Sheet for Auto Sync</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Enter an existing Google Sheet ID (or URL) to sync data with, or leave blank to automatically create a dedicated sync spreadsheet with 3 tabs.
            </p>

            <form onSubmit={handleSaveCustomSheetId} className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Google Spreadsheet ID / URL:
                </label>
                <input
                  type="text"
                  placeholder="e.g. 1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms"
                  value={inputSheetId}
                  onChange={(e) => setInputSheetId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCustomSheetModalOpen(false)}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSyncing}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer disabled:opacity-50"
                >
                  {isSyncing ? 'Verifying...' : 'Link & Sync'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
