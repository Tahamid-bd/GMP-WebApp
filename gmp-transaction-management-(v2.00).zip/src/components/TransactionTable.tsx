import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { TransactionWithBalance } from '../types';
import { formatCurrency, formatDateForDisplay } from '../utils/finance';
import {
  Edit2,
  Trash2,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowRightLeft,
  ChevronLeft,
  ChevronRight,
  Printer,
  FileSpreadsheet,
  FileText,
  Settings,
  Heading,
  X,
  Check,
  Upload,
  Image as ImageIcon,
  Link as LinkIcon,
} from 'lucide-react';

interface HeaderConfigProp {
  title: string;
  subtitle: string;
  logoUrl: string;
  isEnabled: boolean;
}

interface TransactionTableProps {
  transactions: TransactionWithBalance[];
  headerConfig?: HeaderConfigProp;
  onEdit: (transaction: TransactionWithBalance) => void;
  onDelete: (id: string) => void;
  onOpenAddModal: () => void;
}

export const TransactionTable: React.FC<TransactionTableProps> = ({
  transactions,
  headerConfig,
  onEdit,
  onDelete,
  onOpenAddModal,
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(10);

  // Derived Header Config Props
  const headerTitle = headerConfig?.title ?? 'Transaction Register Ledger Report';
  const headerSubtitle = headerConfig?.subtitle ?? 'Bank & Cash Ledger Statement';
  const headerLogoUrl = headerConfig?.logoUrl ?? '';
  const isHeaderEnabled = headerConfig?.isEnabled ?? true;

  // Pagination calculations
  const effectiveItemsPerPage = itemsPerPage === -1 ? transactions.length || 1 : itemsPerPage;
  const totalPages = Math.ceil(transactions.length / effectiveItemsPerPage) || 1;

  // Ensure page is clamped when filter changes or items per page changes
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(1);
    }
  }, [currentPage, totalPages]);

  const startIndex = (currentPage - 1) * effectiveItemsPerPage;
  const currentItems = transactions.slice(
    startIndex,
    itemsPerPage === -1 ? transactions.length : startIndex + effectiveItemsPerPage
  );

  // Filtered total stats
  let filteredReceipts = 0;
  let filteredExpenses = 0;
  transactions.forEach((t) => {
    if (t.type === 'Receipts') filteredReceipts += t.amount;
    if (t.type === 'Expenses') filteredExpenses += t.amount;
  });

  // Action handlers
  const handlePrintOrPdf = (documentTitle: string = 'Transaction_Ledger_Report') => {
    const logoImgHtml = headerLogoUrl
      ? `<img src="${headerLogoUrl}" style="height: 50px; max-width: 150px; object-fit: contain; margin-right: 16px; border-radius: 4px;" alt="Logo" />`
      : '';

    const headerHtml = isHeaderEnabled
      ? `
        <div class="header">
          <div style="display: flex; align-items: center;">
            ${logoImgHtml}
            <div>
              <h1 class="title">${headerTitle}</h1>
              ${headerSubtitle ? `<p class="subtitle">${headerSubtitle}</p>` : ''}
              <p class="meta">Generated on ${new Date().toLocaleString()}</p>
            </div>
          </div>
          <div style="text-align: right;">
            <p style="margin: 0; font-weight: bold; color: #1e293b;">DEVELOPED BY TAHAMID</p>
            <p style="margin: 2px 0 0 0; color: #64748b;">Total Records: ${transactions.length}</p>
          </div>
        </div>
      `
      : '';

    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${documentTitle}</title>
          <style>
            @page { size: A4 landscape; margin: 12mm; }
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #1e293b; margin: 0; padding: 20px; font-size: 11px; }
            .header { border-bottom: 2px solid #1e293b; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; }
            .title { font-size: 20px; font-weight: bold; color: #0f172a; margin: 0; }
            .subtitle { font-size: 12px; color: #475569; font-weight: 500; margin-top: 4px; }
            .meta { font-size: 10px; color: #64748b; margin-top: 2px; }
            .summary-box { display: flex; gap: 24px; margin-bottom: 16px; background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px 18px; border-radius: 6px; }
            .summary-item { font-size: 12px; font-weight: 600; }
            .inflow { color: #047857; }
            .outflow { color: #be123c; }
            table { width: 100%; border-collapse: collapse; margin-top: 8px; }
            th { background-color: #1e293b; color: #ffffff; font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px; text-align: left; padding: 9px 10px; border-bottom: 2px solid #0f172a; }
            td { padding: 8px 10px; border-bottom: 1px solid #e2e8f0; text-align: left; }
            tr:nth-child(even) { background-color: #f8fafc; }
            .text-right { text-align: right; }
            .font-bold { font-weight: bold; }
            .amount-in { color: #047857; font-weight: 600; }
            .amount-out { color: #be123c; font-weight: 600; }
            .footer { margin-top: 20px; font-size: 10px; color: #94a3b8; text-align: right; }
          </style>
        </head>
        <body>
          ${headerHtml}
          <div class="summary-box">
            <div class="summary-item inflow">Total Inflow: +${formatCurrency(filteredReceipts)}</div>
            <div class="summary-item outflow">Total Outflow: -${formatCurrency(filteredExpenses)}</div>
            <div class="summary-item">Net Balance: ${formatCurrency(filteredReceipts - filteredExpenses)}</div>
          </div>
          <table>
            <thead>
              <tr>
                <th>Entry Date</th>
                <th>Voucher No</th>
                <th>Type</th>
                <th>Category</th>
                <th>Mode</th>
                <th>Withdrawn Bank</th>
                <th>Deposited Bank</th>
                <th class="text-right">Amount</th>
                <th class="text-right">Running Balance</th>
                <th>Remarks</th>
              </tr>
            </thead>
            <tbody>
              ${transactions
                .map(
                  (t, idx) => `
                <tr style="background-color: ${idx % 2 === 1 ? '#f8fafc' : '#ffffff'};">
                  <td>${formatDateForDisplay(t.entryDate)}</td>
                  <td class="font-bold">${t.voucherNo}</td>
                  <td>${t.type}</td>
                  <td>${t.category}</td>
                  <td>${t.mode}</td>
                  <td>${t.withdrawnBank}</td>
                  <td>${t.depositedBank}</td>
                  <td class="text-right ${
                    t.type === 'Receipts' ? 'amount-in' : t.type === 'Expenses' ? 'amount-out' : ''
                  }">${formatCurrency(t.amount)}</td>
                  <td class="text-right font-bold">${formatCurrency(t.balanceAmount)}</td>
                  <td>${t.remarks || '-'}</td>
                </tr>
              `
                )
                .join('')}
            </tbody>
          </table>
          <div class="footer">Confidential Financial Report — Total Entries: ${transactions.length}</div>
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
              }, 300);
            };
          </script>
        </body>
      </html>
    `;

    const printWin = window.open('', '_blank', 'width=1000,height=800');
    if (printWin) {
      printWin.document.open();
      printWin.document.write(printContent);
      printWin.document.close();
    } else {
      window.print();
    }
  };

  const handleExportExcel = () => {
    // Generate formatted HTML table inside an offscreen container for SheetJS parsing
    const logoExcelHtml = headerLogoUrl
      ? `<td style="vertical-align: middle; padding-right: 14px;"><img src="${headerLogoUrl}" height="48" style="display: block; max-width: 150px;" /></td>`
      : '';

    const headerBlock = isHeaderEnabled
      ? `
        <tr>
          <td colspan="10" style="padding-bottom: 12px;">
            <table style="border-collapse: collapse;">
              <tr>
                ${logoExcelHtml}
                <td style="vertical-align: middle;">
                  <div style="font-size: 16pt; font-weight: bold; color: #0f172a;">${headerTitle}</div>
                  ${
                    headerSubtitle
                      ? `<div style="font-size: 11pt; color: #475569; font-style: italic;">${headerSubtitle}</div>`
                      : ''
                  }
                  <div style="font-size: 9pt; color: #64748b; margin-top: 3px;">
                    Generated on: ${new Date().toLocaleString()} | Total Records: ${transactions.length} | DEVELOPED BY TAHAMID
                  </div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `
      : '';

    const excelContainer = document.createElement('div');
    excelContainer.style.display = 'none';
    excelContainer.innerHTML = `
      <table id="export-excel-table" style="border-collapse: collapse; font-family: sans-serif;">
        ${headerBlock}
        <tr>
          <td colspan="10" style="padding: 8px 0; font-size: 11pt;">
            <b>Total Inflow: +${formatCurrency(filteredReceipts)}</b> &nbsp;|&nbsp;
            <b>Total Outflow: -${formatCurrency(filteredExpenses)}</b> &nbsp;|&nbsp;
            <b>Net Balance: ${formatCurrency(filteredReceipts - filteredExpenses)}</b>
          </td>
        </tr>
        <thead>
          <tr style="background-color: #1e293b; color: #ffffff; font-weight: bold;">
            <th style="border: 1px solid #1e293b; padding: 8px;">Entry Date</th>
            <th style="border: 1px solid #1e293b; padding: 8px;">Voucher No</th>
            <th style="border: 1px solid #1e293b; padding: 8px;">Type</th>
            <th style="border: 1px solid #1e293b; padding: 8px;">Category</th>
            <th style="border: 1px solid #1e293b; padding: 8px;">Mode</th>
            <th style="border: 1px solid #1e293b; padding: 8px;">Withdrawn Bank</th>
            <th style="border: 1px solid #1e293b; padding: 8px;">Deposited Bank</th>
            <th style="border: 1px solid #1e293b; padding: 8px; text-align: right;">Amount</th>
            <th style="border: 1px solid #1e293b; padding: 8px; text-align: right;">Running Balance</th>
            <th style="border: 1px solid #1e293b; padding: 8px;">Remarks</th>
          </tr>
        </thead>
        <tbody>
          ${transactions
            .map(
              (t, idx) => `
            <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f1f5f9'};">
              <td style="border: 1px solid #cbd5e1; padding: 6px;">${formatDateForDisplay(t.entryDate)}</td>
              <td style="border: 1px solid #cbd5e1; padding: 6px; font-weight: bold;">${t.voucherNo}</td>
              <td style="border: 1px solid #cbd5e1; padding: 6px;">${t.type}</td>
              <td style="border: 1px solid #cbd5e1; padding: 6px;">${t.category}</td>
              <td style="border: 1px solid #cbd5e1; padding: 6px;">${t.mode}</td>
              <td style="border: 1px solid #cbd5e1; padding: 6px;">${t.withdrawnBank}</td>
              <td style="border: 1px solid #cbd5e1; padding: 6px;">${t.depositedBank}</td>
              <td style="border: 1px solid #cbd5e1; padding: 6px; text-align: right; color: ${
                t.type === 'Receipts' ? '#047857' : t.type === 'Expenses' ? '#be123c' : '#0f172a'
              }; font-weight: bold;">${formatCurrency(t.amount)}</td>
              <td style="border: 1px solid #cbd5e1; padding: 6px; text-align: right; font-weight: bold;">${formatCurrency(t.balanceAmount)}</td>
              <td style="border: 1px solid #cbd5e1; padding: 6px;">${t.remarks || '-'}</td>
            </tr>
          `
            )
            .join('')}
          <tr style="background-color: #e2e8f0; font-weight: bold;">
            <td colspan="7" style="border: 1px solid #cbd5e1; padding: 8px; text-align: right;">GRAND TOTAL:</td>
            <td style="border: 1px solid #cbd5e1; padding: 8px; text-align: right;">${formatCurrency(filteredReceipts - filteredExpenses)}</td>
            <td style="border: 1px solid #cbd5e1; padding: 8px; text-align: right;">
              ${
                transactions.length > 0
                  ? formatCurrency(transactions[transactions.length - 1].balanceAmount)
                  : '$0.00'
              }
            </td>
            <td style="border: 1px solid #cbd5e1; padding: 8px;"></td>
          </tr>
        </tbody>
      </table>
    `;

    document.body.appendChild(excelContainer);
    const tableEl = document.getElementById('export-excel-table');
    const ws = XLSX.utils.table_to_sheet(tableEl);
    document.body.removeChild(excelContainer);

    // Set Column Widths for horizontal spacing
    ws['!cols'] = [
      { wch: 14 },
      { wch: 15 },
      { wch: 12 },
      { wch: 22 },
      { wch: 12 },
      { wch: 18 },
      { wch: 18 },
      { wch: 15 },
      { wch: 18 },
      { wch: 28 },
    ];

    // Page setup for Horizontal Printing (Landscape + Fit to 1 page wide)
    ws['!pageSetup'] = {
      orientation: 'landscape',
      paperSize: 9, // A4
      fitToWidth: 1, // Fit horizontally to 1 page wide
      fitToHeight: 0, // auto height
      fitToPage: true, // enable fit to page logic
    };

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Transaction Ledger');

    // Save as .xlsx
    const fileName = `Transaction_Ledger_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(wb, fileName, { bookType: 'xlsx' });
  };

  return (
    <div className="space-y-3">
      {/* Action Toolbar & Data Show Control Section */}
      <div
        className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs print:hidden"
        style={{
          borderColor: '#284369',
          borderWidth: '1.8px',
        }}
      >
        {/* Action Buttons: Print, Export as Excel, Save as PDF */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => handlePrintOrPdf('Print_Transaction_Report')}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-medium flex items-center space-x-1.5 shadow-2xs transition-colors cursor-pointer"
            title="Print Table Data"
          >
            <Printer className="h-4 w-4 text-slate-300" />
            <span>Print</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="px-3.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-medium flex items-center space-x-1.5 shadow-2xs transition-colors cursor-pointer"
            title="Export formatted Excel with Zebra striping & Page Setup (.xlsx)"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-200" />
            <span>Export as Excel</span>
          </button>

          <button
            onClick={() => handlePrintOrPdf('Save_As_PDF_Transaction_Report')}
            className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-medium flex items-center space-x-1.5 shadow-2xs transition-colors cursor-pointer"
            title="Save as PDF"
          >
            <FileText className="h-4 w-4 text-indigo-200" />
            <span>Save as PDF</span>
          </button>

          {/* Summary Badges formatted like summary cards */}
          <div
            className="flex items-center gap-2 sm:ml-1"
            style={{
              marginLeft: '-26px',
            }}
          >
            <div
              className="px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-300/80 flex items-center space-x-1.5 shadow-2xs"
              style={{
                marginLeft: '26px',
                marginRight: '-24px',
                paddingTop: '15px',
                paddingBottom: '15px',
                paddingLeft: '28px',
                paddingRight: '50px',
              }}
            >
              <ArrowDownLeft className="h-3.5 w-3.5 text-emerald-600" />
              <span className="text-[11px] font-medium text-emerald-800">Inflow:</span>
              <strong className="text-xs font-bold text-emerald-700 tracking-tight">
                +{formatCurrency(filteredReceipts)}
              </strong>
            </div>

            <div
              className="px-3 py-1.5 rounded-lg bg-rose-50 border border-rose-300/80 flex items-center space-x-1.5 shadow-2xs"
              style={{
                marginLeft: '26px',
                marginTop: '0px',
                paddingLeft: '21px',
                paddingRight: '31px',
                paddingBottom: '15px',
                paddingTop: '15px',
                marginRight: '-15px',
              }}
            >
              <ArrowUpRight className="h-3.5 w-3.5 text-rose-600" />
              <span className="text-[11px] font-medium text-rose-800">Outflow:</span>
              <strong className="text-xs font-bold text-rose-700 tracking-tight">
                -{formatCurrency(filteredExpenses)}
              </strong>
            </div>
          </div>
        </div>

        {/* Rows per page dropdown */}
        <div className="flex items-center space-x-2 self-end sm:self-auto">
          <span className="text-slate-600 font-medium">Show</span>
          <select
            value={itemsPerPage}
            onChange={(e) => {
              setItemsPerPage(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="px-2.5 py-1.5 rounded-lg border font-bold text-slate-800 shadow-2xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            style={{
              backgroundColor: '#d6e9e9',
              borderWidth: '0.8px',
              borderColor: '#83a4d0',
            }}
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
            <option value={-1}>All</option>
          </select>
          <span className="text-slate-600 font-medium">entries per page</span>
        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            {/* Table Header */}
            <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Entry Date</th>
                <th className="py-3.5 px-3">Voucher No</th>
                <th className="py-3.5 px-3">Type</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-3">Mode</th>
                <th className="py-3.5 px-3">Withdrawn Bank</th>
                <th className="py-3.5 px-3">Deposited Bank</th>
                <th className="py-3.5 px-4 text-right">Amount</th>
                <th className="py-3.5 px-4 text-right">Running Balance</th>
                <th className="py-3.5 px-4">Remarks</th>
                <th className="py-3.5 px-3 text-center print:hidden">Action</th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-slate-100 font-medium">
              {currentItems.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center text-slate-500">
                    <div className="max-w-xs mx-auto space-y-3">
                      <p className="text-sm font-medium">
                        No transactions match your current search or filters.
                      </p>
                      <button
                        onClick={onOpenAddModal}
                        className="px-4 py-2 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-xs shadow-sm transition-all"
                      >
                        + Add New Transaction
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                currentItems.map((tnx) => {
                  const isReceipt = tnx.type === 'Receipts';
                  const isExpense = tnx.type === 'Expenses';
                  const isContra = tnx.type === 'Contra';

                  return (
                    <tr
                      key={tnx.id}
                      className="hover:bg-slate-50/80 transition-colors group"
                    >
                      {/* Date */}
                      <td className="py-3 px-4 text-slate-800 whitespace-nowrap">
                        {formatDateForDisplay(tnx.entryDate)}
                      </td>

                      {/* Voucher No */}
                      <td className="py-3 px-3 font-mono font-bold text-slate-900 whitespace-nowrap">
                        {tnx.voucherNo}
                      </td>

                      {/* Type Badge */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        {isReceipt && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <ArrowDownLeft className="h-3 w-3" />
                            Receipts
                          </span>
                        )}
                        {isExpense && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                            <ArrowUpRight className="h-3 w-3" />
                            Expenses
                          </span>
                        )}
                        {isContra && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                            <ArrowRightLeft className="h-3 w-3" />
                            Contra
                          </span>
                        )}
                      </td>

                      {/* Category */}
                      <td className="py-3 px-4 font-semibold text-slate-800">
                        {tnx.category}
                      </td>

                      {/* Mode */}
                      <td className="py-3 px-3 text-slate-500 text-[11px] font-mono">
                        {tnx.mode}
                      </td>

                      {/* Withdrawn Bank */}
                      <td className="py-3 px-3 text-slate-700">
                        {tnx.withdrawnBank === 'N/A' ? (
                          <span className="text-slate-400">N/A</span>
                        ) : (
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200 font-medium">
                            {tnx.withdrawnBank}
                          </span>
                        )}
                      </td>

                      {/* Deposited Bank */}
                      <td className="py-3 px-3 text-slate-700">
                        {tnx.depositedBank === 'N/A' ? (
                          <span className="text-slate-400">N/A</span>
                        ) : (
                          <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 font-medium">
                            {tnx.depositedBank}
                          </span>
                        )}
                      </td>

                      {/* Amount */}
                      <td className="py-3 px-4 text-right font-bold text-sm whitespace-nowrap">
                        <span
                          className={
                            isReceipt
                              ? 'text-emerald-700'
                              : isExpense
                              ? 'text-rose-700'
                              : 'text-indigo-700'
                          }
                        >
                          {formatCurrency(tnx.amount)}
                        </span>
                      </td>

                      {/* Running Balance */}
                      <td className="py-3 px-4 text-right font-bold text-slate-900 whitespace-nowrap bg-slate-50/50">
                        {formatCurrency(tnx.balanceAmount)}
                      </td>

                      {/* Remarks */}
                      <td className="py-3 px-4 text-slate-500 max-w-xs truncate" title={tnx.remarks}>
                        {tnx.remarks || <span className="text-slate-300">-</span>}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-center whitespace-nowrap print:hidden">
                        <div className="flex items-center justify-center space-x-1">
                          <button
                            onClick={() => onEdit(tnx)}
                            title="Edit Transaction"
                            className="p-1.5 rounded-md text-slate-400 hover:text-indigo-600 hover:bg-slate-100 transition-colors cursor-pointer"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (window.confirm(`Are you sure you want to delete ${tnx.voucherNo}?`)) {
                                onDelete(tnx.id);
                              }
                            }}
                            title="Delete Transaction"
                            className="p-1.5 rounded-md text-slate-400 hover:text-rose-600 hover:bg-slate-100 transition-colors cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Summary & Pagination Controls */}
        <div className="bg-slate-50 px-4 py-3 border-t border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-slate-600 font-medium">
          {/* Total stats & entry count */}
          <div className="flex flex-wrap items-center gap-4">
            <span className="text-slate-500 font-semibold">
              Showing {transactions.length === 0 ? 0 : startIndex + 1} to{' '}
              {Math.min(startIndex + effectiveItemsPerPage, transactions.length)} of{' '}
              {transactions.length} entries
            </span>
          </div>

          {/* Pagination buttons */}
          {totalPages > 1 && (
            <div className="flex items-center space-x-2 print:hidden">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
                className="p-1.5 rounded-md bg-white border border-slate-200 text-slate-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100 shadow-2xs cursor-pointer"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="text-slate-800 font-semibold px-1">
                Page {currentPage} of {totalPages}
              </span>
              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
                className="p-1.5 rounded-md bg-white border border-slate-200 text-slate-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100 shadow-2xs cursor-pointer"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

