import React from 'react';
import { AccountOpeningBalance, FilterOptions, Transaction, TransactionType } from '../types';
import { CONTRA_CATEGORIES, EXPENSE_CATEGORIES, RECEIPT_CATEGORIES } from '../data/initialData';
import { Search, Filter, X, Calendar, DollarSign, Layers, Building2, Plus, Settings2 } from 'lucide-react';

interface FilterBarProps {
  filters: FilterOptions;
  setFilters: React.Dispatch<React.SetStateAction<FilterOptions>>;
  accounts: AccountOpeningBalance[];
  totalFilteredCount: number;
  totalAllCount: number;
  onClearFilters: () => void;
  customCategories?: { type: TransactionType; name: string }[];
  allTransactions?: Transaction[];
  onOpenCategoryManager?: () => void;
  onOpenBankManager?: () => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  setFilters,
  accounts,
  totalFilteredCount,
  totalAllCount,
  onClearFilters,
  customCategories = [],
  allTransactions = [],
  onOpenCategoryManager,
  onOpenBankManager,
}) => {
  const allCategories = React.useMemo(() => {
    const defaultCats = [...RECEIPT_CATEGORIES, ...EXPENSE_CATEGORIES, ...CONTRA_CATEGORIES];
    const customNames = customCategories.map((c) => c.name);
    const existingInTransactions = allTransactions.map((t) => t.category).filter(Boolean);
    return Array.from(new Set([...defaultCats, ...customNames, ...existingInTransactions])).sort((a, b) =>
      a.localeCompare(b, undefined, { sensitivity: 'base' })
    );
  }, [customCategories, allTransactions]);

  const isFiltered =
    filters.searchQuery !== '' ||
    filters.type !== 'All' ||
    filters.category !== 'All' ||
    filters.account !== 'All' ||
    filters.startDate !== '' ||
    filters.endDate !== '' ||
    filters.minAmount !== '' ||
    filters.maxAmount !== '';

  return (
    <div
      className="bg-white border rounded-xl p-4 shadow-sm space-y-3"
      style={{
        backgroundColor: '#f4f4fa',
        borderWidth: '3.8px',
        borderColor: '#2f5587',
      }}
    >
      <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between">
        
        {/* Search input */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={filters.searchQuery}
            onChange={(e) => setFilters((prev) => ({ ...prev, searchQuery: e.target.value }))}
            placeholder="Search by Voucher No, Remarks, Category, or Bank..."
            className="w-full bg-white border border-slate-200 rounded-md pl-10 pr-4 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
          />
          {filters.searchQuery && (
            <button
              onClick={() => setFilters((prev) => ({ ...prev, searchQuery: '' }))}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Transaction Type Filter Chips */}
        <div className="flex items-center space-x-1.5 bg-slate-100 p-1 rounded-md border border-slate-200 text-xs font-medium self-start lg:self-auto">
          {['All', 'Receipts', 'Expenses', 'Contra'].map((t) => {
            const isSelected = filters.type === t;
            let activeStyle = 'bg-indigo-600 text-white';
            if (t === 'Receipts') activeStyle = 'bg-emerald-600 text-white';
            if (t === 'Expenses') activeStyle = 'bg-rose-600 text-white';
            if (t === 'Contra') activeStyle = 'bg-indigo-600 text-white';

            return (
              <button
                key={t}
                onClick={() => setFilters((prev) => ({ ...prev, type: t }))}
                className={`px-3 py-1.5 rounded transition-all ${
                  isSelected
                    ? activeStyle + ' shadow-sm font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/80'
                }`}
              >
                {t}
              </button>
            );
          })}
        </div>

      </div>

      {/* Secondary filter dropdowns row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2 border-t border-slate-200">
        
        {/* Category select */}
        <div className="relative">
          <div className="flex items-center justify-between mb-1">
            <label className="text-[11px] font-semibold text-slate-600 flex items-center gap-1">
              <Layers className="h-3 w-3 text-indigo-600" />
              Category
            </label>
            {onOpenCategoryManager && (
              <button
                type="button"
                onClick={onOpenCategoryManager}
                className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold hover:underline flex items-center gap-0.5"
              >
                + Manage
              </button>
            )}
          </div>
          <select
            value={filters.category}
            onChange={(e) => setFilters((prev) => ({ ...prev, category: e.target.value }))}
            className="w-full bg-white border border-slate-200 rounded-md px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          >
            <option value="All">All Categories ({allCategories.length})</option>
            {allCategories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        {/* Account / Bank Select */}
        <div className="relative">
          <div className="flex items-center justify-between mb-1">
            <label className="text-[11px] font-semibold text-slate-600 flex items-center gap-1">
              <Building2 className="h-3 w-3 text-indigo-600" />
              Bank / Cash Account
            </label>
            {onOpenBankManager && (
              <button
                type="button"
                onClick={onOpenBankManager}
                className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold hover:underline flex items-center gap-0.5"
              >
                + Manage
              </button>
            )}
          </div>
          <select
            value={filters.account}
            onChange={(e) => setFilters((prev) => ({ ...prev, account: e.target.value }))}
            className="w-full bg-white border border-slate-200 rounded-md px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          >
            <option value="All">All Accounts ({accounts.length})</option>
            {accounts.map((a) => (
              <option key={a.id} value={a.name}>
                {a.name}
              </option>
            ))}
          </select>
        </div>

        {/* Date From */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-600 mb-1 flex items-center gap-1">
            <Calendar className="h-3 w-3 text-indigo-600" />
            From Date
          </label>
          <input
            type="date"
            value={filters.startDate}
            onChange={(e) => setFilters((prev) => ({ ...prev, startDate: e.target.value }))}
            className="w-full bg-white border border-slate-200 rounded-md px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>

        {/* Date To */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-600 mb-1 flex items-center gap-1">
            <Calendar className="h-3 w-3 text-indigo-600" />
            To Date
          </label>
          <input
            type="date"
            value={filters.endDate}
            onChange={(e) => setFilters((prev) => ({ ...prev, endDate: e.target.value }))}
            className="w-full bg-white border border-slate-200 rounded-md px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>

      </div>

      {/* Results count & Clear filters indicator */}
      <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
        <div>
          Showing <span className="font-bold text-slate-900">{totalFilteredCount}</span> of{' '}
          <span className="text-slate-500">{totalAllCount}</span> transactions
        </div>

        {isFiltered && (
          <button
            onClick={onClearFilters}
            className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center space-x-1"
          >
            <X
              className="h-3.5 w-3.5"
              style={{
                backgroundColor: '#0d1d5e',
                paddingLeft: '3px',
                paddingRight: '3px',
                paddingTop: '3px',
                paddingBottom: '3px',
                marginRight: '0px',
                borderRadius: '4px',
                color: '#f4d6de',
              }}
            />
            <span
              style={{
                backgroundColor: '#080631',
                color: '#eff2f5',
                paddingLeft: '10px',
                paddingRight: '10px',
                paddingTop: '10px',
                paddingBottom: '10px',
                borderRadius: '7px',
              }}
            >
              Reset Filters
            </span>
          </button>
        )}
      </div>
    </div>
  );
};
