import React, { useState, useEffect } from 'react';
import { AccountOpeningBalance } from '../types';
import { formatCurrency, formatNumberInput, parseFormattedNumber, sortAccountsWithCashFirst } from '../utils/finance';
import { X, Building2, Plus, Trash2, Save, Pencil, Check } from 'lucide-react';

interface OpeningBalancesModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: AccountOpeningBalance[];
  onSaveAccounts: (updatedAccounts: AccountOpeningBalance[]) => void;
}

export const OpeningBalancesModal: React.FC<OpeningBalancesModalProps> = ({
  isOpen,
  onClose,
  accounts,
  onSaveAccounts,
}) => {
  const [editableAccounts, setEditableAccounts] = useState<AccountOpeningBalance[]>(accounts);
  const [rawAmounts, setRawAmounts] = useState<Record<string, string>>({});
  const [newBankName, setNewBankName] = useState('');
  const [newBankOpening, setNewBankOpening] = useState('');
  const [editingNameId, setEditingNameId] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      const sorted = sortAccountsWithCashFirst(accounts);
      setEditableAccounts(sorted);
      const initialRaw: Record<string, string> = {};
      sorted.forEach((a) => {
        initialRaw[a.id] = formatNumberInput(a.amount);
      });
      setRawAmounts(initialRaw);
      setNewBankName('');
      setNewBankOpening('');
      setEditingNameId(null);
    }
  }, [accounts, isOpen]);

  if (!isOpen) return null;

  const handleAmountChange = (id: string, inputValue: string) => {
    const formatted = formatNumberInput(inputValue);
    setRawAmounts((prev) => ({ ...prev, [id]: formatted }));
    const val = parseFormattedNumber(formatted);
    setEditableAccounts((prev) =>
      prev.map((acc) => (acc.id === id ? { ...acc, amount: val } : acc))
    );
  };

  const handleNameChange = (id: string, newName: string) => {
    setEditableAccounts((prev) =>
      prev.map((acc) => (acc.id === id ? { ...acc, name: newName } : acc))
    );
  };

  const handleAddAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBankName.trim()) return;

    const parsedVal = parseFormattedNumber(newBankOpening);
    const newId = Date.now().toString();
    const newAcc: AccountOpeningBalance = {
      id: newId,
      name: newBankName.trim(),
      amount: parsedVal,
    };

    setEditableAccounts((prev) => sortAccountsWithCashFirst([...prev, newAcc]));
    setRawAmounts((prev) => ({ ...prev, [newId]: formatNumberInput(parsedVal) }));
    setNewBankName('');
    setNewBankOpening('');
  };

  const handleDeleteAccount = (id: string) => {
    setEditableAccounts((prev) => sortAccountsWithCashFirst(prev.filter((acc) => acc.id !== id)));
  };

  const handleSave = () => {
    onSaveAccounts(sortAccountsWithCashFirst(editableAccounts));
    onClose();
  };

  const totalOpening = editableAccounts.reduce((sum, a) => sum + (a.amount || 0), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-xl w-full max-w-lg shadow-xl overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-white">
          <div className="flex items-center space-x-2.5 pr-2">
            <Building2 className="h-5 w-5 text-indigo-400 shrink-0" />
            <h3 className="font-bold text-[14px] text-white tracking-tight leading-snug">
              Add Bank Name & Manage Opening Balances
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors shrink-0"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          {/* Add New Bank Form (Placed at Top) */}
          <form onSubmit={handleAddAccount} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
            <span className="block text-xs font-bold text-slate-800">
              + Add New Bank / Wallet Account
            </span>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <input
                type="text"
                placeholder="Account Name (e.g. HSBC, bKash)"
                value={newBankName}
                onChange={(e) => setNewBankName(e.target.value)}
                className="flex-1 bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
              <input
                type="text"
                inputMode="decimal"
                placeholder="Opening Bal."
                value={newBankOpening}
                onChange={(e) => setNewBankOpening(formatNumberInput(e.target.value))}
                className="w-full sm:w-32 bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
              <button
                type="submit"
                className="flex items-center justify-center space-x-1 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors shadow-xs cursor-pointer shrink-0"
              >
                <Plus className="h-4 w-4" />
                <span>Add</span>
              </button>
            </div>
          </form>

          {/* Total Opening Summary Card */}
          <div className="flex items-center justify-between p-3.5 bg-indigo-50/80 border border-indigo-200/80 rounded-xl">
            <span className="font-bold text-xs text-indigo-800 uppercase tracking-wider">
              Total Opening Balance
            </span>
            <span className="font-bold text-sm text-indigo-950 font-mono">
              ৳ {formatCurrency(totalOpening)}
            </span>
          </div>

          {/* Bank & Cash Accounts List */}
          <div className="space-y-2 pt-1">
            <div className="text-xs font-bold text-slate-700 px-1">
              Bank & Cash Accounts List
            </div>
            <div className="space-y-2">
              {editableAccounts.map((acc) => {
                const isCash = acc.name.toLowerCase() === 'cash';
                return (
                  <div
                    key={acc.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-200 gap-2"
                  >
                    <div className="flex-1 min-w-0">
                      {editingNameId === acc.id && !isCash ? (
                        <input
                          type="text"
                          value={acc.name}
                          onChange={(e) => handleNameChange(acc.id, e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') setEditingNameId(null);
                          }}
                          className="w-full bg-white border border-indigo-400 rounded-md px-2 py-1 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          autoFocus
                        />
                      ) : (
                        <span className="font-semibold text-xs text-slate-800 truncate block">
                          {acc.name}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center space-x-2 shrink-0">
                      <span className="text-slate-400 text-xs font-semibold">৳</span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={rawAmounts[acc.id] ?? formatNumberInput(acc.amount)}
                        onChange={(e) => handleAmountChange(acc.id, e.target.value)}
                        className="w-24 sm:w-28 bg-white border border-slate-200 rounded-md px-2.5 py-1 text-xs text-slate-900 font-mono font-bold text-right focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      />

                      {/* Edit Bank Name Button - Hidden for Cash */}
                      {!isCash && (
                        <button
                          type="button"
                          onClick={() => setEditingNameId(editingNameId === acc.id ? null : acc.id)}
                          className={`p-1.5 rounded transition-colors ${
                            editingNameId === acc.id
                              ? 'text-indigo-600 bg-indigo-100 hover:bg-indigo-200'
                              : 'text-slate-400 hover:text-indigo-600 hover:bg-slate-200'
                          }`}
                          title="Edit Bank Name"
                        >
                          {editingNameId === acc.id ? (
                            <Check className="h-3.5 w-3.5" />
                          ) : (
                            <Pencil className="h-3.5 w-3.5" />
                          )}
                        </button>
                      )}

                      {/* Delete Account Button */}
                      {!isCash && editableAccounts.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleDeleteAccount(acc.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                          title="Remove Account"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Action Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-md text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex items-center space-x-1.5 px-5 py-2 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-all shadow-sm"
          >
            <Save className="h-3.5 w-3.5" />
            <span>Save Balances</span>
          </button>
        </div>

      </div>
    </div>
  );
};
