import React, { useState } from 'react';
import { TransactionType } from '../types';
import { X, Layers, Plus, Trash2, Tag, Pencil, Check } from 'lucide-react';

interface CategoryManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  customCategories: { type: TransactionType; name: string }[];
  onAddCustomCategory: (type: TransactionType, name: string) => void;
  onDeleteCustomCategory: (type: TransactionType, name: string) => void;
  onEditCustomCategory?: (type: TransactionType, oldName: string, newName: string) => void;
}

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  isOpen,
  onClose,
  customCategories,
  onAddCustomCategory,
  onDeleteCustomCategory,
  onEditCustomCategory,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<TransactionType>('Receipts');
  const [newCatName, setNewCatName] = useState('');
  const [editingCatName, setEditingCatName] = useState<string | null>(null);
  const [editInputValue, setEditInputValue] = useState('');
  const [error, setError] = useState('');

  const categoryList = customCategories
    .filter((c) => c.type === activeTab)
    .map((c) => c.name)
    .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newCatName.trim();
    if (!trimmed) return;

    if (categoryList.some((c) => c.toLowerCase() === trimmed.toLowerCase())) {
      setError('Category already exists in list');
      return;
    }

    onAddCustomCategory(activeTab, trimmed);
    setNewCatName('');
    setError('');
  };

  const handleSaveEdit = (oldName: string) => {
    const trimmed = editInputValue.trim();
    if (!trimmed || trimmed === oldName) {
      setEditingCatName(null);
      return;
    }
    if (categoryList.some((c) => c.toLowerCase() === trimmed.toLowerCase() && c.toLowerCase() !== oldName.toLowerCase())) {
      setError('Category name already exists');
      return;
    }
    if (onEditCustomCategory) {
      onEditCustomCategory(activeTab, oldName, trimmed);
    }
    setEditingCatName(null);
    setError('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-xl w-full max-w-lg shadow-xl overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-white shrink-0">
          <div className="flex items-center space-x-2">
            <Layers className="h-5 w-5 text-indigo-400" />
            <h3 className="font-bold text-base text-white">
              Category Management
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1">
          {/* Type Selector Tabs */}
          <div className="grid grid-cols-3 gap-2 bg-slate-100 p-1 rounded-md border border-slate-200 text-xs font-semibold">
            {(['Receipts', 'Expenses', 'Contra'] as TransactionType[]).map((t) => {
              const isSelected = activeTab === t;
              let activeColor = 'bg-indigo-600 text-white';
              if (t === 'Receipts') activeColor = 'bg-emerald-600 text-white';
              if (t === 'Expenses') activeColor = 'bg-rose-600 text-white';

              return (
                <button
                  key={t}
                  type="button"
                  onClick={() => {
                    setActiveTab(t);
                    setEditingCatName(null);
                    setError('');
                  }}
                  className={`py-2 text-center rounded transition-all cursor-pointer ${
                    isSelected ? activeColor + ' shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {t}
                </button>
              );
            })}
          </div>

          {/* Add New Category Form */}
          <form onSubmit={handleAdd} className="space-y-2 pt-1">
            <label className="block text-xs font-semibold text-slate-700">
              + Add Category ({activeTab})
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder={`e.g. ${activeTab === 'Receipts' ? 'Grant Income' : activeTab === 'Expenses' ? 'Software License' : 'Vault Transfer'}`}
                value={newCatName}
                onChange={(e) => {
                  setNewCatName(e.target.value);
                  setError('');
                }}
                className="flex-1 bg-white border border-slate-200 rounded-md px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors flex items-center space-x-1 cursor-pointer"
              >
                <Plus className="h-4 w-4" />
                <span>Add</span>
              </button>
            </div>
            {error && <p className="text-[11px] font-medium text-rose-600">{error}</p>}
          </form>

          {/* Categories List Section */}
          <div className="space-y-2 pt-2 border-t border-slate-200">
            <span className="block text-xs font-bold text-indigo-700 uppercase tracking-wider">
              Categories ({categoryList.length})
            </span>
            {categoryList.length === 0 ? (
              <p className="text-xs text-slate-400 italic py-2">No categories found for {activeTab}.</p>
            ) : (
              <div className="space-y-1.5">
                {categoryList.map((cat) => (
                  <div
                    key={cat}
                    className="flex items-center justify-between p-2.5 rounded-md bg-indigo-50/60 border border-indigo-100 text-xs gap-2"
                  >
                    <div className="flex-1 min-w-0">
                      {editingCatName === cat ? (
                        <input
                          type="text"
                          value={editInputValue}
                          onChange={(e) => setEditInputValue(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSaveEdit(cat);
                            if (e.key === 'Escape') setEditingCatName(null);
                          }}
                          className="w-full bg-white border border-indigo-400 rounded-md px-2 py-1 text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          autoFocus
                        />
                      ) : (
                        <span className="font-semibold text-indigo-950 flex items-center gap-1.5 truncate">
                          <Tag className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
                          <span className="truncate">{cat}</span>
                        </span>
                      )}
                    </div>

                    <div className="flex items-center space-x-1 shrink-0">
                      {editingCatName === cat ? (
                        <button
                          type="button"
                          onClick={() => handleSaveEdit(cat)}
                          className="p-1 text-indigo-600 hover:bg-indigo-100 rounded transition-colors"
                          title="Save category name"
                        >
                          <Check className="h-3.5 w-3.5" />
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingCatName(cat);
                            setEditInputValue(cat);
                            setError('');
                          }}
                          className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-100/60 rounded transition-colors"
                          title="Edit category name"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onDeleteCustomCategory(activeTab, cat)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded transition-colors"
                        title="Remove category"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end space-x-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-md border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
