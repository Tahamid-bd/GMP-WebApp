import React from 'react';
import { ViewTab } from '../types';
import { 
  Building2, 
  PlusCircle, 
  Download, 
  PieChart, 
  Receipt, 
  Wallet, 
  RotateCcw,
  Sparkles,
  FileSpreadsheet,
  FileText,
  Layers
} from 'lucide-react';

interface NavbarProps {
  activeTab: ViewTab;
  setActiveTab: (tab: ViewTab) => void;
  onOpenAddModal: () => void;
  onOpenOpeningModal: () => void;
  onOpenCategoryModal: () => void;
  onExportCSV: () => void;
  onResetData: () => void;
  transactionCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddModal,
  onOpenOpeningModal,
  onOpenCategoryModal,
  onExportCSV,
  onResetData,
  transactionCount,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900 text-white border-b border-slate-800 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo and App Title */}
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold shadow-sm">
              <Receipt className="h-5 w-5" />
            </div>
            <div>
              <h1 className="font-bold text-lg tracking-tight text-white">
                Transaction Register
              </h1>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex space-x-1 bg-slate-950/80 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setActiveTab('register')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                activeTab === 'register'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              <FileSpreadsheet className="h-4 w-4" />
              <span>Register</span>
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-xs bg-slate-900 text-slate-300 font-semibold">
                {transactionCount}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('accounts')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                activeTab === 'accounts'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              <Wallet className="h-4 w-4" />
              <span>Bank & Cash</span>
            </button>

            <button
              onClick={() => setActiveTab('statement')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                activeTab === 'statement'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              <FileText className="h-4 w-4" />
              <span>R & P Statement</span>
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                activeTab === 'analytics'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              <PieChart className="h-4 w-4" />
              <span>Analytics</span>
            </button>
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            <button
              onClick={onOpenCategoryModal}
              title="Manage Categories"
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-md transition-colors border border-slate-800 hidden lg:flex items-center space-x-1.5 text-xs font-medium"
            >
              <Layers className="h-4 w-4 text-indigo-400" />
              <span>Categories</span>
            </button>

            <button
              onClick={onOpenOpeningModal}
              title="Manage Opening Balances & Bank Accounts"
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-md transition-colors border border-slate-800 hidden sm:flex items-center space-x-1.5 text-xs font-medium"
            >
              <Building2 className="h-4 w-4 text-indigo-400" />
              <span>Accounts Setup</span>
            </button>

            <button
              onClick={onExportCSV}
              title="Export Full Register as CSV"
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-md transition-colors border border-slate-800 flex items-center space-x-1.5 text-xs font-medium"
            >
              <Download className="h-4 w-4 text-sky-400" />
              <span className="hidden xl:inline">Export CSV</span>
            </button>

            <button
              onClick={onResetData}
              title="Reset data to initial sample register"
              className="p-2 text-slate-400 hover:text-rose-300 hover:bg-slate-800 rounded-md transition-colors border border-slate-800"
            >
              <RotateCcw className="h-4 w-4" />
            </button>

            <button
              onClick={onOpenAddModal}
              className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded-md text-sm transition-all shadow-sm active:scale-95"
            >
              <PlusCircle className="h-4.5 w-4.5" />
              <span>Add Transaction</span>
            </button>
          </div>
        </div>

        {/* Mobile Sub-Navigation Bar */}
        <div className="flex md:hidden border-t border-slate-800 py-2 space-x-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('register')}
            className={`flex-1 py-1.5 px-3 rounded-md text-xs font-medium text-center whitespace-nowrap ${
              activeTab === 'register' ? 'bg-indigo-600 text-white' : 'text-slate-400 bg-slate-800/40'
            }`}
          >
            Register ({transactionCount})
          </button>
          <button
            onClick={() => setActiveTab('accounts')}
            className={`flex-1 py-1.5 px-3 rounded-md text-xs font-medium text-center whitespace-nowrap ${
              activeTab === 'accounts' ? 'bg-indigo-600 text-white' : 'text-slate-400 bg-slate-800/40'
            }`}
          >
            Bank & Cash
          </button>
          <button
            onClick={() => setActiveTab('statement')}
            className={`flex-1 py-1.5 px-3 rounded-md text-xs font-medium text-center whitespace-nowrap ${
              activeTab === 'statement' ? 'bg-indigo-600 text-white' : 'text-slate-400 bg-slate-800/40'
            }`}
          >
            R & P Statement
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex-1 py-1.5 px-3 rounded-md text-xs font-medium text-center whitespace-nowrap ${
              activeTab === 'analytics' ? 'bg-indigo-600 text-white' : 'text-slate-400 bg-slate-800/40'
            }`}
          >
            Analytics
          </button>
          <button
            onClick={onOpenCategoryModal}
            className="py-1.5 px-3 rounded-md text-xs font-medium text-slate-300 bg-slate-800/80 whitespace-nowrap"
          >
            Categories
          </button>
        </div>
      </div>
    </header>
  );
};
