import React, { useState, useEffect } from 'react';
import { AccountOpeningBalance, Transaction, TransactionMode, TransactionType } from '../types';
import { CONTRA_CATEGORIES, EXPENSE_CATEGORIES, RECEIPT_CATEGORIES } from '../data/initialData';
import { generateNextVoucherNo, formatNumberInput, parseFormattedNumber } from '../utils/finance';
import { X, ArrowDownLeft, ArrowUpRight, ArrowRightLeft, AlertCircle, CheckCircle2 } from 'lucide-react';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (transaction: Omit<Transaction, 'id' | 'createdAt'> & { id?: string }) => void;
  editingTransaction?: Transaction | null;
  allTransactions: Transaction[];
  accounts: AccountOpeningBalance[];
  initialAccount?: string;
  customCategories?: { type: TransactionType; name: string }[];
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingTransaction,
  allTransactions,
  accounts,
  initialAccount,
  customCategories = [],
}) => {
  const [type, setType] = useState<TransactionType>('Expenses');
  const [entryDate, setEntryDate] = useState<string>(
    new Date().toISOString().slice(0, 10)
  );
  const [voucherNo, setVoucherNo] = useState<string>('');
  const [category, setCategory] = useState<string>('');
  const [customCategory, setCustomCategory] = useState<string>('');
  const [mode, setMode] = useState<TransactionMode>('Cash');
  const [withdrawnBank, setWithdrawnBank] = useState<string>('Cash');
  const [depositedBank, setDepositedBank] = useState<string>('N/A');
  const [amount, setAmount] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  const receiptCats = React.useMemo(() => {
    const custom = customCategories.filter((c) => c.type === 'Receipts').map((c) => c.name);
    return Array.from(new Set([...RECEIPT_CATEGORIES, ...custom])).sort((a, b) =>
      a.localeCompare(b, undefined, { sensitivity: 'base' })
    );
  }, [customCategories]);

  const expenseCats = React.useMemo(() => {
    const custom = customCategories.filter((c) => c.type === 'Expenses').map((c) => c.name);
    return Array.from(new Set([...EXPENSE_CATEGORIES, ...custom])).sort((a, b) =>
      a.localeCompare(b, undefined, { sensitivity: 'base' })
    );
  }, [customCategories]);

  const contraCats = React.useMemo(() => {
    const custom = customCategories.filter((c) => c.type === 'Contra').map((c) => c.name);
    return Array.from(new Set([...CONTRA_CATEGORIES, ...custom])).sort((a, b) =>
      a.localeCompare(b, undefined, { sensitivity: 'base' })
    );
  }, [customCategories]);

  // Auto initialize values when modal opens or editing state changes
  useEffect(() => {
    if (!isOpen) return;

    if (editingTransaction) {
      setType(editingTransaction.type);
      setEntryDate(editingTransaction.entryDate);
      setVoucherNo(editingTransaction.voucherNo);
      setCategory(editingTransaction.category);
      setMode(editingTransaction.mode);
      setWithdrawnBank(editingTransaction.withdrawnBank);
      setDepositedBank(editingTransaction.depositedBank);
      setAmount(formatNumberInput(editingTransaction.amount));
      setRemarks(editingTransaction.remarks || '');
    } else {
      // New transaction default
      const nextVoucher = generateNextVoucherNo(allTransactions);
      setVoucherNo(nextVoucher);
      setEntryDate(new Date().toISOString().slice(0, 10));
      setAmount('');
      setRemarks('');
      setErrorMsg('');

      // If opened with a specific bank filter or initial account
      if (initialAccount && initialAccount !== 'All') {
        if (initialAccount.toLowerCase() === 'cash') {
          setType('Expenses');
          setCategory('');
          setMode('Cash');
          setWithdrawnBank('Cash');
          setDepositedBank('N/A');
        } else {
          setType('Expenses');
          setCategory('');
          setMode('Bank');
          setWithdrawnBank(initialAccount);
          setDepositedBank('N/A');
        }
      } else {
        setType('Expenses');
        setCategory('');
        setMode('Cash');
        setWithdrawnBank('Cash');
        setDepositedBank('N/A');
      }
    }
  }, [editingTransaction, isOpen]);

  if (!isOpen) return null;

  // Handle Type switch default presets
  const handleTypeChange = (newType: TransactionType) => {
    setType(newType);
    setErrorMsg('');
    setCategory('');

    if (newType === 'Receipts') {
      setMode('Bank');
      setWithdrawnBank('N/A');
      setDepositedBank(accounts.find((a) => a.name !== 'Cash')?.name || 'DBBL');
    } else if (newType === 'Expenses') {
      setMode('Cash');
      setWithdrawnBank('Cash');
      setDepositedBank('N/A');
    } else if (newType === 'Contra') {
      setMode('Bank→Cash');
      setWithdrawnBank(accounts.find((a) => a.name !== 'Cash')?.name || 'DBBL');
      setDepositedBank('Cash');
    }
  };

  // Handle Contra Category switch presets
  const handleContraCategoryChange = (cat: string) => {
    setCategory(cat);
    if (cat === 'Cash Withdrawn From Bank') {
      setMode('Bank→Cash');
      setWithdrawnBank(accounts.find((a) => a.name !== 'Cash')?.name || 'DBBL');
      setDepositedBank('Cash');
    } else if (cat === 'Cash Deposit To Bank') {
      setMode('Cash→Bank');
      setWithdrawnBank('Cash');
      setDepositedBank(accounts.find((a) => a.name !== 'Cash')?.name || 'DBBL');
    } else if (cat === 'Bank To Bank Transfer') {
      setMode('Bank→Bank');
      const bankAccounts = accounts.filter((a) => a.name.toLowerCase() !== 'cash');
      setWithdrawnBank(bankAccounts[0]?.name || 'DBBL');
      setDepositedBank(bankAccounts[1]?.name || 'Brac');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFormattedNumber(amount);

    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setErrorMsg('Please enter a valid positive transaction amount.');
      return;
    }

    if (!voucherNo.trim()) {
      setErrorMsg('Voucher number is required.');
      return;
    }

    const finalCategory = category === 'Other' ? customCategory.trim() : category;
    if (!finalCategory) {
      setErrorMsg('Please specify a category.');
      return;
    }

    if (type === 'Contra' && withdrawnBank === depositedBank) {
      setErrorMsg('Withdrawn Bank and Deposited Bank cannot be the same for a transfer.');
      return;
    }

    onSave({
      id: editingTransaction?.id,
      entryDate,
      voucherNo: voucherNo.trim(),
      type,
      category: finalCategory,
      mode,
      withdrawnBank,
      depositedBank,
      amount: parsedAmount,
      remarks: remarks.trim(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-xl w-full max-w-lg shadow-xl overflow-hidden">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-white">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-md bg-indigo-500/20 text-indigo-300 flex items-center justify-center">
              {type === 'Receipts' && <ArrowDownLeft className="h-5 w-5 text-emerald-400" />}
              {type === 'Expenses' && <ArrowUpRight className="h-5 w-5 text-rose-400" />}
              {type === 'Contra' && <ArrowRightLeft className="h-5 w-5 text-indigo-300" />}
            </div>
            <h3 className="font-bold text-base text-white">
              {editingTransaction ? 'Edit Transaction' : 'Record New Transaction'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {/* Type Selector Tabs */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Transaction Type
            </label>
            <div className="grid grid-cols-3 gap-2 bg-slate-100 p-1 rounded-md border border-slate-200">
              {(['Receipts', 'Expenses', 'Contra'] as TransactionType[]).map((t) => {
                const isSelected = type === t;
                let activeColor = 'bg-indigo-600 text-white';
                if (t === 'Receipts') activeColor = 'bg-emerald-600 text-white';
                if (t === 'Expenses') activeColor = 'bg-rose-600 text-white';
                if (t === 'Contra') activeColor = 'bg-indigo-600 text-white';

                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => handleTypeChange(t)}
                    className={`py-2 text-xs font-semibold rounded transition-all ${
                      isSelected ? activeColor + ' shadow-sm' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {t}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date & Voucher No */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Entry Date
              </label>
              <input
                type="date"
                required
                value={entryDate}
                onChange={(e) => setEntryDate(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-md px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Voucher No
              </label>
              <input
                type="text"
                required
                value={voucherNo}
                onChange={(e) => setVoucherNo(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-md px-3 py-2 text-xs text-slate-900 font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Category Dropdown */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => {
                if (type === 'Contra') {
                  handleContraCategoryChange(e.target.value);
                } else {
                  setCategory(e.target.value);
                }
              }}
              className="w-full bg-white border border-slate-200 rounded-md px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="">-- Select Category --</option>
              {type === 'Receipts' &&
                receiptCats.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              {type === 'Expenses' &&
                expenseCats.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              {type === 'Contra' &&
                contraCats.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              <option value="Other">Other (Specify below)</option>
            </select>

            {category === 'Other' && (
              <input
                type="text"
                placeholder="Enter custom category name..."
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
                className="mt-2 w-full bg-white border border-slate-200 rounded-md px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            )}
          </div>

          {/* Bank Accounts Logic: Withdrawn From & Deposited To */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-md border border-slate-200">
            {/* Withdrawn Bank */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                Withdrawn Bank / Source
              </label>
              <select
                disabled={type === 'Receipts' || (type === 'Contra' && category === 'Cash Deposit To Bank')}
                value={withdrawnBank}
                onChange={(e) => {
                  setWithdrawnBank(e.target.value);
                  if (type === 'Expenses' && e.target.value.toLowerCase() === 'cash') {
                    setMode('Cash');
                  } else if (type === 'Expenses') {
                    setMode('Bank');
                  }
                }}
                className="w-full bg-white border border-slate-200 rounded-md px-2.5 py-1.5 text-xs text-slate-800 disabled:opacity-50 disabled:bg-slate-100"
              >
                <option value="N/A">N/A</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.name}>
                    {a.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Deposited Bank */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                Deposited Bank / Destination
              </label>
              <select
                disabled={type === 'Expenses' || (type === 'Contra' && category === 'Cash Withdrawn From Bank')}
                value={depositedBank}
                onChange={(e) => {
                  setDepositedBank(e.target.value);
                  if (type === 'Receipts' && e.target.value.toLowerCase() === 'cash') {
                    setMode('Cash');
                  } else if (type === 'Receipts') {
                    setMode('Bank');
                  }
                }}
                className="w-full bg-white border border-slate-200 rounded-md px-2.5 py-1.5 text-xs text-slate-800 disabled:opacity-50 disabled:bg-slate-100"
              >
                <option value="N/A">N/A</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.name}>
                    {a.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Amount Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Transaction Amount
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-sm">
                ৳
              </span>
              <input
                type="text"
                inputMode="decimal"
                required
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(formatNumberInput(e.target.value))}
                className="w-full bg-white border border-slate-200 rounded-md pl-8 pr-4 py-2.5 text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Remarks */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Remarks / Notes
            </label>
            <input
              type="text"
              placeholder="e.g. Invoice #102, Cheque No, Purpose..."
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-md px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>

          {/* Error Banner */}
          {errorMsg && (
            <div className="flex items-center space-x-2 p-3 rounded-md bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex items-center justify-end space-x-3 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-md text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-all shadow-sm"
            >
              {editingTransaction ? 'Update Entry' : 'Save Transaction'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
