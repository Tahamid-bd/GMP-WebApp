import React, { useState, useEffect } from 'react';
import { ViewTab } from '../types';
import { initAuth, googleSignIn, logoutGoogle } from '../lib/googleAuth';
import { User } from 'firebase/auth';
import { LogOut, FileSpreadsheet } from 'lucide-react';

interface TopHeaderProps {
  activeTab: ViewTab;
}

export const TopHeader: React.FC<TopHeaderProps> = ({ activeTab }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);

  useEffect(() => {
    const unsubscribe = initAuth(
      (u) => setUser(u),
      () => setUser(null)
    );
    return () => unsubscribe();
  }, []);

  const handleSignIn = async () => {
    setIsSigningIn(true);
    try {
      const res = await googleSignIn();
      if (res?.user) {
        setUser(res.user);
      }
    } catch (err: any) {
      console.error('Sign-in error:', err);
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    await logoutGoogle();
    setUser(null);
  };

  const getTabTitle = () => {
    switch (activeTab) {
      case 'register':
        return {
          title: 'All Transactions',
          subtitle: 'All Receipts, Expenses, Contra Movements, Bank & Cash Transactions Data.',
        };
      case 'accounts':
        return {
          title: 'Bank & Cash Accounts',
          subtitle: 'Configure liquid account details, opening balances & history',
        };
      case 'analytics':
        return {
          title: 'Analytics & Financial Charts',
          subtitle: 'Visual insights on cash flows, income distribution & trends',
        };
      case 'statement':
        return {
          title: 'Account Statement',
          subtitle: 'Detailed ledger statements & chronological running balances',
        };
      default:
        return {
          title: 'All Transactions',
          subtitle: 'All Receipts, Expenses, Contra Movements, Bank & Cash Transactions Data.',
        };
    }
  };

  const { title, subtitle } = getTabTitle();

  return (
    <header className="no-print bg-slate-900 border-b border-slate-800 px-4 sm:px-6 py-4 sticky top-0 z-20 shadow-sm hidden md:block">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">{title}</h2>
          <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>
        </div>

        <div className="flex items-center space-x-4">
          {/* Google Sheets Account Status */}
          {user ? (
            <div className="flex items-center space-x-2 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg text-xs">
              <FileSpreadsheet className="h-4 w-4 text-emerald-400 shrink-0" />
              <div className="text-left">
                <div className="text-[11px] text-emerald-400 font-bold leading-tight">Google Sheets Connected</div>
                <div className="text-[10px] text-slate-300 truncate max-w-[140px]">{user.email}</div>
              </div>
              <button
                onClick={handleSignOut}
                title="Disconnect Google Account"
                className="ml-1 p-1 hover:bg-slate-700 text-slate-400 hover:text-rose-400 rounded transition-colors cursor-pointer"
              >
                <LogOut className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={handleSignIn}
              disabled={isSigningIn}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-xs font-semibold text-slate-200 hover:text-white transition-all flex items-center space-x-2 cursor-pointer"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
              </svg>
              <span>{isSigningIn ? 'Connecting...' : 'Connect Google Sheets'}</span>
            </button>
          )}

          <div className="text-right shrink-0 pl-2 border-l border-slate-800">
            <div className="text-xs sm:text-sm font-semibold text-slate-200">
              Developed By <span className="text-indigo-400 font-bold">@ Tahamid</span>
            </div>
            <div className="text-xs font-mono font-medium text-slate-400 mt-0.5 tracking-wider">
              01977 87 87 18
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};


