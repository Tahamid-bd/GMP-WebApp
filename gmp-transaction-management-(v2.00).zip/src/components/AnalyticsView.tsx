import React from 'react';
import { AccountOpeningBalance, Transaction } from '../types';
import { calculateAccountBalances, formatCurrency } from '../utils/finance';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { PieChart as PieIcon, BarChart3, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';

interface AnalyticsViewProps {
  transactions: Transaction[];
  accounts: AccountOpeningBalance[];
}

const COLORS = [
  '#10b981', // emerald
  '#06b6d4', // cyan
  '#3b82f6', // blue
  '#8b5cf6', // violet
  '#ec4899', // pink
  '#f43f5e', // rose
  '#f97316', // orange
  '#eab308', // yellow
  '#84cc16', // lime
  '#64748b', // slate
];

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ transactions, accounts }) => {
  // 1. Calculate Expenses by Category
  const expenseByCategoryMap: Record<string, number> = {};
  let totalExpenses = 0;
  let totalReceipts = 0;

  transactions.forEach((t) => {
    const amt = Number(t.amount) || 0;
    if (t.type === 'Expenses') {
      totalExpenses += amt;
      expenseByCategoryMap[t.category] = (expenseByCategoryMap[t.category] || 0) + amt;
    } else if (t.type === 'Receipts') {
      totalReceipts += amt;
    }
  });

  const categoryData = Object.entries(expenseByCategoryMap)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  // 2. Account Funds Distribution
  const accountBalances = calculateAccountBalances(accounts, transactions);
  const accountDistributionData = accounts.map((acc) => ({
    name: acc.name,
    value: Math.max(accountBalances[acc.name]?.current || 0, 0),
  }));

  // Top Expense category
  const topExpenseCat = categoryData[0] || { name: 'None', value: 0 };

  return (
    <div className="space-y-6">
      
      {/* Top Insights Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
          <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider mb-1">
            Top Expense Category
          </div>
          <div className="text-xl font-bold text-slate-900 truncate">
            {topExpenseCat.name}
          </div>
          <div className="mt-2 text-xs font-bold text-rose-600 font-mono">
            ৳ {formatCurrency(topExpenseCat.value)}
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
          <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider mb-1">
            Net Operating Inflow
          </div>
          <div className="text-xl font-bold text-slate-900">
            ৳ {formatCurrency(totalReceipts - totalExpenses)}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Receipts ({formatCurrency(totalReceipts)}) - Expenses ({formatCurrency(totalExpenses)})
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm">
          <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider mb-1">
            Expense Ratio
          </div>
          <div className="text-xl font-bold text-slate-900">
            {totalReceipts > 0
              ? `${((totalExpenses / totalReceipts) * 100).toFixed(1)}%`
              : 'N/A'}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Percentage of total inflows spent on expenses
          </div>
        </div>

      </div>

      {/* Visual Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Expense Category Breakdown Chart */}
        <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-rose-600" />
              <span>Expense Breakdown by Category</span>
            </h3>
            <span className="text-xs text-slate-500 font-mono font-bold">
              Total: ৳ {formatCurrency(totalExpenses)}
            </span>
          </div>

          <div className="h-72 w-full flex items-center justify-center">
            {categoryData.length === 0 ? (
              <p className="text-xs text-slate-400 font-medium">No expense records available to display chart.</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <BarChart data={categoryData} layout="vertical" margin={{ left: 20, right: 20 }}>
                  <XAxis type="number" stroke="#64748b" fontSize={11} tickFormatter={(v) => `৳${v}`} />
                  <YAxis dataKey="name" type="category" stroke="#475569" fontSize={11} width={120} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '8px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    formatter={(val: any) => [`৳ ${formatCurrency(Number(val))}`, 'Expense']}
                  />
                  <Bar dataKey="value" fill="#e11d48" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Account Funds Distribution Pie Chart */}
        <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <PieIcon className="h-4 w-4 text-indigo-600" />
              <span>Current Account Funds Distribution</span>
            </h3>
          </div>

          <div className="h-72 w-full flex items-center justify-center">
            {accountDistributionData.every((d) => d.value <= 0) ? (
              <p className="text-xs text-slate-400 font-medium">No positive balances available to display distribution.</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <PieChart>
                  <Pie
                    data={accountDistributionData.filter((d) => d.value > 0)}
                    cx="50%"
                    cy="50%"
                    outerRadius={90}
                    innerRadius={50}
                    paddingAngle={3}
                    dataKey="value"
                    label={({ name, percent }) => `${name} (${(((percent || 0) * 100)).toFixed(0)}%)`}
                  >
                    {accountDistributionData.filter((d) => d.value > 0).map((entry, index) => (
                      <Cell key={`cell-${entry.name}-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '8px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    formatter={(val: any) => [`৳ ${formatCurrency(Number(val))}`, 'Balance']}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
