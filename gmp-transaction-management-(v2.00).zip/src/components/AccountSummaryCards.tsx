import React, { useState, useMemo } from 'react';
import { AccountOpeningBalance, Transaction, TransactionType } from '../types';
import { formatCurrency, formatDateForDisplay } from '../utils/finance';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  Building2, 
  PieChart, 
  Eye, 
  X, 
  ChevronRight, 
  FileText,
  Coins,
  Printer,
  Download,
  FileSpreadsheet
} from 'lucide-react';

interface AccountSummaryCardsProps {
  accounts: AccountOpeningBalance[];
  transactions: Transaction[];
  selectedAccountFilter?: string;
  onSelectAccountFilter?: (accName: string) => void;
  onOpenAddModalWithAccount?: (accName: string) => void;
}

export const AccountSummaryCards: React.FC<AccountSummaryCardsProps> = ({
  accounts,
  transactions,
}) => {
  const [breakdownType, setBreakdownType] = useState<TransactionType | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [bankModalData, setBankModalData] = useState<{
    title: string;
    subtitle?: string;
    balances: { name: string; amount: number }[];
  } | null>(null);

  // Helper to clean account names
  const cleanAccountName = (accName: string) => {
    return accName
      .replace(/^Opening:\s*/i, '')
      .replace(/^Closing:\s*/i, '')
      .replace(/\s*Account$/i, '')
      .trim();
  };

  // 1. Opening Balances Calculation
  const cashOpening = useMemo(() => {
    return accounts
      .filter((a) => a.name.toLowerCase() === 'cash')
      .reduce((sum, a) => sum + (Number(a.amount) || 0), 0);
  }, [accounts]);

  const bankOpeningList = useMemo(() => {
    return accounts
      .filter((a) => a.name.toLowerCase() !== 'cash')
      .map((a) => ({
        name: cleanAccountName(a.name),
        amount: Number(a.amount) || 0,
      }));
  }, [accounts]);

  const bankOpening = useMemo(() => {
    return bankOpeningList.reduce((sum, a) => sum + a.amount, 0);
  }, [bankOpeningList]);

  const totalOpening = cashOpening + bankOpening;

  // 2. Receipts & Expenses Totals
  let totalReceipts = 0;
  let totalExpenses = 0;
  let receiptCount = 0;
  let expenseCount = 0;

  // 3. Current Liquid Cash & Bank Calculations (by account)
  const currentBalancesMap = useMemo(() => {
    const map: Record<string, number> = {};
    accounts.forEach((a) => {
      map[a.name] = Number(a.amount) || 0;
    });

    transactions.forEach((t) => {
      const amt = Number(t.amount) || 0;
      if (t.type === 'Receipts') {
        if (t.depositedBank && map[t.depositedBank] !== undefined) {
          map[t.depositedBank] += amt;
        }
      } else if (t.type === 'Expenses') {
        if (t.withdrawnBank && map[t.withdrawnBank] !== undefined) {
          map[t.withdrawnBank] -= amt;
        }
      } else if (t.type === 'Contra') {
        if (t.withdrawnBank && map[t.withdrawnBank] !== undefined) {
          map[t.withdrawnBank] -= amt;
        }
        if (t.depositedBank && map[t.depositedBank] !== undefined) {
          map[t.depositedBank] += amt;
        }
      }
    });

    return map;
  }, [accounts, transactions]);

  const cashCurrent = useMemo(() => {
    const cashKey = Object.keys(currentBalancesMap).find((k) => k.toLowerCase() === 'cash');
    return cashKey ? currentBalancesMap[cashKey] : 0;
  }, [currentBalancesMap]);

  const bankCurrentList = useMemo(() => {
    return Object.entries(currentBalancesMap)
      .filter(([accName]) => accName.toLowerCase() !== 'cash')
      .map(([accName, amount]) => ({
        name: cleanAccountName(accName),
        amount,
      }));
  }, [currentBalancesMap]);

  const bankCurrent = useMemo(() => {
    return bankCurrentList.reduce((sum, b) => sum + b.amount, 0);
  }, [bankCurrentList]);

  const totalClosing = cashCurrent + bankCurrent;

  // Category breakdown data when modal is open
  const categoryBreakdownList = useMemo(() => {
    if (!breakdownType) return [];

    const map: Record<string, { name: string; total: number; count: number; items: Transaction[] }> = {};

    transactions
      .filter((t) => t.type === breakdownType)
      .forEach((t) => {
        const catName = t.category || 'Uncategorized';
        if (!map[catName]) {
          map[catName] = { name: catName, total: 0, count: 0, items: [] };
        }
        map[catName].total += Number(t.amount) || 0;
        map[catName].count += 1;
        map[catName].items.push(t);
      });

    return Object.values(map).sort((a, b) => b.total - a.total);
  }, [transactions, breakdownType]);

  const activeCategoryDetail = useMemo(() => {
    if (!selectedCategory || !categoryBreakdownList.length) return null;
    return categoryBreakdownList.find((c) => c.name === selectedCategory) || null;
  }, [selectedCategory, categoryBreakdownList]);

  const activeCategoryDetailWithRunningBalance = useMemo(() => {
    if (!activeCategoryDetail) return null;
    const sorted = [...activeCategoryDetail.items].sort((a, b) => {
      const dComp = a.entryDate.localeCompare(b.entryDate);
      if (dComp !== 0) return dComp;
      return (a.createdAt || 0) - (b.createdAt || 0);
    });
    let running = 0;
    const itemsWithRunning = sorted.map((t) => {
      running += (Number(t.amount) || 0);
      return {
        ...t,
        runningBalance: running,
      };
    });
    return {
      ...activeCategoryDetail,
      itemsWithRunning,
      runningTotal: running,
    };
  }, [activeCategoryDetail]);

  const handlePrintCardCategoryDetail = () => {
    if (!activeCategoryDetailWithRunningBalance || !breakdownType) return;
    try {
      let rowsHtml = '';
      activeCategoryDetailWithRunningBalance.itemsWithRunning.forEach((t, idx) => {
        const bg = idx % 2 === 1 ? 'background-color: #f8fafc;' : '';
        const accName = t.type === 'Receipts' ? t.depositedBank : t.withdrawnBank;
        rowsHtml += `
          <tr style="${bg}">
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace;">${idx + 1}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace;">${formatDateForDisplay(t.entryDate)}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold; font-family: monospace; color: #4338ca;">${t.voucherNo}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1;">${cleanAccountName(accName || '-')}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; color: #475569;">${t.remarks || '-'}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold; font-family: monospace;">${formatCurrency(t.amount)}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold; font-family: monospace; color: #10b981;">${formatCurrency(t.runningBalance)}</td>
          </tr>
        `;
      });

      const printHtml = `
        <!DOCTYPE html>
        <html>
          <head>
            <title>${activeCategoryDetailWithRunningBalance.name} - Category Ledger</title>
            <style>
              @page { size: A4 portrait; margin: 12mm; }
              body { font-family: Arial, sans-serif; font-size: 11px; color: #0f172a; margin: 0; padding: 15px; }
              .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #0f172a; padding-bottom: 10px; }
              .header h1 { margin: 0; font-size: 18px; text-transform: uppercase; }
              .header h2 { margin: 4px 0; font-size: 14px; font-weight: bold; color: #4338ca; }
              .header p { margin: 2px 0; font-size: 10px; color: #64748b; }
              table { width: 100%; border-collapse: collapse; margin-top: 15px; }
              th { background-color: #1e293b; color: #ffffff; padding: 8px 10px; font-size: 10px; text-transform: uppercase; border: 1px solid #1e293b; }
              .total-row { background-color: #f1f5f9; font-weight: bold; font-size: 11px; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>GMP FASHIONS LTD.</h1>
              <h2>CATEGORY LEDGER: ${activeCategoryDetailWithRunningBalance.name.toUpperCase()} (${breakdownType.toUpperCase()})</h2>
              <p>Total Entries: ${activeCategoryDetailWithRunningBalance.itemsWithRunning.length}</p>
            </div>

            <table>
              <thead>
                <tr>
                  <th style="width: 35px; text-align: center;">SL#</th>
                  <th style="width: 80px; text-align: center;">DATE</th>
                  <th style="width: 90px;">VOUCHER NO</th>
                  <th>ACCOUNT / BANK</th>
                  <th>REMARKS / PARTICULARS</th>
                  <th style="width: 100px; text-align: right;">AMOUNT (BDT)</th>
                  <th style="width: 110px; text-align: right;">RUNNING BAL (BDT)</th>
                </tr>
              </thead>
              <tbody>
                ${rowsHtml}
                <tr class="total-row">
                  <td colspan="5" style="padding: 8px 10px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold;">TOTAL (${activeCategoryDetailWithRunningBalance.name.toUpperCase()}):</td>
                  <td style="padding: 8px 10px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold; font-family: monospace;">৳ ${formatCurrency(activeCategoryDetailWithRunningBalance.total)}</td>
                  <td style="padding: 8px 10px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold; font-family: monospace; color: #4338ca;">৳ ${formatCurrency(activeCategoryDetailWithRunningBalance.runningTotal)}</td>
                </tr>
              </tbody>
            </table>
          </body>
        </html>
      `;

      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(printHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => printWindow.print(), 300);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleExportCardCategoryPdf = () => {
    if (!activeCategoryDetailWithRunningBalance || !breakdownType) return;
    try {
      const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(16);
      doc.text('GMP FASHIONS LTD.', 105, 15, { align: 'center' });

      doc.setFontSize(12);
      doc.setTextColor(67, 56, 202);
      doc.text(`CATEGORY LEDGER: ${activeCategoryDetailWithRunningBalance.name.toUpperCase()}`, 105, 22, { align: 'center' });

      const tableRows = activeCategoryDetailWithRunningBalance.itemsWithRunning.map((t, idx) => {
        const accName = t.type === 'Receipts' ? t.depositedBank : t.withdrawnBank;
        return [
          (idx + 1).toString(),
          formatDateForDisplay(t.entryDate),
          t.voucherNo,
          cleanAccountName(accName || '-'),
          t.remarks || '-',
          formatCurrency(t.amount),
          formatCurrency(t.runningBalance)
        ];
      });

      tableRows.push([
        '',
        '',
        '',
        '',
        `TOTAL (${activeCategoryDetailWithRunningBalance.name}):`,
        `BDT ${formatCurrency(activeCategoryDetailWithRunningBalance.total)}`,
        `BDT ${formatCurrency(activeCategoryDetailWithRunningBalance.runningTotal)}`
      ]);

      autoTable(doc, {
        startY: 28,
        head: [['SL#', 'DATE', 'VOUCHER NO', 'ACCOUNT / BANK', 'REMARKS / PARTICULARS', 'AMOUNT (BDT)', 'RUNNING BAL (BDT)']],
        body: tableRows,
        theme: 'striped',
        headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 8.5 },
        columnStyles: {
          0: { halign: 'center', cellWidth: 10 },
          1: { halign: 'center', cellWidth: 22 },
          2: { halign: 'left', cellWidth: 24, fontStyle: 'bold' },
          3: { halign: 'left', cellWidth: 32 },
          4: { halign: 'left' },
          5: { halign: 'right', cellWidth: 28, fontStyle: 'bold' },
          6: { halign: 'right', cellWidth: 30, fontStyle: 'bold' },
        },
        styles: { fontSize: 8, cellPadding: 2 },
        didParseCell: (data) => {
          if (data.section === 'head') {
            data.cell.styles.fillColor = [15, 23, 42];
            data.cell.styles.textColor = [255, 255, 255];
            data.cell.styles.fontStyle = 'bold';
          }
        }
      });

      doc.save(`Category_${activeCategoryDetailWithRunningBalance.name.replace(/[^a-zA-Z0-9]/g, '_')}_Ledger.pdf`);
    } catch (e) {
      console.error(e);
    }
  };

  const handleExportCardCategoryExcel = () => {
    if (!activeCategoryDetailWithRunningBalance || !breakdownType) return;
    try {
      const data: (string | number)[][] = [];
      data.push(['GMP FASHIONS LTD.']);
      data.push([`CATEGORY LEDGER STATEMENT: ${activeCategoryDetailWithRunningBalance.name.toUpperCase()} (${breakdownType.toUpperCase()})`]);
      data.push([`Total Entries: ${activeCategoryDetailWithRunningBalance.itemsWithRunning.length} | Category Subtotal: BDT ${Math.round(activeCategoryDetailWithRunningBalance.total)}`]);
      data.push([]);
      data.push(['SL#', 'Date', 'Voucher No', 'Account / Bank', 'Remarks / Particulars', 'Amount (BDT)', 'Running Balance (BDT)']);

      activeCategoryDetailWithRunningBalance.itemsWithRunning.forEach((t, idx) => {
        const accName = t.type === 'Receipts' ? t.depositedBank : t.withdrawnBank;
        data.push([
          idx + 1,
          formatDateForDisplay(t.entryDate),
          t.voucherNo,
          cleanAccountName(accName || '-'),
          t.remarks || '-',
          Math.round(t.amount),
          Math.round(t.runningBalance)
        ]);
      });

      data.push([]);
      data.push(['-', '-', '-', '-', `TOTAL (${activeCategoryDetailWithRunningBalance.name.toUpperCase()}):`, Math.round(activeCategoryDetailWithRunningBalance.total), Math.round(activeCategoryDetailWithRunningBalance.runningTotal)]);

      const ws = XLSX.utils.aoa_to_sheet(data);
      
      const range = XLSX.utils.decode_range(ws['!ref'] || 'A1:G100');
      for (let R = range.s.r; R <= range.e.r; ++R) {
        for (let C = range.s.c; C <= range.e.c; ++C) {
          const cellRef = XLSX.utils.encode_cell({ r: R, c: C });
          if (!ws[cellRef]) continue;
          if (!ws[cellRef].s) ws[cellRef].s = {};
          if ((C === 5 || C === 6) && typeof ws[cellRef].v === 'number') {
            ws[cellRef].z = '#,##0';
          }
          if (R < 3) {
            ws[cellRef].s = {
              font: { bold: R < 2, name: 'Arial', sz: R === 0 ? 14 : 10 },
            };
          } else if (R === 4) {
            ws[cellRef].s = {
              fill: { fgColor: { rgb: '0F172A' } },
              font: { color: { rgb: 'FFFFFF' }, bold: true, name: 'Arial' },
              alignment: { horizontal: C === 5 || C === 6 ? 'right' : (C === 0 || C === 1 ? 'center' : 'left') },
            };
          } else if (R > 4) {
            const isTotalRow = R === range.e.r;
            if (isTotalRow) {
              ws[cellRef].s = {
                fill: { fgColor: { rgb: 'E2E8F0' } },
                font: { bold: true, name: 'Arial' },
              };
            } else if (R % 2 === 1) {
              ws[cellRef].s = {
                fill: { fgColor: { rgb: 'F8FAFC' } },
                font: { name: 'Arial' },
              };
            } else {
              ws[cellRef].s = {
                font: { name: 'Arial' },
              };
            }
          }
        }
      }

      ws['!cols'] = [
        { wch: 8 },
        { wch: 14 },
        { wch: 16 },
        { wch: 25 },
        { wch: 35 },
        { wch: 18 },
        { wch: 22 }
      ];
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Category Ledger');
      XLSX.writeFile(wb, `Category_${activeCategoryDetailWithRunningBalance.name.replace(/[^a-zA-Z0-9]/g, '_')}_Ledger.xlsx`);
    } catch (e) {
      console.error(e);
    }
  };

  const totalBreakdownSum = breakdownType === 'Receipts' ? totalReceipts : totalExpenses;

  const handleOpenBreakdown = (type: TransactionType) => {
    setBreakdownType(type);
    setSelectedCategory(null);
  };

  const handleCloseBreakdown = () => {
    setBreakdownType(null);
    setSelectedCategory(null);
  };

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. OPENING BALANCE CARD */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5 text-slate-700">
                <span className="bg-indigo-100 text-indigo-700 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black">1</span>
                Opening Balance
              </span>
              <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
                <Coins className="h-4 w-4" />
              </div>
            </div>

            <div className="text-2xl font-black text-slate-900 tracking-tight font-mono">
              ৳ {formatCurrency(totalOpening)}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
              <span className="text-[10px] text-slate-500 font-medium block">Cash Opening</span>
              <span className="font-bold font-mono text-slate-800">৳ {formatCurrency(cashOpening)}</span>
            </div>
            <div 
              onClick={() => setBankModalData({
                title: 'Opening Bank Balances Breakdown',
                subtitle: 'Individual opening balances for all registered bank accounts',
                balances: bankOpeningList
              })}
              className="bg-indigo-50/70 p-2 rounded-lg border border-indigo-100 hover:border-indigo-300 hover:bg-indigo-100/70 transition-all cursor-pointer group"
              title="Click to view bank-wise opening balances"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-indigo-700 font-bold block">Bank Opening</span>
                <Building2 className="h-3 w-3 text-indigo-500 group-hover:text-indigo-700 transition-colors" />
              </div>
              <span className="font-bold font-mono text-indigo-900 block">৳ {formatCurrency(bankOpening)}</span>
              <span className="text-[9px] text-indigo-600 font-medium block group-hover:underline">Click details →</span>
            </div>
          </div>
        </div>

        {/* 2. RECEIVED (INFLOW) CARD */}
        <div 
          onClick={() => handleOpenBreakdown('Receipts')}
          className="bg-white border border-emerald-200 rounded-xl p-4 sm:p-5 shadow-xs hover:border-emerald-400 hover:shadow-sm transition-all cursor-pointer group flex flex-col justify-between relative overflow-hidden"
          title="Click to view Category Breakdown"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-50 rounded-full -mr-8 -mt-8 pointer-events-none group-hover:scale-110 transition-transform" />
          
          <div>
            <div className="flex items-center justify-between text-emerald-800 text-xs font-bold uppercase tracking-wider mb-2 relative z-10">
              <span className="flex items-center gap-1.5 text-emerald-800">
                <span className="bg-emerald-100 text-emerald-800 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black">2</span>
                Received (Inflow)
              </span>
              <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700">
                <TrendingUp className="h-4 w-4" />
              </div>
            </div>

            <div className="text-2xl font-black text-emerald-600 tracking-tight font-mono relative z-10">
              +৳ {formatCurrency(totalReceipts)}
            </div>
            
            <p className="text-[11px] text-slate-500 mt-1 relative z-10">
              {receiptCount} receipt vouchers recorded
            </p>
          </div>

          <div className="mt-3 pt-2 border-t border-emerald-100 flex items-center justify-between text-xs font-bold text-emerald-700 group-hover:text-emerald-800 relative z-10">
            <span className="flex items-center gap-1">
              <PieChart className="h-3.5 w-3.5" />
              Click for Category Breakdown
            </span>
            <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* 3. PAYMENTS (OUTFLOW) CARD */}
        <div 
          onClick={() => handleOpenBreakdown('Expenses')}
          className="bg-white border border-rose-200 rounded-xl p-4 sm:p-5 shadow-xs hover:border-rose-400 hover:shadow-sm transition-all cursor-pointer group flex flex-col justify-between relative overflow-hidden"
          title="Click to view Category Breakdown"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-rose-50 rounded-full -mr-8 -mt-8 pointer-events-none group-hover:scale-110 transition-transform" />

          <div>
            <div className="flex items-center justify-between text-rose-800 text-xs font-bold uppercase tracking-wider mb-2 relative z-10">
              <span className="flex items-center gap-1.5 text-rose-800">
                <span className="bg-rose-100 text-rose-800 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black">3</span>
                Payments (Outflow)
              </span>
              <div className="p-2 rounded-lg bg-rose-100 text-rose-700">
                <TrendingDown className="h-4 w-4" />
              </div>
            </div>

            <div className="text-2xl font-black text-rose-600 tracking-tight font-mono relative z-10">
              -৳ {formatCurrency(totalExpenses)}
            </div>

            <p className="text-[11px] text-slate-500 mt-1 relative z-10">
              {expenseCount} expense vouchers recorded
            </p>
          </div>

          <div className="mt-3 pt-2 border-t border-rose-100 flex items-center justify-between text-xs font-bold text-rose-700 group-hover:text-rose-800 relative z-10">
            <span className="flex items-center gap-1">
              <PieChart className="h-3.5 w-3.5" />
              Click for Category Breakdown
            </span>
            <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* 4. CLOSING BALANCE CARD */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5 text-slate-700">
                <span className="bg-indigo-100 text-indigo-700 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black">4</span>
                Closing Balance
              </span>
              <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
                <Wallet className="h-4 w-4" />
              </div>
            </div>

            <div className="text-2xl font-black text-slate-900 tracking-tight font-mono">
              ৳ {formatCurrency(totalClosing)}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
              <span className="text-[10px] text-slate-500 font-medium block">Cash Current</span>
              <span className="font-bold font-mono text-slate-800">৳ {formatCurrency(cashCurrent)}</span>
            </div>
            <div 
              onClick={() => setBankModalData({
                title: 'Closing / Current Bank Balances Breakdown',
                subtitle: 'Individual current balances for all registered bank accounts',
                balances: bankCurrentList
              })}
              className="bg-indigo-50/70 p-2 rounded-lg border border-indigo-100 hover:border-indigo-300 hover:bg-indigo-100/70 transition-all cursor-pointer group"
              title="Click to view bank-wise current balances"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-indigo-700 font-bold block">Bank Current</span>
                <Building2 className="h-3 w-3 text-indigo-500 group-hover:text-indigo-700 transition-colors" />
              </div>
              <span className="font-bold font-mono text-indigo-900 block">৳ {formatCurrency(bankCurrent)}</span>
              <span className="text-[9px] text-indigo-600 font-medium block group-hover:underline">Click details →</span>
            </div>
          </div>
        </div>
      </div>

      {/* CATEGORY BREAKDOWN MODAL */}
      {breakdownType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className={`px-6 py-4 flex items-center justify-between text-white shrink-0 ${
              breakdownType === 'Receipts' ? 'bg-emerald-700' : 'bg-rose-700'
            }`}>
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-lg bg-white/20 backdrop-blur-md">
                  <PieChart className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white flex items-center gap-2">
                    <span>Category Breakdown: {breakdownType === 'Receipts' ? 'Received (Inflow)' : 'Payments (Outflow)'}</span>
                  </h3>
                  <p className="text-xs text-white/80">
                    Total: <span className="font-mono font-bold">৳ {formatCurrency(totalBreakdownSum)}</span> across {categoryBreakdownList.reduce((s, c) => s + c.count, 0)} vouchers
                  </p>
                </div>
              </div>

              <button
                onClick={handleCloseBreakdown}
                className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/20 transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto flex-1 space-y-5">
              
              {/* If a category is selected for drill-down */}
              {activeCategoryDetailWithRunningBalance ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between bg-slate-50 p-3 rounded-lg border border-slate-200 gap-2">
                    <div>
                      <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider block">Category Detail</span>
                      <h4 className="text-sm font-bold text-slate-900">{activeCategoryDetailWithRunningBalance.name}</h4>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={handlePrintCardCategoryDetail}
                        className="px-2.5 py-1 rounded bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors inline-flex items-center space-x-1 cursor-pointer"
                      >
                        <Printer className="h-3.5 w-3.5 text-slate-500" />
                        <span>Print</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleExportCardCategoryPdf}
                        className="px-2.5 py-1 rounded bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors inline-flex items-center space-x-1 cursor-pointer"
                      >
                        <Download className="h-3.5 w-3.5 text-slate-500" />
                        <span>PDF</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleExportCardCategoryExcel}
                        className="px-2.5 py-1 rounded bg-emerald-50 border border-emerald-300 hover:bg-emerald-100 text-emerald-800 font-semibold text-xs transition-colors inline-flex items-center space-x-1 cursor-pointer"
                      >
                        <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-600" />
                        <span>Excel</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setSelectedCategory(null)}
                        className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold underline cursor-pointer ml-2"
                      >
                        ← Back to Categories
                      </button>
                    </div>
                  </div>

                  <div className="overflow-x-auto border border-slate-200 rounded-lg">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-100 text-slate-700 border-b border-slate-200 font-bold uppercase tracking-wider">
                          <th className="py-2.5 px-3">Date</th>
                          <th className="py-2.5 px-3">Voucher No</th>
                          <th className="py-2.5 px-3">Account</th>
                          <th className="py-2.5 px-3">Remarks</th>
                          <th className="py-2.5 px-3 text-right">Amount (৳)</th>
                          <th className="py-2.5 px-3 text-right">Running Balance (৳)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 font-medium text-slate-800">
                        {activeCategoryDetailWithRunningBalance.itemsWithRunning.map((t) => (
                          <tr key={t.id} className="hover:bg-slate-50">
                            <td className="py-2 px-3 whitespace-nowrap font-mono">{formatDateForDisplay(t.entryDate)}</td>
                            <td className="py-2 px-3 font-mono font-bold text-indigo-700">{t.voucherNo}</td>
                            <td className="py-2 px-3">
                              {cleanAccountName(t.type === 'Receipts' ? (t.depositedBank || '') : (t.withdrawnBank || ''))}
                            </td>
                            <td className="py-2 px-3 text-slate-600 max-w-xs truncate">{t.remarks || '-'}</td>
                            <td className="py-2 px-3 text-right font-mono font-bold">
                              ৳ {formatCurrency(t.amount)}
                            </td>
                            <td className="py-2 px-3 text-right font-mono font-black text-indigo-900">
                              ৳ {formatCurrency(t.runningBalance)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="bg-slate-100 font-bold text-slate-900 border-t border-slate-300">
                          <td colSpan={4} className="py-2.5 px-3 text-right uppercase text-[11px]">
                            Total ({activeCategoryDetailWithRunningBalance.name}):
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold">
                            ৳ {formatCurrency(activeCategoryDetailWithRunningBalance.total)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-indigo-700 font-extrabold">
                            ৳ {formatCurrency(activeCategoryDetailWithRunningBalance.runningTotal)}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              ) : (
                /* Category List Summary */
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider">
                    <span>Category Name ({categoryBreakdownList.length})</span>
                    <span>Vouchers / Amount</span>
                  </div>

                  {categoryBreakdownList.length === 0 ? (
                    <div className="text-center py-8 text-slate-400 text-xs italic">
                      No vouchers found for {breakdownType}.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {categoryBreakdownList.map((cat) => {
                        const pct = totalBreakdownSum > 0 ? (cat.total / totalBreakdownSum) * 100 : 0;
                        return (
                          <div
                            key={cat.name}
                            onClick={() => setSelectedCategory(cat.name)}
                            className="p-3 rounded-xl border border-slate-200 hover:border-indigo-300 hover:bg-slate-50/80 transition-all cursor-pointer group space-y-1.5"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <Eye className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 transition-colors" />
                                <span className="font-bold text-xs text-slate-800 group-hover:text-indigo-900">
                                  {cat.name}
                                </span>
                                <span className="text-[10px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full font-mono">
                                  {cat.count} {cat.count === 1 ? 'entry' : 'entries'}
                                </span>
                              </div>

                              <div className="text-right">
                                <span className="font-mono font-extrabold text-sm text-slate-900 block">
                                  ৳ {formatCurrency(cat.total)}
                                </span>
                              </div>
                            </div>

                            {/* Progress bar */}
                            <div className="flex items-center gap-2">
                              <div className="flex-1 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div
                                  className={`h-full rounded-full ${
                                    breakdownType === 'Receipts' ? 'bg-emerald-500' : 'bg-rose-500'
                                  }`}
                                  style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
                                />
                              </div>
                              <span className="text-[10px] font-mono text-slate-500 w-10 text-right">
                                {pct.toFixed(1)}%
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <div className="text-xs text-slate-600 font-medium">
                Click any category above to see individual transaction vouchers.
              </div>
              <button
                type="button"
                onClick={handleCloseBreakdown}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

      {/* BANK BREAKDOWN MODAL */}
      {bankModalData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            
            {/* Modal Header */}
            <div className="px-6 py-4 bg-indigo-700 flex items-center justify-between text-white shrink-0">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-lg bg-white/20 backdrop-blur-md">
                  <Building2 className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    {bankModalData.title}
                  </h3>
                  {bankModalData.subtitle && (
                    <p className="text-xs text-indigo-100">
                      {bankModalData.subtitle}
                    </p>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={() => setBankModalData(null)}
                className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/20 transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto flex-1 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider pb-1 border-b border-slate-200">
                <span>Bank Account Name ({bankModalData.balances.length})</span>
                <span>Balance Amount (BDT)</span>
              </div>

              <div className="space-y-1.5">
                {bankModalData.balances.map((b) => {
                  const totalSum = bankModalData.balances.reduce((s, x) => s + x.amount, 0);
                  const pct = totalSum > 0 ? ((b.amount / totalSum) * 100).toFixed(1) : '0';
                  return (
                    <div
                      key={b.name}
                      className="flex items-center justify-between p-3 rounded-xl border border-slate-100 hover:border-indigo-200 hover:bg-indigo-50/40 transition-colors"
                    >
                      <div className="flex items-center space-x-2.5">
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center font-bold text-indigo-700 text-xs shrink-0">
                          {b.name.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <span className="font-bold text-sm text-slate-900 block">{b.name}</span>
                          <span className="text-[10px] text-slate-500 font-mono">{pct}% of total bank balance</span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="font-mono font-extrabold text-sm text-indigo-900 block">
                          ৳ {formatCurrency(b.amount)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Total Summary Row */}
              <div className="pt-3 border-t-2 border-slate-200 flex items-center justify-between font-bold text-sm text-slate-900 bg-slate-50 p-3 rounded-xl">
                <span>Total Bank Balance</span>
                <span className="font-mono text-indigo-700 text-base">
                  ৳ {formatCurrency(bankModalData.balances.reduce((s, x) => s + x.amount, 0))}
                </span>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end shrink-0">
              <button
                type="button"
                onClick={() => setBankModalData(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
