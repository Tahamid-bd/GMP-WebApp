import React, { useState } from 'react';
import { ViewTab } from '../types';
import {
  Receipt,
  BarChart3,
  FileText,
  Building2,
  FolderPlus,
  PlusCircle,
  Menu,
  X,
  ChevronRight,
} from 'lucide-react';

interface SidebarProps {
  activeTab: ViewTab;
  setActiveTab: (tab: ViewTab) => void;
  onOpenAddModal: () => void;
  onOpenOpeningModal: () => void;
  onOpenCategoryModal: () => void;
  onOpenHeaderModal?: () => void;
  onExportCSV?: () => void;
  onResetData: () => void;
  transactionCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddModal,
  onOpenOpeningModal,
  onOpenCategoryModal,
  onResetData,
  transactionCount,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems: { id: ViewTab; label: string; icon: React.ReactNode; desc: string }[] = [
    {
      id: 'register',
      label: 'All Transactions',
      icon: <Receipt className="h-5 w-5" />,
      desc: 'All vouchers & movements',
    },
    {
      id: 'accounts',
      label: 'Bank & Cash Accounts',
      icon: <Building2 className="h-5 w-5" />,
      desc: 'Liquid account balances',
    },
    {
      id: 'analytics',
      label: 'Analytics & Charts',
      icon: <BarChart3 className="h-5 w-5" />,
      desc: 'Financial reports',
    },
    {
      id: 'statement',
      label: 'Account Statement',
      icon: <FileText className="h-5 w-5" />,
      desc: 'Chronological ledger',
    },
  ];

  const handleTabClick = (tab: ViewTab) => {
    setActiveTab(tab);
    setIsOpen(false);
  };

  return (
    <>
      {/* Mobile Header Bar */}
      <div className="no-print md:hidden bg-slate-900 text-white px-4 py-2.5 flex items-center justify-between sticky top-0 z-30 shadow-md border-b border-slate-800">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 focus:outline-none"
          >
            {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
          <div className="flex items-center space-x-1.5">
            <div className="p-1.5 rounded-md bg-indigo-600 text-white">
              <Receipt className="h-4 w-4" />
            </div>
            <span className="font-bold tracking-tight text-white block text-xs truncate max-w-[100px] sm:max-w-[140px]">
              GMP Fashions
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="text-right shrink-0">
            <div className="text-[11px] font-semibold text-slate-200 leading-tight">
              Developed By <span className="text-indigo-400 font-bold">@ Tahamid</span>
            </div>
            <div className="text-[10px] font-mono font-medium text-slate-400 leading-tight mt-0.5">
              01977 87 87 18
            </div>
          </div>
          <button
            onClick={onOpenAddModal}
            className="p-1.5 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors"
            title="Add Transaction"
          >
            <PlusCircle className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Mobile Drawer Overlay */}
      {isOpen && (
        <div
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 md:hidden"
        />
      )}

      {/* Left Sidebar */}
      <aside
        className={`no-print fixed top-0 bottom-0 left-0 z-50 w-64 bg-slate-900 text-slate-300 flex flex-col transition-transform duration-200 ease-in-out md:static md:translate-x-0 ${
          isOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div
          className="p-5 border-b flex items-center justify-between"
          style={{
            backgroundColor: '#1b0b55',
            paddingBottom: '13px',
            borderColor: '#bfcce2',
            borderWidth: '1px',
          }}
        >
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-indigo-600 text-white shadow-md shadow-indigo-600/30">
              <Receipt className="h-6 w-6" />
            </div>
            <div>
              <h1 className="font-bold text-white text-base tracking-tight">
                GMP Fashions Ltd.
              </h1>
              <p
                style={{
                  fontSize: '8px',
                  lineHeight: '15px',
                  fontWeight: 'bold',
                  fontStyle: 'normal',
                  textDecorationLine: 'none',
                  color: '#f1a8ea',
                }}
              >
                Transaction Management Application
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="md:hidden text-slate-400 hover:text-white p-1"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Primary New Action Button */}
        <div className="p-4 pb-2">
          <button
            onClick={() => {
              onOpenAddModal();
              setIsOpen(false);
            }}
            style={{ backgroundColor: '#9fc8c8', color: '#2b1166' }}
            className="w-full font-bold py-2.5 px-4 rounded-xl shadow-md flex items-center justify-center space-x-2 transition-all hover:opacity-90 active:scale-[0.98] cursor-pointer"
          >
            <PlusCircle className="h-5 w-5" />
            <span>Add Transaction</span>
          </button>
        </div>

        {/* Main Navigation Menu */}
        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-6">
          <div>
            <div className="px-3 mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Navigation Menu
            </div>
            <nav className="space-y-1">
              {navItems.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleTabClick(item.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl font-medium text-sm transition-all cursor-pointer ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20 font-semibold'
                        : 'text-slate-300 hover:bg-slate-700/60 hover:text-white active:bg-slate-600/70'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`${isActive ? 'text-white' : 'text-slate-400'}`}>
                        {item.icon}
                      </div>
                      <div className="text-left">
                        <div className="leading-snug">{item.label}</div>
                        <div
                          className={`text-[10px] ${
                            isActive ? 'text-indigo-100' : 'text-slate-500'
                          }`}
                        >
                          {item.desc}
                        </div>
                      </div>
                    </div>
                    {isActive && <ChevronRight className="h-4 w-4 text-white/80" />}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Quick Setup & Tools */}
          <div>
            <div className="px-3 mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Quick Tools
            </div>
            <div className="space-y-1">
              <button
                onClick={() => {
                  onOpenOpeningModal();
                  setIsOpen(false);
                }}
                className="w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-medium text-slate-300 hover:bg-slate-700/60 hover:text-white active:bg-slate-600/70 transition-colors cursor-pointer"
              >
                <Building2 className="h-4 w-4 text-indigo-400" />
                <span>Add New Bank</span>
              </button>

              <button
                onClick={() => {
                  onOpenCategoryModal();
                  setIsOpen(false);
                }}
                className="w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-medium text-slate-300 hover:bg-slate-700/60 hover:text-white active:bg-slate-600/70 transition-colors cursor-pointer"
              >
                <FolderPlus className="h-4 w-4 text-slate-400" />
                <span>Manage Categories</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-slate-800 text-center">
          <div className="inline-flex items-center justify-center px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700/50 text-[12px] font-medium text-slate-300">
            <span>Developed By <span className="text-indigo-400 font-semibold">@ Tahamid</span></span>
          </div>
        </div>
      </aside>
    </>
  );
};
