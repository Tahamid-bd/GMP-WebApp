import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { Upload, FileSpreadsheet, Download, X, CheckCircle2, AlertCircle, FileCheck, ArrowRight } from 'lucide-react';
import { Transaction, TransactionType, TransactionMode } from '../types';
import { formatCurrency } from '../utils/finance';

interface BulkImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportTransactions: (imported: Transaction[]) => void;
}

export const BulkImportModal: React.FC<BulkImportModalProps> = ({
  isOpen,
  onClose,
  onImportTransactions,
}) => {
  if (!isOpen) return null;

  const [parsedRows, setParsedRows] = useState<Transaction[]>([]);
  const [fileName, setFileName] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Generate and download blank Excel template
  const handleDownloadBlankTemplate = () => {
    const headers = [
      'Entry Date (YYYY-MM-DD)',
      'Voucher No',
      'Type (Receipts / Expenses / Contra)',
      'Category',
      'Mode (Bank / Cash / Bank→Cash / Cash→Bank / Bank→Bank)',
      'Withdrawn Bank / Cheque No',
      'Deposited Bank / Particulars',
      'Amount (BDT)',
      'Remarks',
    ];

    const exampleRows = [
      [
        '2026-08-01',
        'V-1001',
        'Receipts',
        'Sales Revenue',
        'Bank',
        'N/A',
        'Pubali Bank Ltd',
        50000,
        'Advance payment received for order #402',
      ],
      [
        '2026-08-02',
        'V-1002',
        'Expenses',
        'Office Expenses',
        'Cash',
        'Cash',
        'N/A',
        2500,
        'Tea, snacks and stationery items',
      ],
      [
        '2026-08-03',
        'V-1003',
        'Contra',
        'Cash Withdrawal',
        'Bank→Cash',
        'Pubali Bank Ltd',
        'Cash',
        15000,
        'Self cheque cash withdraw from bank',
      ],
    ];

    const wsData = [headers, ...exampleRows];
    const ws = XLSX.utils.aoa_to_sheet(wsData);

    // Style column widths
    ws['!cols'] = [
      { wch: 22 },
      { wch: 15 },
      { wch: 32 },
      { wch: 22 },
      { wch: 45 },
      { wch: 25 },
      { wch: 25 },
      { wch: 16 },
      { wch: 35 },
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Import Template');

    XLSX.writeFile(wb, 'Bulk_Transaction_Import_Template.xlsx');
  };

  // Handle File Upload & Excel Parsing
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setErrorMsg(null);
    setIsProcessing(true);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary', cellDates: true });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];

        // Parse to JSON array
        const rawData: any[] = XLSX.utils.sheet_to_json(ws, { header: 1 });

        if (!rawData || rawData.length < 2) {
          throw new Error('Excel file is empty or missing data rows.');
        }

        const rows = rawData.slice(1); // skip header row
        const validTransactions: Transaction[] = [];

        rows.forEach((row, idx) => {
          if (!row || row.length === 0) return;

          const rawDate = row[0]?.toString().trim();
          const rawVoucher = row[1]?.toString().trim();
          const rawType = row[2]?.toString().trim();
          const rawCategory = row[3]?.toString().trim();
          const rawMode = row[4]?.toString().trim();
          const rawWithdrawn = row[5]?.toString().trim();
          const rawDeposited = row[6]?.toString().trim();
          const rawAmount = parseFloat(row[7]?.toString().replace(/,/g, '') || '0');
          const rawRemarks = row[8]?.toString().trim();

          if (!rawDate && !rawAmount && !rawCategory) return; // skip empty lines

          let type: TransactionType = 'Receipts';
          if (rawType) {
            const lower = rawType.toLowerCase();
            if (lower.includes('exp') || lower.includes('pay')) type = 'Expenses';
            else if (lower.includes('contra')) type = 'Contra';
          }

          let mode: TransactionMode = 'Bank';
          if (rawMode) {
            if (rawMode.includes('Cash')) mode = 'Cash';
            else if (rawMode.includes('Bank→Cash')) mode = 'Bank→Cash';
            else if (rawMode.includes('Cash→Bank')) mode = 'Cash→Bank';
            else if (rawMode.includes('Bank→Bank')) mode = 'Bank→Bank';
          }

          validTransactions.push({
            id: `tnx-import-${Date.now()}-${idx}`,
            entryDate: rawDate || new Date().toISOString().split('T')[0],
            voucherNo: rawVoucher || `V-IMP-${1000 + idx}`,
            type,
            category: rawCategory || (type === 'Receipts' ? 'Sales Revenue' : 'Office Expenses'),
            mode,
            withdrawnBank: rawWithdrawn || (type === 'Receipts' ? 'N/A' : 'Pubali Bank Ltd'),
            depositedBank: rawDeposited || (type === 'Receipts' ? 'Pubali Bank Ltd' : 'N/A'),
            amount: isNaN(rawAmount) ? 0 : rawAmount,
            remarks: rawRemarks || 'Imported via Bulk Import',
            createdAt: Date.now() - idx * 100,
          });
        });

        if (validTransactions.length === 0) {
          throw new Error('No valid transaction rows found in the uploaded file.');
        }

        setParsedRows(validTransactions);
      } catch (err: any) {
        console.error('File parsing error:', err);
        setErrorMsg(err.message || 'Failed to read Excel/CSV file.');
        setParsedRows([]);
      } finally {
        setIsProcessing(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  const handleConfirmImport = () => {
    if (parsedRows.length === 0) return;
    onImportTransactions(parsedRows);
    onClose();
  };

  // Stats for parsed rows
  const totalInflow = parsedRows.filter((t) => t.type === 'Receipts').reduce((sum, t) => sum + t.amount, 0);
  const totalOutflow = parsedRows.filter((t) => t.type === 'Expenses').reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/65 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-emerald-500/20 border border-emerald-500/30 rounded-lg">
              <Upload className="h-5 w-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Bulk Data Import (Excel / CSV)</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Upload multiple transaction records at once using Excel or CSV file.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          
          {/* Top Banner: Download Template */}
          <div className="p-4 bg-indigo-50/80 border border-indigo-200 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h4 className="text-xs font-bold text-indigo-950 flex items-center space-x-1.5">
                <FileSpreadsheet className="h-4 w-4 text-indigo-600" />
                <span>Need a formatted Excel template first?</span>
              </h4>
              <p className="text-[11px] text-indigo-800 mt-0.5">
                Download a ready-to-use blank Excel template with headers & example rows.
              </p>
            </div>
            <button
              type="button"
              onClick={handleDownloadBlankTemplate}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-lg flex items-center space-x-1.5 transition-colors shadow-2xs cursor-pointer shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download Blank Template</span>
            </button>
          </div>

          {/* File Upload Zone */}
          <div className="border-2 border-dashed border-slate-300 hover:border-emerald-500 bg-slate-50/60 hover:bg-emerald-50/20 rounded-xl p-6 text-center transition-all cursor-pointer relative">
            <input
              type="file"
              accept=".xlsx, .xls, .csv"
              onChange={handleFileUpload}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
            />
            <div className="space-y-2 pointer-events-none">
              <Upload className="h-8 w-8 text-emerald-600 mx-auto" />
              <div className="text-xs font-bold text-slate-800">
                {fileName ? (
                  <span className="text-emerald-700 font-mono">Uploaded: {fileName}</span>
                ) : (
                  <span>Click or drag & drop Excel / CSV file here</span>
                )}
              </div>
              <p className="text-[11px] text-slate-500">Supports .xlsx, .xls, and .csv files</p>
            </div>
          </div>

          {/* Processing Spinner */}
          {isProcessing && (
            <div className="py-4 text-center text-xs text-slate-600 font-medium">
              Parsing Excel sheet data...
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-center space-x-2">
              <AlertCircle className="h-4 w-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Parsed Rows Preview */}
          {parsedRows.length > 0 && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between bg-slate-100 p-3 rounded-lg border border-slate-200">
                <div className="flex items-center space-x-2">
                  <FileCheck className="h-4 w-4 text-emerald-600" />
                  <span className="text-xs font-bold text-slate-900">
                    Parsed {parsedRows.length} transaction records successfully
                  </span>
                </div>
                <div className="text-xs font-semibold text-slate-700 space-x-2">
                  <span className="text-emerald-700">Inflow: +৳{formatCurrency(totalInflow)}</span>
                  <span>|</span>
                  <span className="text-rose-700">Outflow: -৳{formatCurrency(totalOutflow)}</span>
                </div>
              </div>

              {/* Table Preview */}
              <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-lg text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-800 text-white font-semibold text-[11px] sticky top-0">
                    <tr>
                      <th className="p-2">Date</th>
                      <th className="p-2">Voucher</th>
                      <th className="p-2">Type</th>
                      <th className="p-2">Category</th>
                      <th className="p-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                    {parsedRows.slice(0, 15).map((r, i) => (
                      <tr key={i} className="hover:bg-slate-50">
                        <td className="p-2 font-mono">{r.entryDate}</td>
                        <td className="p-2 font-mono font-bold">{r.voucherNo}</td>
                        <td className="p-2">{r.type}</td>
                        <td className="p-2">{r.category}</td>
                        <td className="p-2 text-right font-bold">৳{formatCurrency(r.amount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {parsedRows.length > 15 && (
                  <p className="p-2 text-[11px] text-slate-500 text-center bg-slate-50 italic">
                    ...and {parsedRows.length - 15} more rows
                  </p>
                )}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end space-x-2 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold text-xs rounded-lg transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleConfirmImport}
            disabled={parsedRows.length === 0}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-bold text-xs rounded-lg flex items-center space-x-1.5 transition-colors shadow-2xs cursor-pointer"
          >
            <span>Import {parsedRows.length > 0 ? `${parsedRows.length} Transactions` : ''}</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
