import React, { useState } from 'react';
import { Trash2, RotateCcw, X, AlertOctagon, FileText, Layers, Building2, CheckCircle2 } from 'lucide-react';
import { Transaction, TransactionType, AccountOpeningBalance } from '../types';
import { formatCurrency, formatDateForDisplay } from '../utils/finance';

interface TrashBinModalProps {
  isOpen: boolean;
  onClose: () => void;
  deletedTransactions: Transaction[];
  deletedCategories: { type: TransactionType; name: string }[];
  deletedAccounts: AccountOpeningBalance[];
  onRestoreTransaction: (id: string) => void;
  onRestoreCategory: (category: { type: TransactionType; name: string }) => void;
  onRestoreAccount: (id: string) => void;
  onPermanentDeleteTransaction: (id: string) => void;
  onPermanentDeleteCategory: (category: { type: TransactionType; name: string }) => void;
  onPermanentDeleteAccount: (id: string) => void;
  onEmptyAllTrash: () => void;
}

export const TrashBinModal: React.FC<TrashBinModalProps> = ({
  isOpen,
  onClose,
  deletedTransactions,
  deletedCategories,
  deletedAccounts,
  onRestoreTransaction,
  onRestoreCategory,
  onRestoreAccount,
  onPermanentDeleteTransaction,
  onPermanentDeleteCategory,
  onPermanentDeleteAccount,
  onEmptyAllTrash,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'transactions' | 'categories' | 'accounts'>('transactions');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const totalTrashItems =
    deletedTransactions.length + deletedCategories.length + deletedAccounts.length;

  const showNotification = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/65 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-xl max-w-3xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-rose-500/20 border border-rose-500/30 rounded-lg">
              <Trash2 className="h-5 w-5 text-rose-400" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white flex items-center space-x-2">
                <span>Recycle Bin & Deleted Data Restore</span>
                <span className="px-2 py-0.5 text-xs font-semibold bg-rose-500/30 text-rose-200 rounded-full">
                  {totalTrashItems} {totalTrashItems === 1 ? 'item' : 'items'}
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Restore deleted transactions, categories, or bank accounts back to active records anytime.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Success Toast */}
        {successMsg && (
          <div className="px-6 py-2.5 bg-emerald-600 text-white text-xs font-medium flex items-center space-x-2 animate-fade-in shrink-0">
            <CheckCircle2 className="h-4 w-4 text-emerald-200" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Category Navigation Tabs */}
        <div className="px-6 pt-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveTab('transactions')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg border-b-2 flex items-center space-x-1.5 transition-all cursor-pointer ${
                activeTab === 'transactions'
                  ? 'border-rose-600 text-rose-700 bg-white shadow-2xs font-bold'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="h-3.5 w-3.5" />
              <span>Transactions ({deletedTransactions.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('categories')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg border-b-2 flex items-center space-x-1.5 transition-all cursor-pointer ${
                activeTab === 'categories'
                  ? 'border-rose-600 text-rose-700 bg-white shadow-2xs font-bold'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="h-3.5 w-3.5" />
              <span>Categories ({deletedCategories.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('accounts')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg border-b-2 flex items-center space-x-1.5 transition-all cursor-pointer ${
                activeTab === 'accounts'
                  ? 'border-rose-600 text-rose-700 bg-white shadow-2xs font-bold'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Building2 className="h-3.5 w-3.5" />
              <span>Bank Accounts ({deletedAccounts.length})</span>
            </button>
          </div>

          {totalTrashItems > 0 && (
            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to permanently clear ALL items in the Recycle Bin? This action cannot be undone.')) {
                  onEmptyAllTrash();
                  showNotification('Recycle Bin emptied successfully!');
                }
              }}
              className="mb-2 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-semibold rounded-lg flex items-center space-x-1.5 transition-colors cursor-pointer"
            >
              <AlertOctagon className="h-3.5 w-3.5 text-rose-600" />
              <span>Empty Trash</span>
            </button>
          )}
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          
          {/* TAB 1: DELETED TRANSACTIONS */}
          {activeTab === 'transactions' && (
            <div>
              {deletedTransactions.length === 0 ? (
                <div className="py-12 text-center text-slate-400 space-y-2">
                  <Trash2 className="h-8 w-8 mx-auto text-slate-300" />
                  <p className="text-xs font-medium">No deleted transactions in Recycle Bin.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {deletedTransactions.map((tnx) => (
                    <div
                      key={tnx.id}
                      className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-mono font-bold text-slate-900 bg-slate-200 px-2 py-0.5 rounded">
                            {tnx.voucherNo}
                          </span>
                          <span className="font-semibold text-slate-700">
                            {formatDateForDisplay(tnx.entryDate)}
                          </span>
                          <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-slate-200 text-slate-800">
                            {tnx.type}
                          </span>
                        </div>
                        <p className="text-slate-600">
                          <strong>Category:</strong> {tnx.category} | <strong>Amount:</strong>{' '}
                          <span className="font-bold font-mono text-slate-900">
                            ৳ {formatCurrency(tnx.amount)}
                          </span>
                        </p>
                        {tnx.remarks && (
                          <p className="text-[11px] text-slate-400 italic">
                            Remarks: {tnx.remarks}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center space-x-2 shrink-0 self-end sm:self-auto">
                        <button
                          onClick={() => {
                            onRestoreTransaction(tnx.id);
                            showNotification(`Restored Voucher ${tnx.voucherNo}`);
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg flex items-center space-x-1 transition-colors shadow-2xs cursor-pointer"
                        >
                          <RotateCcw className="h-3.5 w-3.5" />
                          <span>Restore</span>
                        </button>
                        <button
                          onClick={() => {
                            onPermanentDeleteTransaction(tnx.id);
                            showNotification(`Permanently deleted Voucher ${tnx.voucherNo}`);
                          }}
                          className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold rounded-lg flex items-center space-x-1 transition-colors cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          <span>Purge</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: DELETED CATEGORIES */}
          {activeTab === 'categories' && (
            <div>
              {deletedCategories.length === 0 ? (
                <div className="py-12 text-center text-slate-400 space-y-2">
                  <Layers className="h-8 w-8 mx-auto text-slate-300" />
                  <p className="text-xs font-medium">No deleted categories in Recycle Bin.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {deletedCategories.map((cat, idx) => (
                    <div
                      key={`${cat.type}-${cat.name}-${idx}`}
                      className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs gap-3"
                    >
                      <div>
                        <span className="font-bold text-slate-900">{cat.name}</span>
                        <span className="ml-2 px-2 py-0.5 text-[10px] font-semibold bg-indigo-100 text-indigo-800 rounded">
                          {cat.type}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => {
                            onRestoreCategory(cat);
                            showNotification(`Restored category ${cat.name}`);
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg flex items-center space-x-1 transition-colors cursor-pointer"
                        >
                          <RotateCcw className="h-3.5 w-3.5" />
                          <span>Restore</span>
                        </button>
                        <button
                          onClick={() => {
                            onPermanentDeleteCategory(cat);
                            showNotification(`Permanently deleted category ${cat.name}`);
                          }}
                          className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold rounded-lg flex items-center space-x-1 transition-colors cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          <span>Purge</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: DELETED ACCOUNTS */}
          {activeTab === 'accounts' && (
            <div>
              {deletedAccounts.length === 0 ? (
                <div className="py-12 text-center text-slate-400 space-y-2">
                  <Building2 className="h-8 w-8 mx-auto text-slate-300" />
                  <p className="text-xs font-medium">No deleted bank accounts in Recycle Bin.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {deletedAccounts.map((acc) => (
                    <div
                      key={acc.id}
                      className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs gap-3"
                    >
                      <div>
                        <span className="font-bold text-slate-900">{acc.name}</span>
                        <span className="ml-2 font-mono text-slate-600">
                          Opening: ৳ {formatCurrency(acc.amount)}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => {
                            onRestoreAccount(acc.id);
                            showNotification(`Restored account ${acc.name}`);
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg flex items-center space-x-1 transition-colors cursor-pointer"
                        >
                          <RotateCcw className="h-3.5 w-3.5" />
                          <span>Restore</span>
                        </button>
                        <button
                          onClick={() => {
                            onPermanentDeleteAccount(acc.id);
                            showNotification(`Permanently deleted account ${acc.name}`);
                          }}
                          className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold rounded-lg flex items-center space-x-1 transition-colors cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          <span>Purge</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs rounded-lg cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
