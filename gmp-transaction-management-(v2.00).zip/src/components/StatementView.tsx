import React, { useState, useMemo } from 'react';
import XLSX from 'xlsx-js-style';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { AccountOpeningBalance, Transaction, TransactionType } from '../types';
import { RECEIPT_CATEGORIES, EXPENSE_CATEGORIES } from '../data/initialData';
import { calculateTransactionsWithRunningBalance, formatCurrency, formatDateForDisplay } from '../utils/finance';
import { 
  FileText, 
  Printer, 
  Download, 
  Calendar, 
  Building2, 
  CheckCircle2, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Search, 
  ChevronRight,
  Eye,
  X,
  Scale,
  FileSpreadsheet,
  RotateCcw,
  ArrowUpDown,
  ExternalLink
} from 'lucide-react';
import { exportStatementToGoogleSheets, exportCategoryLedgerToGoogleSheets } from '../lib/googleSheets';

interface StatementViewProps {
  transactions: Transaction[];
  accounts: AccountOpeningBalance[];
  categories?: { type: TransactionType; name: string }[];
}

export const StatementView: React.FC<StatementViewProps> = ({ transactions, accounts, categories }) => {
  // Period filter states
  const [startDate, setStartDate] = useState<string>('2026-07-01');
  const [endDate, setEndDate] = useState<string>('2026-07-31');
  const [selectedAccount, setSelectedAccount] = useState<string>('All');
  
  // Drill-down category state
  const [selectedCategoryDetail, setSelectedCategoryDetail] = useState<{
    category: string;
    type: 'Receipts' | 'Expenses';
  } | null>(null);

  // Category sorting state (Defaults to Name A-Z)
  const [receiptSortField, setReceiptSortField] = useState<'name' | 'amount'>('name');
  const [receiptSortOrder, setReceiptSortOrder] = useState<'asc' | 'desc'>('asc');

  const [expenseSortField, setExpenseSortField] = useState<'name' | 'amount'>('name');
  const [expenseSortOrder, setExpenseSortOrder] = useState<'asc' | 'desc'>('asc');

  // Opening & Closing Balances sorting state
  const [openingSortField, setOpeningSortField] = useState<'name' | 'amount'>('name');
  const [openingSortOrder, setOpeningSortOrder] = useState<'asc' | 'desc'>('asc');

  const [closingSortField, setClosingSortField] = useState<'name' | 'amount'>('name');
  const [closingSortOrder, setClosingSortOrder] = useState<'asc' | 'desc'>('asc');

  // Google Sheets Export State
  const [isExportingSheets, setIsExportingSheets] = useState(false);
  const [exportedSheetUrl, setExportedSheetUrl] = useState<string | null>(null);

  // Helper to clean account names (removes "Opening: ", "Closing: ", " Account")
  const cleanAccountName = (accName: string) => {
    return accName
      .replace(/^Opening:\s*/i, '')
      .replace(/^Closing:\s*/i, '')
      .replace(/\s*Account$/i, '')
      .trim();
  };

  // Quick Date presets
  const handleQuickPreset = (preset: 'all' | 'jul2026' | 'thisMonth') => {
    if (preset === 'all') {
      setStartDate('');
      setEndDate('');
    } else if (preset === 'jul2026') {
      setStartDate('2026-07-01');
      setEndDate('2026-07-31');
    } else if (preset === 'thisMonth') {
      const now = new Date();
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
      const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().slice(0, 10);
      setStartDate(firstDay);
      setEndDate(lastDay);
    }
  };

  // Master Receipt Categories (includes defaults + custom + transactions)
  const allReceiptCategories = useMemo(() => {
    const set = new Set<string>(RECEIPT_CATEGORIES);
    if (categories) {
      categories.filter(c => c.type === 'Receipts').forEach(c => set.add(c.name));
    }
    transactions.filter(t => t.type === 'Receipts').forEach(t => {
      if (t.category) set.add(t.category);
    });
    return Array.from(set);
  }, [categories, transactions]);

  // Master Expense Categories (includes defaults + custom + transactions)
  const allExpenseCategories = useMemo(() => {
    const set = new Set<string>(EXPENSE_CATEGORIES);
    if (categories) {
      categories.filter(c => c.type === 'Expenses').forEach(c => set.add(c.name));
    }
    transactions.filter(t => t.type === 'Expenses').forEach(t => {
      if (t.category) set.add(t.category);
    });
    return Array.from(set);
  }, [categories, transactions]);

  // Filter transactions by date range
  const filteredInPeriod = useMemo(() => {
    return transactions.filter((t) => {
      // Date bounds
      if (startDate && t.entryDate < startDate) return false;
      if (endDate && t.entryDate > endDate) return false;

      // Account filter
      if (selectedAccount !== 'All') {
        const isWithdrawn = t.withdrawnBank === selectedAccount;
        const isDeposited = t.depositedBank === selectedAccount;
        if (!isWithdrawn && !isDeposited) return false;
      }

      return true;
    });
  }, [transactions, startDate, endDate, selectedAccount]);

  // Compute Opening Balances as of start date (All accounts included)
  const openingBalances = useMemo(() => {
    const map: Record<string, number> = {};
    accounts.forEach((a) => {
      if (selectedAccount === 'All' || a.name === selectedAccount) {
        map[a.name] = a.amount;
      }
    });

    if (!startDate) {
      return map;
    }

    // Get transactions PRIOR to startDate
    const priorTransactions = transactions.filter((t) => t.entryDate < startDate);
    
    // Apply prior transactions
    priorTransactions.forEach((t) => {
      if (t.type === 'Receipts') {
        if (t.depositedBank && map[t.depositedBank] !== undefined) {
          map[t.depositedBank] += t.amount;
        }
      } else if (t.type === 'Expenses') {
        if (t.withdrawnBank && map[t.withdrawnBank] !== undefined) {
          map[t.withdrawnBank] -= t.amount;
        }
      } else if (t.type === 'Contra') {
        if (t.withdrawnBank && map[t.withdrawnBank] !== undefined) {
          map[t.withdrawnBank] -= t.amount;
        }
        if (t.depositedBank && map[t.depositedBank] !== undefined) {
          map[t.depositedBank] += t.amount;
        }
      }
    });

    return map;
  }, [transactions, accounts, startDate, selectedAccount]);

  const totalOpeningBalance = useMemo(() => {
    return (Object.values(openingBalances) as number[]).reduce((sum: number, val: number) => sum + val, 0);
  }, [openingBalances]);

  // Sorted Opening Balances
  const sortedOpeningBalances = useMemo(() => {
    return Object.entries(openingBalances)
      .map(([accName, amt]) => ({ name: accName, amount: Number(amt) || 0 }))
      .sort((a, b) => {
        if (openingSortField === 'name') {
          const cleanA = cleanAccountName(a.name);
          const cleanB = cleanAccountName(b.name);
          const comp = cleanA.localeCompare(cleanB);
          return openingSortOrder === 'asc' ? comp : -comp;
        } else {
          const comp = a.amount - b.amount;
          return openingSortOrder === 'asc' ? comp : -comp;
        }
      });
  }, [openingBalances, openingSortField, openingSortOrder]);

  // Aggregate Receipts by Category (Includes ALL master categories even if 0)
  const receiptsByCategory = useMemo(() => {
    const map: Record<string, { total: number; count: number }> = {};
    
    // Initialize ALL master receipt categories with 0
    allReceiptCategories.forEach((cat) => {
      map[cat] = { total: 0, count: 0 };
    });

    filteredInPeriod
      .filter((t) => t.type === 'Receipts')
      .forEach((t) => {
        const cat = t.category || 'Uncategorized';
        if (!map[cat]) {
          map[cat] = { total: 0, count: 0 };
        }
        map[cat].total += Number(t.amount) || 0;
        map[cat].count += 1;
      });

    return Object.entries(map)
      .map(([name, data]) => ({ name, amount: data.total, count: data.count }))
      .sort((a, b) => {
        if (receiptSortField === 'name') {
          const comp = a.name.localeCompare(b.name);
          return receiptSortOrder === 'asc' ? comp : -comp;
        } else {
          const comp = a.amount - b.amount;
          return receiptSortOrder === 'asc' ? comp : -comp;
        }
      });
  }, [allReceiptCategories, filteredInPeriod, receiptSortField, receiptSortOrder]);

  const totalReceipts = useMemo(() => {
    return receiptsByCategory.reduce((sum, r) => sum + r.amount, 0);
  }, [receiptsByCategory]);

  // Aggregate Payments (Expenses) by Category (Includes ALL master categories even if 0)
  const paymentsByCategory = useMemo(() => {
    const map: Record<string, { total: number; count: number }> = {};

    // Initialize ALL master expense categories with 0
    allExpenseCategories.forEach((cat) => {
      map[cat] = { total: 0, count: 0 };
    });

    filteredInPeriod
      .filter((t) => t.type === 'Expenses')
      .forEach((t) => {
        const cat = t.category || 'Uncategorized';
        if (!map[cat]) {
          map[cat] = { total: 0, count: 0 };
        }
        map[cat].total += Number(t.amount) || 0;
        map[cat].count += 1;
      });

    return Object.entries(map)
      .map(([name, data]) => ({ name, amount: data.total, count: data.count }))
      .sort((a, b) => {
        if (expenseSortField === 'name') {
          const comp = a.name.localeCompare(b.name);
          return expenseSortOrder === 'asc' ? comp : -comp;
        } else {
          const comp = a.amount - b.amount;
          return expenseSortOrder === 'asc' ? comp : -comp;
        }
      });
  }, [allExpenseCategories, filteredInPeriod, expenseSortField, expenseSortOrder]);

  const totalPayments = useMemo(() => {
    return paymentsByCategory.reduce((sum, p) => sum + p.amount, 0);
  }, [paymentsByCategory]);

  // Calculate Closing Balances as of end of period (All accounts included)
  const closingBalances = useMemo(() => {
    const map: Record<string, number> = { ...openingBalances };

    filteredInPeriod.forEach((t) => {
      if (t.type === 'Receipts') {
        if (t.depositedBank && map[t.depositedBank] !== undefined) {
          map[t.depositedBank] += t.amount;
        }
      } else if (t.type === 'Expenses') {
        if (t.withdrawnBank && map[t.withdrawnBank] !== undefined) {
          map[t.withdrawnBank] -= t.amount;
        }
      } else if (t.type === 'Contra') {
        if (t.withdrawnBank && map[t.withdrawnBank] !== undefined) {
          map[t.withdrawnBank] -= t.amount;
        }
        if (t.depositedBank && map[t.depositedBank] !== undefined) {
          map[t.depositedBank] += t.amount;
        }
      }
    });

    return map;
  }, [openingBalances, filteredInPeriod]);

  const totalClosingBalance = useMemo(() => {
    return (Object.values(closingBalances) as number[]).reduce((sum: number, val: number) => sum + val, 0);
  }, [closingBalances]);

  // Sorted Closing Balances
  const sortedClosingBalances = useMemo(() => {
    return Object.entries(closingBalances)
      .map(([accName, amt]) => ({ name: accName, amount: Number(amt) || 0 }))
      .sort((a, b) => {
        if (closingSortField === 'name') {
          const cleanA = cleanAccountName(a.name);
          const cleanB = cleanAccountName(b.name);
          const comp = cleanA.localeCompare(cleanB);
          return closingSortOrder === 'asc' ? comp : -comp;
        } else {
          const comp = a.amount - b.amount;
          return closingSortOrder === 'asc' ? comp : -comp;
        }
      });
  }, [closingBalances, closingSortField, closingSortOrder]);

  // State for Bank Breakdown Modal & Category Breakdown Modal
  const [bankModalData, setBankModalData] = useState<{
    title: string;
    subtitle?: string;
    balances: { name: string; amount: number }[];
  } | null>(null);

  const [categoryBreakdownType, setCategoryBreakdownType] = useState<'Receipts' | 'Expenses' | null>(null);

  // Helper opening cash & bank balances
  const openingCash = useMemo(() => {
    const cashKey = Object.keys(openingBalances).find((k) => k.toLowerCase() === 'cash');
    return cashKey ? openingBalances[cashKey] : 0;
  }, [openingBalances]);

  const openingBankList = useMemo(() => {
    return Object.entries(openingBalances)
      .filter(([accName]) => accName.toLowerCase() !== 'cash')
      .map(([accName, amount]) => ({
        name: cleanAccountName(accName),
        amount: Number(amount) || 0,
      }));
  }, [openingBalances]);

  const openingBankTotal = useMemo(() => {
    return openingBankList.reduce((sum, b) => sum + b.amount, 0);
  }, [openingBankList]);

  // Helper closing cash & bank balances
  const closingCash = useMemo(() => {
    const cashKey = Object.keys(closingBalances).find((k) => k.toLowerCase() === 'cash');
    return cashKey ? closingBalances[cashKey] : 0;
  }, [closingBalances]);

  const closingBankList = useMemo(() => {
    return Object.entries(closingBalances)
      .filter(([accName]) => accName.toLowerCase() !== 'cash')
      .map(([accName, amount]) => ({
        name: cleanAccountName(accName),
        amount: Number(amount) || 0,
      }));
  }, [closingBalances]);

  const closingBankTotal = useMemo(() => {
    return closingBankList.reduce((sum, b) => sum + b.amount, 0);
  }, [closingBankList]);

  // Statement Totals Check
  const totalReceiptsSide = totalOpeningBalance + totalReceipts;
  const totalPaymentsSide = totalPayments + totalClosingBalance;
  const isBalanced = Math.abs(totalReceiptsSide - totalPaymentsSide) < 0.01;

  // ERP Ledger View calculations for selected category detail modal
  const detailOpeningBalance = useMemo(() => {
    if (!selectedCategoryDetail || !startDate) return 0;
    return transactions
      .filter((t) => {
        if (t.type !== selectedCategoryDetail.type || t.category !== selectedCategoryDetail.category) return false;
        if (selectedAccount !== 'All') {
          const accName = t.type === 'Receipts' ? t.depositedBank : t.withdrawnBank;
          if (accName !== selectedAccount) return false;
        }
        return t.entryDate < startDate;
      })
      .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
  }, [transactions, selectedCategoryDetail, startDate, selectedAccount]);

  const detailTransactionsWithRunningBalance = useMemo(() => {
    if (!selectedCategoryDetail) return [];

    const filtered = filteredInPeriod.filter(
      (t) => t.type === selectedCategoryDetail.type && t.category === selectedCategoryDetail.category
    );

    const sorted = [...filtered].sort((a, b) => {
      const dateCompare = a.entryDate.localeCompare(b.entryDate);
      if (dateCompare !== 0) return dateCompare;
      return (a.createdAt || 0) - (b.createdAt || 0);
    });

    let running = detailOpeningBalance;
    return sorted.map((t) => {
      const amt = Number(t.amount) || 0;
      running += amt;
      return {
        ...t,
        runningBalance: running,
      };
    });
  }, [filteredInPeriod, selectedCategoryDetail, detailOpeningBalance]);

  const detailPeriodTotal = useMemo(() => {
    return detailTransactionsWithRunningBalance.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
  }, [detailTransactionsWithRunningBalance]);

  const detailClosingBalance = detailOpeningBalance + detailPeriodTotal;

  // Print Category Detail Ledger
  const handlePrintCategoryDetail = () => {
    if (!selectedCategoryDetail) return;
    try {
      let rowsHtml = '';
      
      // Opening Balance Row
      rowsHtml += `
        <tr style="background-color: #f1f5f9; font-weight: bold;">
          <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: center;">-</td>
          <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace;">${startDate ? formatDateForDisplay(startDate) : 'Baseline'}</td>
          <td style="padding: 6px 10px; border: 1px solid #cbd5e1; color: #475569;" colspan="3">OPENING BALANCE (${selectedCategoryDetail.category.toUpperCase()})</td>
          <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: right; font-family: monospace;">-</td>
          <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold; font-family: monospace; color: #1e293b;">${formatCurrency(detailOpeningBalance)}</td>
        </tr>
      `;

      detailTransactionsWithRunningBalance.forEach((t, idx) => {
        const bg = idx % 2 === 1 ? 'background-color: #f8fafc;' : '';
        const accName = t.type === 'Receipts' ? t.depositedBank : t.withdrawnBank;
        rowsHtml += `
          <tr style="${bg}">
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace;">${idx + 1}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace;">${formatDateForDisplay(t.entryDate)}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold; font-family: monospace; color: #4338ca;">${t.voucherNo}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1;">${cleanAccountName(accName || '-')}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; color: #475569;">${t.remarks || '-'}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold; font-family: monospace;">${formatCurrency(t.amount)}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold; font-family: monospace; color: #10b981;">${formatCurrency(t.runningBalance)}</td>
          </tr>
        `;
      });

      // Closing Balance Row
      rowsHtml += `
        <tr style="background-color: #e2e8f0; font-weight: bold; font-size: 11px;">
          <td style="padding: 8px 10px; border: 1px solid #cbd5e1; text-align: center;">-</td>
          <td style="padding: 8px 10px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace;">${endDate ? formatDateForDisplay(endDate) : 'Present'}</td>
          <td style="padding: 8px 10px; border: 1px solid #cbd5e1; color: #0f172a;" colspan="3">CLOSING BALANCE (${selectedCategoryDetail.category.toUpperCase()})</td>
          <td style="padding: 8px 10px; border: 1px solid #cbd5e1; text-align: right; font-family: monospace;">৳ ${formatCurrency(detailPeriodTotal)}</td>
          <td style="padding: 8px 10px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold; font-family: monospace; color: #4338ca;">৳ ${formatCurrency(detailClosingBalance)}</td>
        </tr>
      `;

      const periodText = `Period: ${startDate ? formatDateForDisplay(startDate) : 'Baseline'} to ${endDate ? formatDateForDisplay(endDate) : 'Present'}`;

      const printHtml = `
        <!DOCTYPE html>
        <html>
          <head>
            <title>${selectedCategoryDetail.category} - Category Ledger Statement</title>
            <style>
              @page { size: A4 portrait; margin: 12mm; }
              body { font-family: Arial, sans-serif; font-size: 11px; color: #0f172a; margin: 0; padding: 15px; }
              .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #0f172a; padding-bottom: 10px; }
              .header h1 { margin: 0; font-size: 18px; text-transform: uppercase; }
              .header h2 { margin: 4px 0; font-size: 14px; font-weight: bold; color: #4338ca; }
              .header p { margin: 2px 0; font-size: 10px; color: #64748b; }
              table { width: 100%; border-collapse: collapse; margin-top: 15px; }
              th { background-color: #1e293b; color: #ffffff; padding: 8px 10px; font-size: 10px; text-transform: uppercase; border: 1px solid #1e293b; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>GMP FASHIONS LTD.</h1>
              <h2>CATEGORY LEDGER STATEMENT: ${selectedCategoryDetail.category.toUpperCase()} (${selectedCategoryDetail.type.toUpperCase()})</h2>
              <p>${periodText}</p>
              <p>Opening: BDT ${formatCurrency(detailOpeningBalance)} | Period Entries: ${detailTransactionsWithRunningBalance.length} | Closing: BDT ${formatCurrency(detailClosingBalance)}</p>
            </div>

            <table>
              <thead>
                <tr>
                  <th style="width: 35px; text-align: center;">SL#</th>
                  <th style="width: 80px; text-align: center;">DATE</th>
                  <th style="width: 90px;">VOUCHER NO</th>
                  <th>ACCOUNT / BANK</th>
                  <th>REMARKS / PARTICULARS</th>
                  <th style="width: 100px; text-align: right;">AMOUNT (BDT)</th>
                  <th style="width: 110px; text-align: right;">RUNNING BAL (BDT)</th>
                </tr>
              </thead>
              <tbody>
                ${rowsHtml}
              </tbody>
            </table>
          </body>
        </html>
      `;

      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(printHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
        }, 300);
      }
    } catch (e) {
      console.error('Failed to print category details', e);
    }
  };

  // Export Category Details to PDF
  const handleExportCategoryPdf = () => {
    if (!selectedCategoryDetail) return;
    try {
      const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text('GMP FASHIONS LTD.', 105, 15, { align: 'center' });

      doc.setFontSize(12);
      doc.setTextColor(67, 56, 202);
      doc.text(`CATEGORY LEDGER: ${selectedCategoryDetail.category.toUpperCase()}`, 105, 22, { align: 'center' });

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      const periodStr = `Period: ${startDate ? formatDateForDisplay(startDate) : 'Baseline'} to ${endDate ? formatDateForDisplay(endDate) : 'Present'} | Scope: ${selectedAccount}`;
      doc.text(periodStr, 105, 27, { align: 'center' });

      const tableRows: string[][] = [];

      // Opening Balance Row
      tableRows.push([
        '-',
        startDate ? formatDateForDisplay(startDate) : 'Baseline',
        '-',
        `OPENING BALANCE (${selectedCategoryDetail.category.toUpperCase()})`,
        '-',
        '-',
        formatCurrency(detailOpeningBalance)
      ]);

      detailTransactionsWithRunningBalance.forEach((t, idx) => {
        const accName = t.type === 'Receipts' ? t.depositedBank : t.withdrawnBank;
        tableRows.push([
          (idx + 1).toString(),
          formatDateForDisplay(t.entryDate),
          t.voucherNo,
          cleanAccountName(accName || '-'),
          t.remarks || '-',
          formatCurrency(t.amount),
          formatCurrency(t.runningBalance)
        ]);
      });

      // Closing Balance Row
      tableRows.push([
        '-',
        endDate ? formatDateForDisplay(endDate) : 'Present',
        '-',
        `CLOSING BALANCE (${selectedCategoryDetail.category.toUpperCase()})`,
        '-',
        `BDT ${formatCurrency(detailPeriodTotal)}`,
        `BDT ${formatCurrency(detailClosingBalance)}`
      ]);

      autoTable(doc, {
        startY: 33,
        head: [['SL#', 'DATE', 'VOUCHER NO', 'ACCOUNT / BANK', 'REMARKS / PARTICULARS', 'AMOUNT (BDT)', 'RUNNING BAL (BDT)']],
        body: tableRows,
        theme: 'striped',
        headStyles: {
          fillColor: [15, 23, 42],
          textColor: [255, 255, 255],
          fontStyle: 'bold',
          fontSize: 8.5,
          halign: 'left',
        },
        columnStyles: {
          0: { halign: 'center', cellWidth: 10 },
          1: { halign: 'center', cellWidth: 22 },
          2: { halign: 'left', cellWidth: 24, fontStyle: 'bold' },
          3: { halign: 'left', cellWidth: 32 },
          4: { halign: 'left' },
          5: { halign: 'right', cellWidth: 28, fontStyle: 'bold' },
          6: { halign: 'right', cellWidth: 30, fontStyle: 'bold' },
        },
        styles: {
          fontSize: 8,
          cellPadding: 2,
        },
        didParseCell: (data) => {
          if (data.section === 'head') {
            data.cell.styles.fillColor = [15, 23, 42];
            data.cell.styles.textColor = [255, 255, 255];
            data.cell.styles.fontStyle = 'bold';
          } else if (data.row.index === 0 || data.row.index === tableRows.length - 1) {
            data.cell.styles.fontStyle = 'bold';
            data.cell.styles.fillColor = [241, 245, 249];
            if (data.column.index === 6) {
              data.cell.styles.textColor = [67, 56, 202];
            }
          }
        }
      });

      doc.save(`Category_Ledger_${selectedCategoryDetail.category.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`);
    } catch (e) {
      console.error('Failed to export category PDF', e);
    }
  };

  // Export Category Details to Excel
  const handleExportCategoryExcel = () => {
    if (!selectedCategoryDetail) return;
    try {
      const data: (string | number)[][] = [];

      data.push(['GMP FASHIONS LTD.']);
      data.push([`CATEGORY LEDGER STATEMENT: ${selectedCategoryDetail.category.toUpperCase()} (${selectedCategoryDetail.type.toUpperCase()})`]);
      data.push([`Period: ${startDate ? formatDateForDisplay(startDate) : 'Baseline'} to ${endDate ? formatDateForDisplay(endDate) : 'Present'} | Account Scope: ${selectedAccount}`]);
      data.push([`Opening: BDT ${Math.round(detailOpeningBalance)} | Total Entries: ${detailTransactionsWithRunningBalance.length} | Period Net Total: BDT ${Math.round(detailPeriodTotal)} | Closing: BDT ${Math.round(detailClosingBalance)}`]);
      data.push([]);

      data.push(['SL#', 'Date', 'Voucher No', 'Account / Bank', 'Remarks / Particulars', 'Amount (BDT)', 'Running Balance (BDT)']);

      // Opening balance row
      data.push(['-', startDate ? formatDateForDisplay(startDate) : 'Baseline', '-', 'Scope: ' + selectedAccount, 'OPENING BALANCE (' + selectedCategoryDetail.category.toUpperCase() + ')', '-', Math.round(detailOpeningBalance)]);

      detailTransactionsWithRunningBalance.forEach((t, idx) => {
        const accName = t.type === 'Receipts' ? t.depositedBank : t.withdrawnBank;
        data.push([
          idx + 1,
          formatDateForDisplay(t.entryDate),
          t.voucherNo,
          cleanAccountName(accName || '-'),
          t.remarks || '-',
          Math.round(t.amount),
          Math.round(t.runningBalance)
        ]);
      });

      // Closing balance row
      data.push(['-', endDate ? formatDateForDisplay(endDate) : 'Present', '-', '-', 'CLOSING BALANCE (' + selectedCategoryDetail.category.toUpperCase() + ')', Math.round(detailPeriodTotal), Math.round(detailClosingBalance)]);

      const ws = XLSX.utils.aoa_to_sheet(data);

      ws['!cols'] = [
        { wch: 8 },
        { wch: 14 },
        { wch: 16 },
        { wch: 25 },
        { wch: 35 },
        { wch: 18 },
        { wch: 22 }
      ];

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Category Ledger');
      XLSX.writeFile(wb, `Category_Ledger_${selectedCategoryDetail.category.replace(/[^a-zA-Z0-9]/g, '_')}.xlsx`);
    } catch (e) {
      console.error('Failed to export category Excel', e);
    }
  };

  // Export Category Details to Google Sheets
  const handleExportCategoryToGoogleSheets = async () => {
    if (!selectedCategoryDetail) return;
    try {
      setIsExportingSheets(true);
      const rows = detailTransactionsWithRunningBalance.map((t, idx) => ({
        sl: idx + 1,
        date: formatDateForDisplay(t.entryDate),
        voucherNo: t.voucherNo,
        account: cleanAccountName((t.type === 'Receipts' ? t.depositedBank : t.withdrawnBank) || '-'),
        remarks: t.remarks || '-',
        amount: Math.round(t.amount),
        runningBalance: Math.round(t.runningBalance),
      }));

      const res = await exportCategoryLedgerToGoogleSheets(
        selectedCategoryDetail.category,
        selectedCategoryDetail.type,
        rows,
        detailPeriodTotal,
        detailClosingBalance
      );

      setExportedSheetUrl(res.spreadsheetUrl);
      window.open(res.spreadsheetUrl, '_blank');
    } catch (err: any) {
      console.error('Failed to export Category to Google Sheets', err);
      alert('Google Sheets Export Error: ' + (err.message || err));
    } finally {
      setIsExportingSheets(false);
    }
  };

  // Print Handler - Multi-strategy print trigger
  const handlePrint = () => {
    try {
      let openingRows = '';
      Object.entries(openingBalances).forEach(([acc, amt]) => {
        openingRows += `
          <tr>
            <td style="padding-left: 20px;">${cleanAccountName(acc)}</td>
            <td style="text-align: right; font-weight: bold;">${formatCurrency(Number(amt))}</td>
          </tr>
        `;
      });

      let receiptRows = '';
      receiptsByCategory.forEach((r, idx) => {
        const bg = idx % 2 === 1 ? 'background-color: #e2e8f0;' : '';
        receiptRows += `
          <tr style="${bg}">
            <td style="padding-left: 20px;">${r.name}</td>
            <td style="text-align: right; font-weight: bold;">${formatCurrency(r.amount)}</td>
          </tr>
        `;
      });

      let paymentRows = '';
      paymentsByCategory.forEach((p, idx) => {
        const bg = idx % 2 === 1 ? 'background-color: #e2e8f0;' : '';
        paymentRows += `
          <tr style="${bg}">
            <td style="padding-left: 20px;">${p.name}</td>
            <td style="text-align: right; font-weight: bold;">${formatCurrency(p.amount)}</td>
          </tr>
        `;
      });

      let closingRows = '';
      Object.entries(closingBalances).forEach(([acc, amt]) => {
        closingRows += `
          <tr>
            <td style="padding-left: 20px;">${cleanAccountName(acc)}</td>
            <td style="text-align: right; font-weight: bold;">${formatCurrency(Number(amt))}</td>
          </tr>
        `;
      });

      const periodText = `For the Period: ${startDate ? formatDateForDisplay(startDate) : 'Beginning'} to ${endDate ? formatDateForDisplay(endDate) : 'Present'}`;

      const fullPrintHtml = `
        <!DOCTYPE html>
        <html>
          <head>
            <title>Receipts & Payments Statement - GMP Fashions Ltd.</title>
            <style>
              @page { size: A4 portrait; margin: 10mm; }
              body { font-family: Arial, sans-serif; font-size: 11px; color: #0f172a; margin: 0; padding: 15px; }
              .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #0f172a; padding-bottom: 10px; }
              .header h1 { margin: 0; font-size: 18px; text-transform: uppercase; letter-spacing: 0.5px; }
              .header h2 { margin: 4px 0; font-size: 13px; font-weight: normal; color: #334155; }
              .header p { margin: 2px 0; font-size: 10px; color: #64748b; }
              table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
              th, td { border: 1px solid #cbd5e1; padding: 6px 10px; }
              th { background-color: #1e293b; color: #ffffff; font-weight: bold; text-align: left; }
              .sec-header { background-color: #cbd5e1; font-weight: bold; color: #0f172a; }
              .subtotal-row { background-color: #e2e8f0; font-weight: bold; }
              .total-row { background-color: #0f172a; color: #ffffff; font-weight: bold; font-size: 12px; }
              .text-right { text-align: right; }
              .signatures { display: flex; justify-content: space-between; margin-top: 50px; font-weight: bold; font-size: 10px; }
              .sig-box { border-top: 1px solid #64748b; width: 130px; text-align: center; padding-top: 4px; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>GMP FASHIONS LTD.</h1>
              <h2>RECEIPTS AND PAYMENTS STATEMENT</h2>
              <p>${periodText}</p>
              <p>Currency: BDT</p>
            </div>

            <table>
              <thead>
                <tr>
                  <th>PARTICULARS / CATEGORY</th>
                  <th style="text-align: right; width: 160px;">AMOUNT (BDT)</th>
                </tr>
              </thead>
              <tbody>
                <tr class="sec-header"><td colspan="2">1. OPENING BALANCES</td></tr>
                ${openingRows}
                <tr class="subtotal-row">
                  <td>SUBTOTAL OPENING BALANCES (A)</td>
                  <td class="text-right">${formatCurrency(totalOpeningBalance)}</td>
                </tr>

                <tr class="sec-header"><td colspan="2">2. RECEIPTS (INFLOWS) BY CATEGORY</td></tr>
                ${receiptRows}
                <tr class="subtotal-row">
                  <td>SUBTOTAL TOTAL RECEIPTS (B)</td>
                  <td class="text-right">${formatCurrency(totalReceipts)}</td>
                </tr>

                <tr class="sec-header"><td colspan="2">3. PAYMENTS & EXPENSES (OUTFLOWS)</td></tr>
                ${paymentRows}
                <tr class="subtotal-row">
                  <td>SUBTOTAL TOTAL PAYMENTS (C)</td>
                  <td class="text-right">${formatCurrency(totalPayments)}</td>
                </tr>

                <tr class="sec-header"><td colspan="2">4. CLOSING BALANCES</td></tr>
                ${closingRows}
                <tr class="subtotal-row">
                  <td>SUBTOTAL CLOSING BALANCES (D)</td>
                  <td class="text-right">${formatCurrency(totalClosingBalance)}</td>
                </tr>

                <tr class="sec-header"><td colspan="2">5. STATEMENT SUMMARY</td></tr>
                <tr class="subtotal-row">
                  <td>TOTAL RECEIPTS SIDE (Opening A + Receipts B)</td>
                  <td class="text-right">${formatCurrency(totalReceiptsSide)}</td>
                </tr>
                <tr class="subtotal-row">
                  <td>TOTAL PAYMENTS SIDE (Payments C + Closing D)</td>
                  <td class="text-right">${formatCurrency(totalPaymentsSide)}</td>
                </tr>
              </tbody>
            </table>

            <div class="signatures">
              <div class="sig-box">Prepared By</div>
              <div class="sig-box">Approved By</div>
            </div>
          </body>
        </html>
      `;

      // Strategy 1: Open popup window
      const printWin = window.open('', '_blank', 'width=900,height=800');
      if (printWin) {
        printWin.document.open();
        printWin.document.write(fullPrintHtml);
        printWin.document.close();
        setTimeout(() => {
          printWin.focus();
          printWin.print();
        }, 300);
        return;
      }

      // Strategy 2: Hidden Iframe
      const printIframe = document.createElement('iframe');
      printIframe.style.position = 'fixed';
      printIframe.style.right = '0';
      printIframe.style.bottom = '0';
      printIframe.style.width = '0';
      printIframe.style.height = '0';
      printIframe.style.border = '0';
      document.body.appendChild(printIframe);

      const frameDoc = printIframe.contentWindow?.document;
      if (frameDoc) {
        frameDoc.open();
        frameDoc.write(fullPrintHtml);
        frameDoc.close();
        setTimeout(() => {
          printIframe.contentWindow?.focus();
          printIframe.contentWindow?.print();
          setTimeout(() => {
            if (document.body.contains(printIframe)) {
              document.body.removeChild(printIframe);
            }
          }, 1000);
        }, 300);
        return;
      }

      // Fallback
      window.print();
    } catch (err) {
      console.error('Print trigger error:', err);
      window.print();
    }
  };

  // Export PDF Handler - 2 Columns, No Currency Symbol, Arial Font, Deeper Zebra Formatting
  const handleExportPDF = () => {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

    // Company Header
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('GMP FASHIONS LTD.', 105, 15, { align: 'center' });

    doc.setFontSize(12);
    doc.text('RECEIPTS AND PAYMENTS STATEMENT', 105, 22, { align: 'center' });

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    const periodStr = `For the Period: ${startDate ? formatDateForDisplay(startDate) : 'Beginning'} to ${endDate ? formatDateForDisplay(endDate) : 'Present'}`;
    doc.text(periodStr, 105, 27, { align: 'center' });
    doc.text('Currency: BDT', 105, 32, { align: 'center' });

    const tableData: (string | number)[][] = [];

    // Section 1: Opening Balances
    tableData.push(['1. OPENING BALANCES', '']);
    Object.entries(openingBalances).forEach(([acc, amt]) => {
      tableData.push([`  ${cleanAccountName(acc)}`, formatCurrency(Number(amt))]);
    });
    tableData.push(['SUBTOTAL OPENING BALANCES (A)', formatCurrency(totalOpeningBalance)]);

    // Section 2: Receipts
    tableData.push(['2. RECEIPTS (INFLOWS) BY CATEGORY', '']);
    receiptsByCategory.forEach((r) => {
      tableData.push([`  ${r.name}`, formatCurrency(r.amount)]);
    });
    tableData.push(['SUBTOTAL TOTAL RECEIPTS (B)', formatCurrency(totalReceipts)]);

    // Section 3: Payments
    tableData.push(['3. PAYMENTS & EXPENSES (OUTFLOWS)', '']);
    paymentsByCategory.forEach((p) => {
      tableData.push([`  ${p.name}`, formatCurrency(p.amount)]);
    });
    tableData.push(['SUBTOTAL TOTAL PAYMENTS (C)', formatCurrency(totalPayments)]);

    // Section 4: Closing Balances
    tableData.push(['4. CLOSING BALANCES', '']);
    Object.entries(closingBalances).forEach(([acc, amt]) => {
      tableData.push([`  ${cleanAccountName(acc)}`, formatCurrency(Number(amt))]);
    });
    tableData.push(['SUBTOTAL CLOSING BALANCES (D)', formatCurrency(totalClosingBalance)]);

    // Section 5: Statement Summary
    tableData.push(['5. STATEMENT SUMMARY', '']);
    tableData.push(['TOTAL RECEIPTS SIDE (Opening A + Receipts B)', formatCurrency(totalReceiptsSide)]);
    tableData.push(['TOTAL PAYMENTS SIDE (Payments C + Closing D)', formatCurrency(totalPaymentsSide)]);

    autoTable(doc, {
      startY: 37,
      head: [['Particulars / Category', 'Amount (BDT)']],
      body: tableData,
      theme: 'grid',
      styles: { font: 'helvetica', fontSize: 9, cellPadding: 2.8, textColor: [15, 23, 42] },
      headStyles: { fillColor: [30, 41, 59], textColor: [255, 255, 255], fontStyle: 'bold', font: 'helvetica' },
      columnStyles: {
        0: { cellWidth: 140, font: 'helvetica' },
        1: { cellWidth: 45, halign: 'right', fontStyle: 'bold', font: 'helvetica' },
      },
      didParseCell: function (data) {
        const rawText = String(data.row.raw[0] || '');
        if (rawText.match(/^[1-5]\./)) {
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [203, 213, 225]; // #CBD5E1 deep slate
          data.cell.styles.textColor = [15, 23, 42];
        } else if (rawText.startsWith('SUBTOTAL') || rawText.startsWith('TOTAL')) {
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [226, 232, 240]; // #E2E8F0
          data.cell.styles.textColor = [15, 23, 42];
        } else if (data.section === 'body') {
          // Deeper Zebra Striping for alternating data rows
          if (data.row.index % 2 === 1) {
            data.cell.styles.fillColor = [226, 232, 240]; // #E2E8F0 visible zebra
          }
        }
      },
    });

    doc.save(`Receipts_and_Payments_Statement_${startDate || 'all'}_to_${endDate || 'all'}.pdf`);
  };

  // Export XLSX Handler - 2 Columns, No Currency Symbol, No .00, Comma Separators (#,##0), Arial Font, Deeper Zebra Formatting
  const handleExportStatementXLSX = () => {
    const wb = XLSX.utils.book_new();
    const data: (string | number)[][] = [];

    // Title Block
    data.push(['GMP FASHIONS LTD.', '']);
    data.push(['RECEIPTS AND PAYMENTS STATEMENT', '']);
    data.push([`For the Period: ${startDate ? formatDateForDisplay(startDate) : 'Beginning'} to ${endDate ? formatDateForDisplay(endDate) : 'Present'}`, '']);
    data.push(['Currency: BDT', '']);
    data.push([]); // blank row

    // Table Column Headers (2 Columns)
    data.push([
      'PARTICULARS / CATEGORY',
      'AMOUNT (BDT)',
    ]);

    // Section 1: Opening Balances
    data.push(['1. OPENING BALANCES', '']);
    Object.entries(openingBalances).forEach(([acc, amt]) => {
      data.push([`  ${cleanAccountName(acc)}`, Math.round(Number(amt))]);
    });
    data.push(['SUBTOTAL OPENING BALANCES (A)', Math.round(totalOpeningBalance)]);
    data.push([]);

    // Section 2: Receipts (Inflows)
    data.push(['2. RECEIPTS (INFLOWS) BY CATEGORY', '']);
    receiptsByCategory.forEach((r) => {
      data.push([`  ${r.name}`, Math.round(r.amount)]);
    });
    data.push(['SUBTOTAL TOTAL RECEIPTS (B)', Math.round(totalReceipts)]);
    data.push([]);

    // Section 3: Payments (Outflows)
    data.push(['3. PAYMENTS & EXPENSES (OUTFLOWS)', '']);
    paymentsByCategory.forEach((p) => {
      data.push([`  ${p.name}`, Math.round(p.amount)]);
    });
    data.push(['SUBTOTAL TOTAL PAYMENTS (C)', Math.round(totalPayments)]);
    data.push([]);

    // Section 4: Closing Balances
    data.push(['4. CLOSING BALANCES', '']);
    Object.entries(closingBalances).forEach(([acc, amt]) => {
      data.push([`  ${cleanAccountName(acc)}`, Math.round(Number(amt))]);
    });
    data.push(['SUBTOTAL CLOSING BALANCES (D)', Math.round(totalClosingBalance)]);
    data.push([]);

    // Section 5: Statement Summary
    data.push(['5. STATEMENT SUMMARY', '']);
    data.push(['TOTAL RECEIPTS SIDE (Opening A + Receipts B)', Math.round(totalReceiptsSide)]);
    data.push(['TOTAL PAYMENTS SIDE (Payments C + Closing D)', Math.round(totalPaymentsSide)]);

    const ws = XLSX.utils.aoa_to_sheet(data);

    // Apply Zebra Formatting & Cell Styles & Arial Font & Comma Separator No Decimals (#,##0)
    const range = XLSX.utils.decode_range(ws['!ref'] || 'A1:B100');
    let itemDataRow = 0;

    for (let R = range.s.r; R <= range.e.r; ++R) {
      for (let C = range.s.c; C <= range.e.c; ++C) {
        const cellRef = XLSX.utils.encode_cell({ r: R, c: C });
        if (!ws[cellRef]) continue;

        if (!ws[cellRef].s) ws[cellRef].s = {};

        // Format numeric cells as pure integer with commas: #,##0 (NO .00)
        if (C === 1 && typeof ws[cellRef].v === 'number') {
          ws[cellRef].z = '#,##0';
        }

        // Title Rows
        if (R < 4) {
          ws[cellRef].s = {
            font: { bold: R < 2, name: 'Arial', sz: R === 0 ? 14 : 11 },
          };
        } else if (R === 5) {
          // Table Header
          ws[cellRef].s = {
            fill: { fgColor: { rgb: '1E293B' } },
            font: { color: { rgb: 'FFFFFF' }, bold: true, name: 'Arial' },
            alignment: { horizontal: C === 1 ? 'right' : 'left' },
          };
        } else if (R > 5) {
          const valStr = String(ws[cellRef].v || '');
          const col0Val = String(ws[XLSX.utils.encode_cell({ r: R, c: 0 })]?.v || '');

          if (valStr.match(/^[1-5]\./) || col0Val.match(/^[1-5]\./)) {
            ws[cellRef].s = {
              fill: { fgColor: { rgb: 'CBD5E1' } }, // Deep slate
              font: { bold: true, color: { rgb: '0F172A' }, name: 'Arial' },
            };
          } else if (valStr.startsWith('SUBTOTAL') || valStr.startsWith('TOTAL') || col0Val.startsWith('SUBTOTAL') || col0Val.startsWith('TOTAL')) {
            ws[cellRef].s = {
              fill: { fgColor: { rgb: 'E2E8F0' } }, // Accent slate
              font: { bold: true, color: { rgb: '0F172A' }, name: 'Arial' },
            };
          } else if (col0Val !== '') {
            if (C === 0) itemDataRow++;
            // Deep Zebra striping for even data rows
            if (itemDataRow % 2 === 0) {
              ws[cellRef].s = {
                fill: { fgColor: { rgb: 'F1F5F9' } }, // Visible gray-blue zebra
                font: { name: 'Arial' },
              };
            } else {
              ws[cellRef].s = {
                font: { name: 'Arial' },
              };
            }
          }
        }
      }
    }

    // Set Column Widths for clean 2-column layout
    ws['!cols'] = [
      { wch: 60 }, // Particulars / Category
      { wch: 25 }, // Amount (BDT)
    ];

    XLSX.utils.book_append_sheet(wb, ws, 'R&P Statement');
    XLSX.writeFile(wb, `Receipts_and_Payments_Statement_${startDate || 'all'}_to_${endDate || 'all'}.xlsx`);
  };

  // Export Statement to Google Sheets
  const handleExportStatementGoogleSheets = async () => {
    try {
      setIsExportingSheets(true);

      const openingArray = sortedOpeningBalances.map(acc => ({ name: cleanAccountName(acc.name), amount: acc.amount }));
      const receiptsArray = receiptsByCategory.map(r => ({ name: r.name, amount: r.amount, count: r.count }));
      const expensesArray = paymentsByCategory.map(e => ({ name: e.name, amount: e.amount, count: e.count }));
      const closingArray = sortedClosingBalances.map(acc => ({ name: cleanAccountName(acc.name), amount: acc.amount }));

      const res = await exportStatementToGoogleSheets({
        title: 'GMP FASHIONS LTD.',
        periodText: `${startDate ? formatDateForDisplay(startDate) : 'Beginning'} to ${endDate ? formatDateForDisplay(endDate) : 'Present'}`,
        scopeText: selectedAccount === 'All' ? 'Consolidated All Bank & Cash Accounts' : `Account: ${selectedAccount}`,
        openingBalances: openingArray,
        openingTotal: totalOpeningBalance,
        receipts: receiptsArray,
        receiptsTotal: totalReceipts,
        expenses: expensesArray,
        expensesTotal: totalPayments,
        closingBalances: closingArray,
        closingTotal: totalClosingBalance,
      });

      setExportedSheetUrl(res.spreadsheetUrl);
      window.open(res.spreadsheetUrl, '_blank');
    } catch (err: any) {
      console.error('Failed to export statement to Google Sheets', err);
      alert('Google Sheets Export Error: ' + (err.message || err));
    } finally {
      setIsExportingSheets(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Printable CSS style sheet override for clean PDF/print output */}
      <style>{`
        @media print {
          @page {
            size: A4 portrait;
            margin: 10mm 8mm 10mm 8mm;
          }
          html, body, #root, main {
            background-color: #ffffff !important;
            color: #000000 !important;
            padding: 0 !important;
            margin: 0 !important;
            overflow: visible !important;
            height: auto !important;
          }
          header, nav, aside, .no-print, .no-print * {
            display: none !important;
            height: 0 !important;
            width: 0 !important;
            overflow: hidden !important;
          }
          .print-container {
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            box-shadow: none !important;
            border: none !important;
            display: block !important;
          }
        }
      `}</style>

      {/* Top Controls Bar (No Print) */}
      <div
        className="no-print bg-white border border-slate-200 p-5 rounded-xl shadow-sm space-y-4"
        style={{ borderWidth: '2.8px', borderColor: '#7a8088' }}
      >
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <FileText className="h-5 w-5 text-indigo-600" />
            <span>Receipts & Payments Statement</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Summary of opening cash/bank balances, categorized inflows (receipts), outflows (payments), and closing liquid balances.
          </p>
        </div>

        {/* Filters and Presets */}
        <div
          className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-200"
          style={{ borderColor: '#5a5c5f' }}
        >
          
          {/* Preset Buttons */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">
              Quick Period
            </label>
            <div className="flex gap-1">
              <button
                type="button"
                onClick={() => handleQuickPreset('jul2026')}
                className="flex-1 py-1 px-2 text-xs bg-slate-100 hover:bg-slate-200 text-slate-800 rounded font-medium border border-slate-200 transition-colors cursor-pointer"
              >
                Jul 2026
              </button>
              <button
                type="button"
                onClick={() => handleQuickPreset('thisMonth')}
                className="flex-1 py-1 px-2 text-xs bg-slate-100 hover:bg-slate-200 text-slate-800 rounded font-medium border border-slate-200 transition-colors cursor-pointer"
              >
                This Month
              </button>
              <button
                type="button"
                onClick={() => handleQuickPreset('all')}
                className="flex-1 py-1 px-2 text-xs bg-slate-100 hover:bg-slate-200 text-slate-800 rounded font-medium border border-slate-200 transition-colors cursor-pointer"
              >
                All Time
              </button>
            </div>
          </div>

          {/* Date From */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1 flex items-center gap-1">
              <Calendar className="h-3 w-3 text-indigo-600" />
              Statement From Date
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-md px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Date To */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1 flex items-center gap-1">
              <Calendar className="h-3 w-3 text-indigo-600" />
              Statement To Date
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-md px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

        </div>
      </div>

      {/* Dedicated Action Section (Below Filter Area) */}
      <div className="no-print bg-white border border-slate-200 p-4 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-2 text-slate-800 text-xs font-bold uppercase tracking-wider">
          <Printer className="h-4 w-4 text-indigo-600" />
          <span>Statement Export & Print Actions</span>
        </div>
        <div className="flex items-center space-x-2 flex-wrap gap-y-2">
          <button
            type="button"
            onClick={() => {
              setStartDate('');
              setEndDate('');
              setSelectedAccount('All');
            }}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-md bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-semibold border border-amber-200 transition-colors cursor-pointer"
            title="Reset all date and account filters"
          >
            <RotateCcw className="h-4 w-4 text-amber-700" />
            <span>Reset Filter</span>
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold border border-slate-200 transition-colors cursor-pointer"
            title="Print Statement Report"
          >
            <Printer className="h-4 w-4 text-slate-600" />
            <span>Print Statement</span>
          </button>
          <button
            type="button"
            onClick={handleExportPDF}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-md bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            title="Export as PDF document"
          >
            <FileText className="h-4 w-4" />
            <span>Export PDF</span>
          </button>
          <button
            type="button"
            onClick={handleExportStatementXLSX}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            title="Export formatted Excel file (.xlsx)"
          >
            <FileSpreadsheet className="h-4 w-4" />
            <span>Export Statement .xlsx</span>
          </button>
          <button
            type="button"
            onClick={handleExportStatementGoogleSheets}
            disabled={isExportingSheets}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-md bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer disabled:opacity-50"
            title="Export live formatted report directly to Google Sheets"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-200" />
            <span>{isExportingSheets ? 'Exporting to Sheets...' : 'Export to Google Sheets'}</span>
          </button>
        </div>
      </div>

      {/* KPI Cards (No Print) */}
      <div className="no-print grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* 1. OPENING BALANCE CARD */}
        <div className="bg-white border border-slate-200 p-4 sm:p-5 rounded-xl shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5 text-slate-700">
                <span className="bg-indigo-100 text-indigo-700 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black">1</span>
                Opening Cash & Bank
              </span>
            </div>

            <div className="text-xl font-black text-slate-900 tracking-tight font-mono">
              ৳ {formatCurrency(totalOpeningBalance)}
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">As of {startDate ? formatDateForDisplay(startDate) : 'Baseline'}</p>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
              <span className="text-[10px] text-slate-500 font-medium block">Cash Opening</span>
              <span className="font-bold font-mono text-slate-800">৳ {formatCurrency(openingCash)}</span>
            </div>
            <div 
              onClick={() => setBankModalData({
                title: 'Opening Bank Balances Breakdown',
                subtitle: `As of ${startDate || 'Baseline'} across registered accounts`,
                balances: openingBankList
              })}
              className="bg-indigo-50/70 p-2 rounded-lg border border-indigo-100 hover:border-indigo-300 hover:bg-indigo-100/70 transition-all cursor-pointer group"
              title="Click to view bank-wise opening balances"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-indigo-700 font-bold block">Bank Opening</span>
                <Building2 className="h-3 w-3 text-indigo-500 group-hover:text-indigo-700 transition-colors" />
              </div>
              <span className="font-bold font-mono text-indigo-900 block">৳ {formatCurrency(openingBankTotal)}</span>
              <span className="text-[9px] text-indigo-600 font-medium block group-hover:underline">Click details →</span>
            </div>
          </div>
        </div>

        {/* 2. TOTAL RECEIPTS CARD */}
        <div 
          onClick={() => setCategoryBreakdownType('Receipts')}
          className="bg-white border border-emerald-200 p-4 sm:p-5 rounded-xl shadow-xs hover:border-emerald-400 hover:shadow-sm transition-all cursor-pointer group flex flex-col justify-between relative overflow-hidden"
          title="Click to view Receipt Category Breakdown"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-50 rounded-full -mr-8 -mt-8 pointer-events-none group-hover:scale-110 transition-transform" />

          <div>
            <div className="flex items-center justify-between text-emerald-800 text-xs font-bold uppercase tracking-wider mb-2 relative z-10">
              <span className="flex items-center gap-1.5 text-emerald-800">
                <span className="bg-emerald-100 text-emerald-800 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black">2</span>
                Total Receipts (Inflows)
              </span>
              <div className="p-1.5 rounded-lg bg-emerald-100 text-emerald-700">
                <ArrowDownLeft className="h-4 w-4" />
              </div>
            </div>

            <div className="text-xl font-black text-emerald-600 tracking-tight font-mono relative z-10">
              +৳ {formatCurrency(totalReceipts)}
            </div>
            
            <p className="text-[11px] text-slate-500 mt-1 relative z-10">
              {receiptsByCategory.filter(r => r.amount > 0).length} active receipt categories
            </p>
          </div>

          <div className="mt-3 pt-2 border-t border-emerald-100 flex items-center justify-between text-xs font-bold text-emerald-700 group-hover:text-emerald-800 relative z-10">
            <span className="flex items-center gap-1">
              <Eye className="h-3.5 w-3.5" />
              Category Breakdown
            </span>
            <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* 3. TOTAL PAYMENTS CARD */}
        <div 
          onClick={() => setCategoryBreakdownType('Expenses')}
          className="bg-white border border-rose-200 p-4 sm:p-5 rounded-xl shadow-xs hover:border-rose-400 hover:shadow-sm transition-all cursor-pointer group flex flex-col justify-between relative overflow-hidden"
          title="Click to view Expense Category Breakdown"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-rose-50 rounded-full -mr-8 -mt-8 pointer-events-none group-hover:scale-110 transition-transform" />

          <div>
            <div className="flex items-center justify-between text-rose-800 text-xs font-bold uppercase tracking-wider mb-2 relative z-10">
              <span className="flex items-center gap-1.5 text-rose-800">
                <span className="bg-rose-100 text-rose-800 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black">3</span>
                Total Payments (Outflows)
              </span>
              <div className="p-1.5 rounded-lg bg-rose-100 text-rose-700">
                <ArrowUpRight className="h-4 w-4" />
              </div>
            </div>

            <div className="text-xl font-black text-rose-600 tracking-tight font-mono relative z-10">
              -৳ {formatCurrency(totalPayments)}
            </div>

            <p className="text-[11px] text-slate-500 mt-1 relative z-10">
              {paymentsByCategory.filter(p => p.amount > 0).length} active expense categories
            </p>
          </div>

          <div className="mt-3 pt-2 border-t border-rose-100 flex items-center justify-between text-xs font-bold text-rose-700 group-hover:text-rose-800 relative z-10">
            <span className="flex items-center gap-1">
              <Eye className="h-3.5 w-3.5" />
              Category Breakdown
            </span>
            <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* 4. CLOSING BALANCE CARD */}
        <div className="bg-white border border-slate-200 p-4 sm:p-5 rounded-xl shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5 text-slate-700">
                <span className="bg-indigo-100 text-indigo-700 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black">4</span>
                Closing Cash & Bank
              </span>
            </div>

            <div className="text-xl font-black text-slate-900 tracking-tight font-mono">
              ৳ {formatCurrency(totalClosingBalance)}
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">As of {endDate ? formatDateForDisplay(endDate) : 'End of Period'}</p>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
              <span className="text-[10px] text-slate-500 font-medium block">Cash Closing</span>
              <span className="font-bold font-mono text-slate-800">৳ {formatCurrency(closingCash)}</span>
            </div>
            <div 
              onClick={() => setBankModalData({
                title: 'Closing Bank Balances Breakdown',
                subtitle: `As of ${endDate || 'End of Period'} across registered accounts`,
                balances: closingBankList
              })}
              className="bg-indigo-50/70 p-2 rounded-lg border border-indigo-100 hover:border-indigo-300 hover:bg-indigo-100/70 transition-all cursor-pointer group"
              title="Click to view bank-wise closing balances"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-indigo-700 font-bold block">Bank Closing</span>
                <Building2 className="h-3 w-3 text-indigo-500 group-hover:text-indigo-700 transition-colors" />
              </div>
              <span className="font-bold font-mono text-indigo-900 block">৳ {formatCurrency(closingBankTotal)}</span>
              <span className="text-[9px] text-indigo-600 font-medium block group-hover:underline">Click details →</span>
            </div>
          </div>
        </div>

      </div>

      {/* Main Statement Document Container */}
      <div className="print-container bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden p-6 space-y-6">
        
        {/* Statement Header */}
        <div className="border-b border-slate-200 pb-4 text-center space-y-1">
          <h1 className="text-xl font-bold tracking-tight text-slate-900 uppercase">
            Receipts and Payments Statement
          </h1>
          <p className="text-xs font-semibold text-slate-600">
            For the Period: <span className="text-indigo-600 font-bold">{startDate ? formatDateForDisplay(startDate) : 'Beginning'}</span> to <span className="text-indigo-600 font-bold">{endDate ? formatDateForDisplay(endDate) : 'Present'}</span>
          </p>
          <p className="text-[11px] text-slate-500">
            Scope: {selectedAccount === 'All' ? 'Consolidated All Bank & Cash Accounts' : `Account: ${selectedAccount}`} | Currency: BDT (৳)
          </p>
        </div>

        {/* Two Column Accounting Statement Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* LEFT SIDE: RECEIPTS & OPENING BALANCES */}
          <div className="border border-slate-200 rounded-lg overflow-hidden flex flex-col justify-between">
            <div>
              {/* Table Column Title Header */}
              <div className="bg-emerald-700 text-white px-4 py-2.5 font-bold text-xs uppercase tracking-wider flex items-center justify-between">
                <span>Receipts (Inflows) & Opening Balances</span>
                <span>Amount (৳)</span>
              </div>

              {/* 1. Opening Balances Section */}
              <div className="p-4 space-y-2 border-b border-slate-200 bg-slate-50/50">
                <div className="flex items-center justify-between pb-1 border-b border-slate-100 flex-wrap gap-y-1">
                  <div className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                    A. Opening Cash & Bank Balances
                  </div>
                  <div className="flex items-center space-x-1 no-print">
                    <button
                      type="button"
                      onClick={() => {
                        if (openingSortField === 'name') {
                          setOpeningSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
                        } else {
                          setOpeningSortField('name');
                          setOpeningSortOrder('asc');
                        }
                      }}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center space-x-1 border transition-colors cursor-pointer ${
                        openingSortField === 'name'
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Sort opening accounts by Name (A-Z / Z-A)"
                    >
                      <ArrowUpDown className="h-3 w-3" />
                      <span>Name {openingSortField === 'name' ? (openingSortOrder === 'asc' ? 'A-Z' : 'Z-A') : ''}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (openingSortField === 'amount') {
                          setOpeningSortOrder(prev => prev === 'desc' ? 'asc' : 'desc');
                        } else {
                          setOpeningSortField('amount');
                          setOpeningSortOrder('desc');
                        }
                      }}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center space-x-1 border transition-colors cursor-pointer ${
                        openingSortField === 'amount'
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Sort opening accounts by Amount (High / Low)"
                    >
                      <ArrowUpDown className="h-3 w-3" />
                      <span>Amount {openingSortField === 'amount' ? (openingSortOrder === 'desc' ? 'High' : 'Low') : ''}</span>
                    </button>
                  </div>
                </div>
                <div className="space-y-1 pl-2 text-xs">
                  {sortedOpeningBalances.map((acc) => (
                    <div key={acc.name} className="flex items-center justify-between text-slate-700 py-0.5 border-b border-slate-100 last:border-none">
                      <span className="font-medium">{cleanAccountName(acc.name)}</span>
                      <span className="font-mono font-semibold">{formatCurrency(acc.amount)}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-slate-300 font-bold text-xs text-slate-900">
                  <span>Subtotal Opening Balances (A)</span>
                  <span className="font-mono text-emerald-700">৳ {formatCurrency(totalOpeningBalance)}</span>
                </div>
              </div>

              {/* 2. Receipts by Category Section */}
              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                  <div className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                    B. Receipts Received During Period
                  </div>
                  <div className="flex items-center space-x-1 no-print">
                    <button
                      type="button"
                      onClick={() => {
                        if (receiptSortField === 'name') {
                          setReceiptSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
                        } else {
                          setReceiptSortField('name');
                          setReceiptSortOrder('asc');
                        }
                      }}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center space-x-1 border transition-colors cursor-pointer ${
                        receiptSortField === 'name'
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Sort categories by Name (A-Z)"
                    >
                      <ArrowUpDown className="h-3 w-3" />
                      <span>Name {receiptSortField === 'name' ? (receiptSortOrder === 'asc' ? 'A-Z' : 'Z-A') : ''}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (receiptSortField === 'amount') {
                          setReceiptSortOrder(prev => prev === 'desc' ? 'asc' : 'desc');
                        } else {
                          setReceiptSortField('amount');
                          setReceiptSortOrder('desc');
                        }
                      }}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center space-x-1 border transition-colors cursor-pointer ${
                        receiptSortField === 'amount'
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Sort categories by Subtotal Amount"
                    >
                      <ArrowUpDown className="h-3 w-3" />
                      <span>Amount {receiptSortField === 'amount' ? (receiptSortOrder === 'desc' ? 'High' : 'Low') : ''}</span>
                    </button>
                  </div>
                </div>
                {receiptsByCategory.length === 0 ? (
                  <p className="text-xs text-slate-400 italic py-2 text-center">No receipts recorded in this period.</p>
                ) : (
                  <div className="space-y-1.5 pl-2 text-xs">
                    {receiptsByCategory.map((r) => {
                      const pct = totalReceipts > 0 ? ((r.amount / totalReceipts) * 100).toFixed(1) : '0';
                      return (
                        <div
                          key={r.name}
                          onClick={() => setSelectedCategoryDetail({ category: r.name, type: 'Receipts' })}
                          className="flex items-center justify-between py-1 px-1.5 rounded hover:bg-emerald-50 cursor-pointer transition-colors group"
                          title="Click to view category transactions"
                        >
                          <div className="flex items-center space-x-1.5">
                            <Eye className="h-3 w-3 text-slate-400 group-hover:text-emerald-600 no-print" />
                            <span className="font-medium text-slate-800 group-hover:text-emerald-800">{r.name}</span>
                            <span className="text-[10px] text-slate-400 font-mono">({r.count})</span>
                          </div>
                          <div className="text-right">
                            <span className="font-mono font-bold text-slate-900 group-hover:text-emerald-700">
                              {formatCurrency(r.amount)}
                            </span>
                            <span className="text-[10px] text-slate-400 block font-mono">{pct}%</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
                <div className="flex items-center justify-between pt-2 border-t border-slate-300 font-bold text-xs text-slate-900">
                  <span>Subtotal Total Receipts (B)</span>
                  <span className="font-mono text-emerald-700">৳ {formatCurrency(totalReceipts)}</span>
                </div>
              </div>
            </div>

            {/* Total Left Side */}
            <div className="bg-emerald-50 p-4 border-t-2 border-emerald-600 flex items-center justify-between font-bold text-sm text-emerald-950">
              <span>TOTAL RECEIPTS SIDE (A + B)</span>
              <span className="font-mono text-base text-emerald-800">৳ {formatCurrency(totalReceiptsSide)}</span>
            </div>
          </div>


          {/* RIGHT SIDE: PAYMENTS & CLOSING BALANCES */}
          <div className="border border-slate-200 rounded-lg overflow-hidden flex flex-col justify-between">
            <div>
              {/* Table Column Title Header */}
              <div className="bg-rose-700 text-white px-4 py-2.5 font-bold text-xs uppercase tracking-wider flex items-center justify-between">
                <span>Payments (Outflows) & Closing Balances</span>
                <span>Amount (৳)</span>
              </div>

              {/* 1. Payments / Expenses Section */}
              <div className="p-4 space-y-2 border-b border-slate-200">
                <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                  <div className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                    C. Payments & Expenses Made During Period
                  </div>
                  <div className="flex items-center space-x-1 no-print">
                    <button
                      type="button"
                      onClick={() => {
                        if (expenseSortField === 'name') {
                          setExpenseSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
                        } else {
                          setExpenseSortField('name');
                          setExpenseSortOrder('asc');
                        }
                      }}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center space-x-1 border transition-colors cursor-pointer ${
                        expenseSortField === 'name'
                          ? 'bg-rose-100 text-rose-800 border-rose-300'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Sort categories by Name (A-Z)"
                    >
                      <ArrowUpDown className="h-3 w-3" />
                      <span>Name {expenseSortField === 'name' ? (expenseSortOrder === 'asc' ? 'A-Z' : 'Z-A') : ''}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (expenseSortField === 'amount') {
                          setExpenseSortOrder(prev => prev === 'desc' ? 'asc' : 'desc');
                        } else {
                          setExpenseSortField('amount');
                          setExpenseSortOrder('desc');
                        }
                      }}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center space-x-1 border transition-colors cursor-pointer ${
                        expenseSortField === 'amount'
                          ? 'bg-rose-100 text-rose-800 border-rose-300'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Sort categories by Subtotal Amount"
                    >
                      <ArrowUpDown className="h-3 w-3" />
                      <span>Amount {expenseSortField === 'amount' ? (expenseSortOrder === 'desc' ? 'High' : 'Low') : ''}</span>
                    </button>
                  </div>
                </div>
                {paymentsByCategory.length === 0 ? (
                  <p className="text-xs text-slate-400 italic py-2 text-center">No expenses recorded in this period.</p>
                ) : (
                  <div className="space-y-1.5 pl-2 text-xs">
                    {paymentsByCategory.map((p) => {
                      const pct = totalPayments > 0 ? ((p.amount / totalPayments) * 100).toFixed(1) : '0';
                      return (
                        <div
                          key={p.name}
                          onClick={() => setSelectedCategoryDetail({ category: p.name, type: 'Expenses' })}
                          className="flex items-center justify-between py-1 px-1.5 rounded hover:bg-rose-50 cursor-pointer transition-colors group"
                          title="Click to view category transactions"
                        >
                          <div className="flex items-center space-x-1.5">
                            <Eye className="h-3 w-3 text-slate-400 group-hover:text-rose-600 no-print" />
                            <span className="font-medium text-slate-800 group-hover:text-rose-800">{p.name}</span>
                            <span className="text-[10px] text-slate-400 font-mono">({p.count})</span>
                          </div>
                          <div className="text-right">
                            <span className="font-mono font-bold text-slate-900 group-hover:text-rose-700">
                              {formatCurrency(p.amount)}
                            </span>
                            <span className="text-[10px] text-slate-400 block font-mono">{pct}%</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
                <div className="flex items-center justify-between pt-2 border-t border-slate-300 font-bold text-xs text-slate-900">
                  <span>Subtotal Total Payments (C)</span>
                  <span className="font-mono text-rose-700">৳ {formatCurrency(totalPayments)}</span>
                </div>
              </div>

              {/* 2. Closing Balances Section */}
              <div className="p-4 space-y-2 bg-slate-50/50">
                <div className="flex items-center justify-between pb-1 border-b border-slate-100 flex-wrap gap-y-1">
                  <div className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                    D. Closing Cash & Bank Balances
                  </div>
                  <div className="flex items-center space-x-1 no-print">
                    <button
                      type="button"
                      onClick={() => {
                        if (closingSortField === 'name') {
                          setClosingSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
                        } else {
                          setClosingSortField('name');
                          setClosingSortOrder('asc');
                        }
                      }}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center space-x-1 border transition-colors cursor-pointer ${
                        closingSortField === 'name'
                          ? 'bg-rose-100 text-rose-800 border-rose-300'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Sort closing accounts by Name (A-Z / Z-A)"
                    >
                      <ArrowUpDown className="h-3 w-3" />
                      <span>Name {closingSortField === 'name' ? (closingSortOrder === 'asc' ? 'A-Z' : 'Z-A') : ''}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (closingSortField === 'amount') {
                          setClosingSortOrder(prev => prev === 'desc' ? 'asc' : 'desc');
                        } else {
                          setClosingSortField('amount');
                          setClosingSortOrder('desc');
                        }
                      }}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center space-x-1 border transition-colors cursor-pointer ${
                        closingSortField === 'amount'
                          ? 'bg-rose-100 text-rose-800 border-rose-300'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                      title="Sort closing accounts by Amount (High / Low)"
                    >
                      <ArrowUpDown className="h-3 w-3" />
                      <span>Amount {closingSortField === 'amount' ? (closingSortOrder === 'desc' ? 'High' : 'Low') : ''}</span>
                    </button>
                  </div>
                </div>
                <div className="space-y-1 pl-2 text-xs">
                  {sortedClosingBalances.map((acc) => (
                    <div key={acc.name} className="flex items-center justify-between text-slate-700 py-0.5 border-b border-slate-100 last:border-none">
                      <span className="font-medium">{cleanAccountName(acc.name)}</span>
                      <span className="font-mono font-semibold">{formatCurrency(acc.amount)}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-slate-300 font-bold text-xs text-slate-900">
                  <span>Subtotal Closing Balances (D)</span>
                  <span className="font-mono text-indigo-700">৳ {formatCurrency(totalClosingBalance)}</span>
                </div>
              </div>
            </div>

            {/* Total Right Side */}
            <div className="bg-rose-50 p-4 border-t-2 border-rose-600 flex items-center justify-between font-bold text-sm text-rose-950">
              <span>TOTAL PAYMENTS SIDE (C + D)</span>
              <span className="font-mono text-base text-rose-800">৳ {formatCurrency(totalPaymentsSide)}</span>
            </div>
          </div>

        </div>

        {/* Statement Balance Equality Verification Banner */}
        <div className={`p-4 rounded-lg border flex flex-col sm:flex-row items-center justify-between gap-3 text-xs font-semibold ${
          isBalanced ? 'bg-indigo-50 border-indigo-200 text-indigo-900' : 'bg-amber-50 border-amber-200 text-amber-900'
        }`}>
          <div className="flex items-center space-x-2">
            <Scale className={`h-5 w-5 shrink-0 ${isBalanced ? 'text-indigo-600' : 'text-amber-600'}`} />
            <div>
              <span className="font-bold text-sm block">
                {isBalanced ? 'Statement Balanced & Verified ✓' : 'Statement Imbalance Warning'}
              </span>
              <span className="text-slate-600 font-normal">
                Receipts Side (Opening + Receipts = ৳{formatCurrency(totalReceiptsSide)}) equals Payments Side (Payments + Closing = ৳{formatCurrency(totalPaymentsSide)}).
              </span>
            </div>
          </div>
        </div>

        {/* Signatures Section for Printed Official Report */}
        <div className="hidden print:flex items-center justify-between pt-12 text-xs font-semibold text-slate-700">
          <div className="text-center border-t border-slate-400 pt-2 w-48">
            Prepared By
          </div>
          <div className="text-center border-t border-slate-400 pt-2 w-48">
            Approved By
          </div>
        </div>

      </div>

      {/* CATEGORY BREAKDOWN OVERVIEW MODAL (Receipts or Expenses) */}
      {categoryBreakdownType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200 no-print">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className={`px-6 py-4 flex items-center justify-between text-white shrink-0 ${
              categoryBreakdownType === 'Receipts' ? 'bg-emerald-700' : 'bg-rose-700'
            }`}>
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-lg bg-white/20 backdrop-blur-md">
                  {categoryBreakdownType === 'Receipts' ? (
                    <ArrowDownLeft className="h-5 w-5 text-white" />
                  ) : (
                    <ArrowUpRight className="h-5 w-5 text-white" />
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    {categoryBreakdownType === 'Receipts' ? 'Receipt Categories Breakdown' : 'Expense Categories Breakdown'}
                  </h3>
                  <p className="text-xs text-white/80">
                    Category summary for period ({startDate || 'Baseline'} to {endDate || 'Present'})
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setCategoryBreakdownType(null)}
                className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/20 transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto flex-1 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider pb-1 border-b border-slate-200">
                <span>Category Name</span>
                <span>Subtotal Amount (BDT)</span>
              </div>

              <div className="space-y-2">
                {(categoryBreakdownType === 'Receipts' ? receiptsByCategory : paymentsByCategory).map((cat) => {
                  const totalVal = categoryBreakdownType === 'Receipts' ? totalReceipts : totalPayments;
                  const pct = totalVal > 0 ? (cat.amount / totalVal) * 100 : 0;
                  return (
                    <div
                      key={cat.name}
                      onClick={() => {
                        setCategoryBreakdownType(null);
                        setSelectedCategoryDetail({ category: cat.name, type: categoryBreakdownType });
                      }}
                      className="p-3 rounded-xl border border-slate-100 hover:border-slate-300 hover:bg-slate-50 transition-all cursor-pointer group space-y-1.5"
                      title="Click to view transactions in this category"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Eye className="h-3.5 w-3.5 text-slate-400 group-hover:text-slate-700" />
                          <span className="font-bold text-slate-900 text-sm group-hover:text-indigo-600 transition-colors">
                            {cat.name}
                          </span>
                          <span className="text-[10px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full font-mono">
                            {cat.count} {cat.count === 1 ? 'entry' : 'entries'}
                          </span>
                        </div>

                        <div className="text-right">
                          <span className="font-mono font-extrabold text-sm text-slate-900 block">
                            ৳ {formatCurrency(cat.amount)}
                          </span>
                        </div>
                      </div>

                      {/* Progress bar */}
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              categoryBreakdownType === 'Receipts' ? 'bg-emerald-500' : 'bg-rose-500'
                            }`}
                            style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
                          />
                        </div>
                        <span className="text-[10px] font-mono text-slate-500 w-10 text-right">
                          {pct.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <div className="text-xs text-slate-600 font-medium">
                Click any category above to see individual transaction vouchers.
              </div>
              <button
                type="button"
                onClick={() => setCategoryBreakdownType(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

      {/* BANK BREAKDOWN MODAL */}
      {bankModalData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200 no-print">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            
            {/* Modal Header */}
            <div className="px-6 py-4 bg-indigo-700 flex items-center justify-between text-white shrink-0">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-lg bg-white/20 backdrop-blur-md">
                  <Building2 className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    {bankModalData.title}
                  </h3>
                  {bankModalData.subtitle && (
                    <p className="text-xs text-indigo-100">
                      {bankModalData.subtitle}
                    </p>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={() => setBankModalData(null)}
                className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/20 transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto flex-1 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider pb-1 border-b border-slate-200">
                <span>Bank Account Name ({bankModalData.balances.length})</span>
                <span>Balance Amount (BDT)</span>
              </div>

              <div className="space-y-1.5">
                {bankModalData.balances.map((b) => {
                  const totalSum = bankModalData.balances.reduce((s, x) => s + x.amount, 0);
                  const pct = totalSum > 0 ? ((b.amount / totalSum) * 100).toFixed(1) : '0';
                  return (
                    <div
                      key={b.name}
                      className="flex items-center justify-between p-3 rounded-xl border border-slate-100 hover:border-indigo-200 hover:bg-indigo-50/40 transition-colors"
                    >
                      <div className="flex items-center space-x-2.5">
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center font-bold text-indigo-700 text-xs shrink-0">
                          {b.name.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <span className="font-bold text-sm text-slate-900 block">{b.name}</span>
                          <span className="text-[10px] text-slate-500 font-mono">{pct}% of total bank balance</span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="font-mono font-extrabold text-sm text-indigo-900 block">
                          ৳ {formatCurrency(b.amount)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Total Summary Row */}
              <div className="pt-3 border-t-2 border-slate-200 flex items-center justify-between font-bold text-sm text-slate-900 bg-slate-50 p-3 rounded-xl">
                <span>Total Bank Balance</span>
                <span className="font-mono text-indigo-700 text-base">
                  ৳ {formatCurrency(bankModalData.balances.reduce((s, x) => s + x.amount, 0))}
                </span>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end shrink-0">
              <button
                type="button"
                onClick={() => setBankModalData(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

      {/* CATEGORY TRANSACTION DETAIL DRILLDOWN MODAL */}
      {selectedCategoryDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200 no-print">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className={`px-6 py-4 flex items-center justify-between text-white shrink-0 ${
              selectedCategoryDetail.type === 'Receipts' ? 'bg-emerald-700' : 'bg-rose-700'
            }`}>
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-lg bg-white/20 backdrop-blur-md">
                  <FileText className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    Category Ledger Statement: {selectedCategoryDetail.category}
                  </h3>
                  <p className="text-xs text-white/80">
                    {selectedCategoryDetail.type} in selected period ({detailTransactionsWithRunningBalance.length} {detailTransactionsWithRunningBalance.length === 1 ? 'entry' : 'entries'})
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={handlePrintCategoryDetail}
                  className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-xs transition-colors cursor-pointer"
                  title="Print Category Transactions"
                >
                  <Printer className="h-3.5 w-3.5" />
                  <span>Print</span>
                </button>

                <button
                  type="button"
                  onClick={handleExportCategoryPdf}
                  className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-xs transition-colors cursor-pointer"
                  title="Save as PDF"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Save PDF</span>
                </button>

                <button
                  type="button"
                  onClick={handleExportCategoryExcel}
                  className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs transition-colors cursor-pointer"
                  title="Export to Excel"
                >
                  <FileSpreadsheet className="h-3.5 w-3.5" />
                  <span>Excel</span>
                </button>

                <button
                  type="button"
                  onClick={handleExportCategoryToGoogleSheets}
                  disabled={isExportingSheets}
                  className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-medium text-xs transition-colors cursor-pointer disabled:opacity-50"
                  title="Export to Google Sheets"
                >
                  <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-200" />
                  <span>{isExportingSheets ? 'Exporting...' : 'Google Sheets'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedCategoryDetail(null)}
                  className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/20 transition-colors cursor-pointer ml-2"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            {/* Modal Body Table */}
            <div className="p-5 overflow-y-auto flex-1 space-y-4">
              
              {/* Ledger Summary Bar */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                  <div className="text-[11px] font-semibold uppercase text-slate-500">Opening Balance</div>
                  <div className="text-sm font-bold font-mono text-slate-800">
                    ৳ {formatCurrency(detailOpeningBalance)}
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                  <div className="text-[11px] font-semibold uppercase text-slate-500">Period Total ({selectedCategoryDetail.type})</div>
                  <div className={`text-sm font-bold font-mono ${
                    selectedCategoryDetail.type === 'Receipts' ? 'text-emerald-700' : 'text-rose-700'
                  }`}>
                    ৳ {formatCurrency(detailPeriodTotal)}
                  </div>
                </div>
                <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-3">
                  <div className="text-[11px] font-semibold uppercase text-indigo-700">Closing Ledger Balance</div>
                  <div className="text-sm font-extrabold font-mono text-indigo-900">
                    ৳ {formatCurrency(detailClosingBalance)}
                  </div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-800 text-white border-b border-slate-700 font-bold uppercase tracking-wider">
                      <th className="py-3 px-3 text-center w-10">SL#</th>
                      <th className="py-3 px-3">Date</th>
                      <th className="py-3 px-3">Voucher No</th>
                      <th className="py-3 px-3">Account / Source</th>
                      <th className="py-3 px-3">Remarks / Particulars</th>
                      <th className="py-3 px-3 text-right">Amount (BDT)</th>
                      <th className="py-3 px-3 text-right">Running Balance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-medium text-slate-800">
                    {/* Opening Balance Row */}
                    <tr className="bg-slate-100 font-semibold text-slate-700">
                      <td className="py-2.5 px-3 text-center font-mono">-</td>
                      <td className="py-2.5 px-3 font-mono text-slate-500">{startDate ? formatDateForDisplay(startDate) : 'Baseline'}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-400">-</td>
                      <td className="py-2.5 px-3" colSpan={2}>
                        <span className="font-bold text-slate-800">OPENING BALANCE</span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-400">-</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                        ৳ {formatCurrency(detailOpeningBalance)}
                      </td>
                    </tr>

                    {detailTransactionsWithRunningBalance.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-6 text-center text-slate-400 italic">
                          No transaction vouchers found for category "{selectedCategoryDetail.category}" in the selected date range.
                        </td>
                      </tr>
                    ) : (
                      detailTransactionsWithRunningBalance.map((t, index) => {
                        const accName = t.type === 'Receipts' ? t.depositedBank : t.withdrawnBank;
                        return (
                          <tr key={t.id} className="hover:bg-indigo-50/50 transition-colors">
                            <td className="py-2.5 px-3 text-center text-slate-500 font-mono">{index + 1}</td>
                            <td className="py-2.5 px-3 whitespace-nowrap font-mono">{formatDateForDisplay(t.entryDate)}</td>
                            <td className="py-2.5 px-3 font-mono font-bold text-indigo-700">{t.voucherNo}</td>
                            <td className="py-2.5 px-3">
                              <span className="inline-flex items-center px-2 py-0.5 rounded bg-slate-100 text-slate-800 font-semibold text-[11px]">
                                {cleanAccountName(accName || '-')}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-slate-600 max-w-xs truncate">{t.remarks || '-'}</td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                              ৳ {formatCurrency(t.amount)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-black text-indigo-900">
                              ৳ {formatCurrency(t.runningBalance)}
                            </td>
                          </tr>
                        );
                      })
                    )}

                    {/* Closing Balance Row */}
                    <tr className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-300">
                      <td className="py-3 px-3 text-center font-mono">-</td>
                      <td className="py-3 px-3 font-mono text-slate-600">{endDate ? formatDateForDisplay(endDate) : 'Present'}</td>
                      <td className="py-3 px-3 font-mono text-slate-400">-</td>
                      <td className="py-3 px-3 uppercase text-xs tracking-wider" colSpan={2}>
                        CLOSING BALANCE ({selectedCategoryDetail.category})
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-slate-700 text-xs">
                        ৳ {formatCurrency(detailPeriodTotal)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-indigo-700 text-sm font-black">
                        ৳ {formatCurrency(detailClosingBalance)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Modal Footer (Clean, only Close button) */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <div className="text-xs text-slate-600 font-medium">
                Showing <span className="font-bold text-slate-900">{detailTransactionsWithRunningBalance.length}</span> entries | Net Period Total: <span className="font-bold font-mono text-indigo-700">৳ {formatCurrency(detailPeriodTotal)}</span>
              </div>

              <button
                type="button"
                onClick={() => setSelectedCategoryDetail(null)}
                className="px-5 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
